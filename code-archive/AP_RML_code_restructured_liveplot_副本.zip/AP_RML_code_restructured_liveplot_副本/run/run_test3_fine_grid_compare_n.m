% RUN_TEST3_FINE_GRID_COMPARE_N
% 数值实验 3：在较细 theta 网格上比较 direct n 与 WKB 重构 n。
%
% 本版本会额外保存多个时刻的数据，方便后处理画 x-theta-n 热图。
%
% 保存内容：
%   1. summary_compare_n.mat
%   2. snapshots_compare_n.mat
%   3. snapshots/test3_snapshot_*.mat
%
% 每个 snapshot 中包含：
%   x, theta, t, eps
%   n_direct
%   W_wkb, u_wkb, n_wkb
%   relL1, relL2
%   theta_direct, theta_wkb

% clear; clc;

root = fileparts(fileparts(mfilename('fullpath')));
addpath(root);
startup_AP_RML;

%% ========== 参数设置 ==========

quickMode = false;

par = model.default_params_1d('baseline');
par.eps = 1e-4;

if quickMode
    par.Nx = 80;
    par.Ntheta = 128;
    par.T = 8;
    par.dt = 5e-3;
    par.tol = 1e-8;

    % 诊断信息输出间隔
    par.historyEveryTime = 1.0;

    % 多时刻保存，用于后处理画图
    snapshotTimes = 0:1:par.T;

    par.outdir = utils.output_dir('test3_compare_n_quick');
else
    par.Nx = 100;
    par.Ntheta = 60;
    par.T = 5;
    par.dt = 1e-4;
    par.tol = 1e-9;

    par.historyEveryTime = 0.5;

    % 正式实验不建议每一步都存，数据会比较大
    snapshotTimes = [0, 1:10];

    par.outdir = utils.output_dir('test3_compare_n_homo');
end

par.verbose = true;
par.progressEveryPercent = 5;

% 关键：打开快照保存
par.storeSnapshots = true;

% 给求解器使用的保存时刻。如果当前 src.run_wkb_1d 和 src.run_direct_1d
% 已经支持 storeSnapshots，则通常会读取这个字段。
par.snapshotTimes = unique(snapshotTimes(:).');
par.snapshotEveryTime = par.historyEveryTime;

utils.ensure_dir(par.outdir);

fprintf('\n========== TEST 3: fine-grid comparison of n ==========\n');
fprintf('quickMode=%d, eps=%.4g, Nx=%d, Ntheta=%d, T=%.4g, dt=%.4g\n', ...
    quickMode, par.eps, par.Nx, par.Ntheta, par.T, par.dt);
fprintf('预计最多步数: %d；未知量规模约: %d\n', ...
    ceil(par.T/par.dt), (par.Nx+1)*par.Ntheta);
fprintf('计划保存时刻: ');
fprintf('%.4g ', par.snapshotTimes);
fprintf('\n');
fprintf('[TEST 3] 先运行 WKB，然后运行 direct solver。\n');

%% ========== 运行 WKB 与 direct solver ==========

% wkb = src.run_wkb_1d(par);
direct = src.run_direct_1d(par);

%% ========== 终止时刻误差 ==========

wx = utils.trapz_weights(wkb.op.nx, wkb.op.dx);

errL1 = wkb.op.dtheta * sum(wx.' * abs(wkb.n - direct.n));
refL1 = wkb.op.dtheta * sum(wx.' * abs(direct.n));

errL2 = sqrt(wkb.op.dtheta * sum(wx.' * (wkb.n - direct.n).^2));
refL2 = sqrt(wkb.op.dtheta * sum(wx.' * direct.n.^2));

summary = struct();
summary.quickMode = quickMode;
summary.eps = par.eps;
summary.Nx = par.Nx;
summary.Ntheta = par.Ntheta;
summary.T = par.T;
summary.dt = par.dt;
summary.snapshotTimes = par.snapshotTimes;
summary.relL1 = errL1 / max(refL1, realmin);
summary.relL2 = errL2 / max(refL2, realmin);
summary.theta_wkb = get_optional_field(wkb.diagnostics, 'theta_wkb', NaN);
summary.theta_direct = get_optional_field(direct.diagnostics, 'theta_direct', NaN);
summary.wkb_steps = wkb.step;
summary.direct_steps = direct.step;

disp(summary);

%% ========== 整理并保存多个时刻的数据 ==========

snapshotDir = fullfile(par.outdir, 'snapshots');
utils.ensure_dir(snapshotDir);

x = get_grid_field(wkb, 'x');
theta = get_grid_field(wkb, 'theta');

wkbSnaps = collect_solution_snapshots(wkb, 'wkb');
directSnaps = collect_solution_snapshots(direct, 'direct');

% 如果求解器没有真正保存 snapshots，则至少保存终止时刻，避免程序报错。
if isempty(wkbSnaps)
    warning('wkb.snapshots 为空。当前只保存 WKB 终止时刻。请检查 src.run_wkb_1d 是否支持 par.storeSnapshots。');
    wkbSnaps = final_snapshot_from_solution(wkb, 'wkb');
end

if isempty(directSnaps)
    warning('direct.snapshots 为空。当前只保存 direct 终止时刻。请检查 src.run_direct_1d 是否支持 par.storeSnapshots。');
    directSnaps = final_snapshot_from_solution(direct, 'direct');
end

tW = [wkbSnaps.t];
tD = [directSnaps.t];

% 以 WKB 的保存时刻为基准，找 direct 中最近的时刻。
numSnaps = numel(wkbSnaps);
snapshots = struct([]);

for m = 1:numSnaps
    tw = tW(m);
    [~, id] = min(abs(tD - tw));

    nd = directSnaps(id).n;

    W = get_optional_field(wkbSnaps(m), 'W', []);
    u = get_optional_field(wkbSnaps(m), 'u', []);
    nw = get_optional_field(wkbSnaps(m), 'n', []);

    % 如果 snapshot 里面没有 n_wkb，就由 W 和 u 重构。
    if isempty(nw)
        if isempty(W) || isempty(u)
            error('WKB snapshot 中既没有 n，也没有完整的 W,u，无法重构 n_wkb。');
        end
        nw = reconstruct_wkb_density(W, u, par.eps);
    end

    % 误差
    [relL1_m, relL2_m] = relative_errors(nw, nd, wkb.op);

    % trait marginal 的峰值位置
    theta_direct_m = peak_trait(theta, nd, wx, wkb.op.dtheta);
    theta_wkb_m = peak_trait(theta, nw, wx, wkb.op.dtheta);

    one = struct();
    one.t = tw;
    one.eps = par.eps;
    one.x = x;
    one.theta = theta;

    one.n_direct = nd;
    one.W_wkb = W;
    one.u_wkb = u;
    one.n_wkb = nw;

    one.relL1 = relL1_m;
    one.relL2 = relL2_m;
    one.theta_direct = theta_direct_m;
    one.theta_wkb = theta_wkb_m;

    if m == 1
        snapshots = one;
    else
        snapshots(m) = one; %#ok<SAGROW>
    end

    snapFile = fullfile(snapshotDir, sprintf('test3_snapshot_%03d_t%.6g.mat', m, tw));
    save(snapFile, 'one', '-v7.3');

    fprintf('[snapshot %02d/%02d] t = %.6g, relL1 = %.3e, relL2 = %.3e, saved: %s\n', ...
        m, numSnaps, tw, relL1_m, relL2_m, snapFile);
end

%% ========== 保存总结果 ==========

save(fullfile(par.outdir, 'summary_compare_n.mat'), ...
    'summary', 'par', '-v7.3');

save(fullfile(par.outdir, 'snapshots_compare_n.mat'), ...
    'snapshots', 'summary', 'par', '-v7.3');

% 如果还想保存完整求解器返回结果，可以保留下面这个。
% 数据可能较大，因此单独存。
save(fullfile(par.outdir, 'raw_wkb_direct_outputs.mat'), ...
    'wkb', 'direct', '-v7.3');

fprintf('\nTEST 3 完成。\n');
fprintf('summary 保存到: %s\n', fullfile(par.outdir, 'summary_compare_n.mat'));
fprintf('snapshots 保存到: %s\n', fullfile(par.outdir, 'snapshots_compare_n.mat'));
fprintf('单时刻数据保存到: %s\n', snapshotDir);

%% ========================================================================
%% 局部函数
%% ========================================================================

function val = get_optional_field(S, name, defaultVal)
    if isstruct(S) && isfield(S, name)
        val = S.(name);
    else
        val = defaultVal;
    end
end

function x = get_grid_field(sol, name)
% 从 sol 或 sol.op 中读取 x/theta 网格。

    if isfield(sol, name)
        x = sol.(name);
        x = x(:);
        return;
    end

    if isfield(sol, 'op') && isfield(sol.op, name)
        x = sol.op.(name);
        x = x(:);
        return;
    end

    if strcmp(name, 'x')
        if isfield(sol, 'op') && isfield(sol.op, 'xgrid')
            x = sol.op.xgrid(:);
            return;
        elseif isfield(sol, 'op') && isfield(sol.op, 'xx')
            x = sol.op.xx(:);
            return;
        end
    end

    if strcmp(name, 'theta')
        if isfield(sol, 'op') && isfield(sol.op, 'theta_grid')
            x = sol.op.theta_grid(:);
            return;
        elseif isfield(sol, 'op') && isfield(sol.op, 'th')
            x = sol.op.th(:);
            return;
        end
    end

    error('没有找到网格字段 %s。请检查 sol.op 中 x/theta 的变量名。', name);
end

function snaps = collect_solution_snapshots(sol, kind)
% 将不同可能格式的 snapshots 统一整理成 struct 数组。
%
% 输出字段尽量为：
%   t, n, W, u
%
% kind = 'wkb' 或 'direct'

    snaps = struct([]);

    if ~isfield(sol, 'snapshots') || isempty(sol.snapshots)
        return;
    end

    raw = sol.snapshots;

    if isstruct(raw)
        snaps = raw;

        for m = 1:numel(snaps)
            if ~isfield(snaps(m), 't')
                if isfield(snaps(m), 'time')
                    snaps(m).t = snaps(m).time;
                elseif isfield(snaps(m), 'tt')
                    snaps(m).t = snaps(m).tt;
                else
                    snaps(m).t = NaN;
                end
            end
        end

        return;
    end

    error('%s.snapshots 的格式不是 struct，暂时无法自动整理。', kind);
end

function snap = final_snapshot_from_solution(sol, kind)
% 如果求解器没有保存中间快照，则用终止时刻构造一个 snapshot。

    snap = struct();

    if isfield(sol, 't')
        snap.t = sol.t;
    elseif isfield(sol, 'time')
        snap.t = sol.time;
    elseif isfield(sol, 'step') && isfield(sol, 'dt')
        snap.t = sol.step * sol.dt;
    else
        snap.t = NaN;
    end

    if isfield(sol, 'n')
        snap.n = sol.n;
    end

    if strcmp(kind, 'wkb')
        if isfield(sol, 'W')
            snap.W = sol.W;
        end
        if isfield(sol, 'u')
            snap.u = sol.u;
        end
    end
end

function n = reconstruct_wkb_density(W, u, epsVal)
% 由 W 和 u 重构 n = W exp(u/eps)。
% 这里不做 WENO。WENO 建议放在后处理画图脚本里做，因为画图可能需要更细 theta 网格。

    if isvector(u)
        U = repmat(u(:).', size(W,1), 1);
    else
        U = u;
    end

    arg = U / epsVal;

    % 防止 exp 溢出或下溢
    arg = min(max(arg, -745), 700);

    n = W .* exp(arg);

    % 只截断极小的数值负值
    tolNeg = 1e-13 * max(1, max(abs(n(:))));
    n(n < 0 & abs(n) < tolNeg) = 0;
end

function [relL1, relL2] = relative_errors(nw, nd, op)
% 计算加权相对 L1/L2 误差。

    wx = utils.trapz_weights(op.nx, op.dx);

    errL1 = op.dtheta * sum(wx.' * abs(nw - nd));
    refL1 = op.dtheta * sum(wx.' * abs(nd));

    errL2 = sqrt(op.dtheta * sum(wx.' * (nw - nd).^2));
    refL2 = sqrt(op.dtheta * sum(wx.' * nd.^2));

    relL1 = errL1 / max(refL1, realmin);
    relL2 = errL2 / max(refL2, realmin);
end

function thetaPeak = peak_trait(theta, n, wx, dtheta)
% 计算 trait marginal 的峰值位置。
% P(theta_k) = int n(x,theta_k) dx

    P = dtheta * 0; %#ok<NASGU>
    marginal = wx.' * n;
    [~, id] = max(marginal);
    thetaPeak = theta(id);
end