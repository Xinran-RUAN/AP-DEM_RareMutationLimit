% RUN_TEST3_WKB_ADVANTAGE_REFINEMENT
% -------------------------------------------------------------------------
% Test 3b：WKB 粗 trait 网格 vs direct 细 trait 网格。
%
% 目的：
%   说明 rare mutation limit 下，直接解原始密度 n(x,theta,t) 时，theta
%   方向必须用较密网格才能解析集中峰；而 WKB 方法只在较粗 theta 网格上
%   求解 W(x,theta,t), u(theta,t)，再通过正确的重构
%
%       n_WKB(x,theta,t) = W(x,theta,t) * exp(u(theta,t)/eps)
%
%   就可以得到接近 direct 细网格的 trait marginal 和密度结构。
%
% 本脚本只负责“跑数据”和“保存最终比较表”。作图建议放在 post/ 目录中做。
% 作图时必须注意：WKB 的后处理顺序是先重构 W,u，再指数化，最后积分；
% 不能先在粗网格上算 P(theta_k)，再对 P 做插值。
%
% 推荐正文输出：
%   Figure A: t=3 和 t=5 的 trait marginal P(theta) 比较。
%             黑线：固定粗 WKB；彩色点线：direct K=32,64,128,256。
%   Figure B: t=5 的 direct 细网格热图 vs WKB 粗网格重构热图，共用 colorbar。
%   Figure C: 误差随 K_direct 增大下降的曲线。
%   Table   : K_direct, relL1/relL2(n), relL1(P), peak distance, sigma_theta, runtime。
%
% 操作建议：
%   1. 先用 experimentMode='quick' 调通流程；
%   2. 再用 experimentMode='paper' 跑正式数据；
%   3. 如果 K=256 太慢，先跑 K=[32,64,128]，正文表格可把 K=256 留到最后补。
%
% 重要设计选择：
%   - 主实验固定 Nx，只增加 Ntheta。这样能隔离 theta 集中峰的分辨率问题；
%   - 所有 WKB/direct 运行分别存到独立子目录，避免文件名混乱；
%   - stopByResidual=false，强制所有算例跑到同一终止时间，便于同一时刻比较；
%   - snapshotTimes 明确指定；snapshotEveryTime=Inf，避免重复快照和不必要文件。
% -------------------------------------------------------------------------

clear; clc;

root = fileparts(fileparts(mfilename('fullpath')));
addpath(root);
startup_AP_RML;

%% ========================= 用户设置区 =========================

% 'quick'：快速调试；'paper'：正式图表。
experimentMode = 'paper';

% 是否跳过已经存在 final 文件的算例。调试时建议 true，避免重复跑。
skipExisting = true;

% WKB 后处理比较时的重构方法。
% 推荐 'spline'：与早期 PDF 中“cubic spline interpolation + trapezoidal quadrature”一致；
% 可用 'pchip' 作为保形稳健性检查。
reconstructMethodForSummary = 'spline';

switch lower(experimentMode)
    case 'quick'
        % 快速检查程序是否能完整跑完。
        cfg.eps = 1e-2;
        cfg.Nx = 50;
        cfg.dt = 1e-3;
        cfg.T = 5;
        cfg.K_wkb = 32;
        cfg.K_direct_list = [16, 32, 64];
        cfg.tol = 1e-8;
        cfg.outName = 'test3_wkb_advantage_quick';

    case 'paper'
        % 正式建议参数。
        % 若 direct K=256 过慢，可先改成 [32,64,128]，待其它图确认后再补 K=256。
        cfg.eps = 1e-3;
        cfg.Nx = 100;
        cfg.dt = 1e-4;
        cfg.T = 5;
        cfg.K_wkb = 64;
        cfg.K_direct_list = [32, 64, 128, 256];
        cfg.tol = 1e-9;
        cfg.outName = 'test3_wkb_advantage_eps1e-3';

    otherwise
        error('未知 experimentMode：%s。请选择 quick 或 paper。', experimentMode);
end

% 建议保存这些时刻。t=3 和 t=5 可直接用于论文图。
cfg.snapshotTimes = unique([0.5, 1, 2, 3, 4, cfg.T]);
cfg.historyEveryTime = 0.5;
cfg.checkpointEveryTime = 0.5;
cfg.progressEveryPercent = 5;

% 总输出目录。每个 K 会再建一个子目录。
cfg.outRoot = fullfile(root, 'data', cfg.outName);
utils.ensure_dir(cfg.outRoot);

fprintf('\n========== TEST 3b: WKB advantage in theta refinement ==========%s', newline);
fprintf('mode=%s, eps=%.3g, Nx=%d, T=%.3g, dt=%.3g\n', ...
    experimentMode, cfg.eps, cfg.Nx, cfg.T, cfg.dt);
fprintf('固定 WKB: K_wkb=%d\n', cfg.K_wkb);
fprintf('direct refinement K list: '); fprintf('%d ', cfg.K_direct_list); fprintf('\n');
fprintf('snapshotTimes: '); fprintf('%.4g ', cfg.snapshotTimes); fprintf('\n');
fprintf('输出目录: %s\n\n', cfg.outRoot);

%% ========================= 1. 跑固定粗 WKB =========================

parWKB = make_common_par(cfg);
parWKB.Ntheta = cfg.K_wkb;
parWKB.outdir = fullfile(cfg.outRoot, sprintf('wkb_K%04d', cfg.K_wkb));
utils.ensure_dir(parWKB.outdir);

fprintf('\n[1/2] 运行固定粗 WKB：K=%d\n', cfg.K_wkb);
[wkb, wkbInfo] = run_or_load_wkb(parWKB, skipExisting);

%% ========================= 2. 跑 direct theta 加密序列 =========================

directResults = cell(numel(cfg.K_direct_list), 1);
directInfo = struct([]);

fprintf('\n[2/2] 运行 direct theta 加密序列\n');
for ik = 1:numel(cfg.K_direct_list)
    Kd = cfg.K_direct_list(ik);

    parD = make_common_par(cfg);
    parD.Ntheta = Kd;
    parD.outdir = fullfile(cfg.outRoot, sprintf('direct_K%04d', Kd));
    utils.ensure_dir(parD.outdir);

    fprintf('\n--- direct K=%d (%d/%d) ---\n', Kd, ik, numel(cfg.K_direct_list));
    [directResults{ik}, thisDirectInfo] = run_or_load_direct(parD, skipExisting);
    if ik == 1
        directInfo = thisDirectInfo;
    else
        directInfo(ik) = thisDirectInfo; %#ok<SAGROW>
    end
end

%% ========================= 3. 终止时刻比较表 =========================
% 这里比较的是 final time T。中间时刻 t=3,t=5 的曲线图建议用 post 脚本
% 从各子目录的 snapshots 读取。final 表格已经足以显示随 K_direct 增大误差下降。

comparisonRows = struct([]);

for ik = 1:numel(cfg.K_direct_list)
    Kd = cfg.K_direct_list(ik);
    direct = directResults{ik};

    row = compare_wkb_to_direct_final(wkb, direct, cfg.K_wkb, Kd, cfg.eps, reconstructMethodForSummary);
    row.directFinalFile = directInfo(ik).finalFile;
    row.wkbFinalFile = wkbInfo.finalFile;
    row.directRuntimeSeconds = directInfo(ik).runtimeSeconds;
    row.wkbRuntimeSeconds = wkbInfo.runtimeSeconds;
    row.directOutdir = directInfo(ik).outdir;
    row.wkbOutdir = wkbInfo.outdir;

    if ik == 1
        comparisonRows = row;
    else
        comparisonRows(ik) = row; %#ok<SAGROW>
    end
end

comparisonTable = struct2table(comparisonRows);

summaryFile = fullfile(cfg.outRoot, 'test3_wkb_advantage_summary.mat');
save(summaryFile, 'cfg', 'wkbInfo', 'directInfo', 'comparisonTable', '-v7.3');

csvFile = fullfile(cfg.outRoot, 'test3_wkb_advantage_summary.csv');
writetable(comparisonTable, csvFile);

disp(comparisonTable(:, {'K_wkb','K_direct','relL1_n','relL2_n','relL1_P','relL1_P_normalized','theta_wkb','theta_direct','dT_peak','sigma_wkb','sigma_direct'}));

fprintf('\nTEST 3b 完成。\n');
fprintf('summary MAT: %s\n', summaryFile);
fprintf('summary CSV: %s\n', csvFile);
fprintf('下一步：用 post 脚本读取各子目录 snapshots，画 P(theta) 和热图。\n');

%% ========================================================================
%% 局部函数
%% ========================================================================

function par = make_common_par(cfg)
%MAKE_COMMON_PAR 生成 WKB 和 direct 共用参数。
% 注意：这里不设置 Ntheta 和 outdir，由调用处分别设置。

    par = model.default_params_1d('baseline');

    % 基本物理与网格参数
    par.eps = cfg.eps;
    par.Nx = cfg.Nx;
    par.T = cfg.T;
    par.dt = cfg.dt;
    par.tol = cfg.tol;

    % 为了严格比较同一时刻，禁止按 residual 提前停。
    % 否则不同 K 可能在不同时间停止，无法做 t=3/t=5 对比。
    par.stopByResidual = false;

    % WKB 方程中的相位方程格式。若论文强调 WENO，这里显式设为 weno5。
    % 若想做单调基线测试，可改为 'godunov'。
    par.phaseHamiltonian = 'weno5';

    % WKB 小 epsilon 稳健格式。
    par.amplitudeVariant = 'wkb-if-split';
    par.reactionDiscretization = 'logistic-exact';
    par.rhoReconstruction = 'laplace-hybrid';
    par.residualMode = 'wkb-steady';

    % 时间步控制。本实验先用固定 dt，避免不同 K 的自适应路径差别太大。
    par.adaptiveTimeStep = false;

    % 中间数据保存。
    % 只在指定 snapshotTimes 保存完整快照；checkpoint 额外用于中途停止恢复。
    par.storeSnapshots = true;
    par.saveIntermediate = true;
    par.snapshotTimes = cfg.snapshotTimes;
    par.snapshotEveryTime = Inf;
    par.snapshotEverySteps = [];
    par.saveLatestCheckpoint = true;
    par.checkpointEveryTime = cfg.checkpointEveryTime;
    par.checkpointEverySteps = [];
    par.saveHistoryCheckpoint = true;
    par.historyEveryTime = cfg.historyEveryTime;
    par.historyEverySteps = [];

    % 输出控制
    par.verbose = true;
    par.progressEveryPercent = cfg.progressEveryPercent;
    par.progressEverySeconds = 20;
    par.printIntermediateSaveMessage = true;

    % 若后续 K 很大、快照很多导致 MAT 文件超过 2GB，再改成 true。
    par.saveMatV73 = false;

    % 默认不打开在线图，避免批量实验变慢。
    par.livePlot = false;
end

function [wkb, info] = run_or_load_wkb(par, skipExisting)
%RUN_OR_LOAD_WKB 跑 WKB；若 final 文件已存在且 skipExisting=true，则直接读取。

    tag = utils.build_tag(par);
    finalFile = fullfile(par.outdir, [tag '_final.mat']);

    info = struct();
    info.outdir = par.outdir;
    info.tag = tag;
    info.finalFile = finalFile;
    info.loadedExisting = false;
    info.runtimeSeconds = NaN;

    if skipExisting && isfile(finalFile)
        fprintf('[WKB] 发现已有 final 文件，直接读取：%s\n', finalFile);
        wkb = load(finalFile);
        info.loadedExisting = true;
        return;
    end

    tStart = tic;
    wkb = src.run_wkb_1d(par);
    info.runtimeSeconds = toc(tStart);
    info.finalFile = finalFile;
end

function [direct, info] = run_or_load_direct(par, skipExisting)
%RUN_OR_LOAD_DIRECT 跑 direct；若 final 文件已存在且 skipExisting=true，则直接读取。

    tag = [utils.build_tag(par) '_direct'];
    finalFile = fullfile(par.outdir, [tag '_final.mat']);

    info = struct();
    info.outdir = par.outdir;
    info.tag = tag;
    info.finalFile = finalFile;
    info.loadedExisting = false;
    info.runtimeSeconds = NaN;

    if skipExisting && isfile(finalFile)
        fprintf('[DIRECT] 发现已有 final 文件，直接读取：%s\n', finalFile);
        direct = load(finalFile);
        info.loadedExisting = true;
        return;
    end

    tStart = tic;
    direct = src.run_direct_1d(par);
    info.runtimeSeconds = toc(tStart);
    info.finalFile = finalFile;
end

function row = compare_wkb_to_direct_final(wkb, direct, K_wkb, K_direct, epsVal, reconMethod)
%COMPARE_WKB_TO_DIRECT_FINAL 在 direct 网格上比较 final time 的 n 和 P(theta)。
% WKB 重构使用正确顺序：先把 W,u 重构到 direct 的 theta 网格，再计算 exp。

    xD = direct.op.x(:);
    thetaD = direct.op.theta(:);
    nD = direct.n;

    nW = reconstruct_wkb_density_on_grid(wkb, xD, thetaD, epsVal, reconMethod);

    wx = trapz_weights_from_x(xD);
    dthetaD = 1 / numel(thetaD);

    errL1 = dthetaD * sum(wx.' * abs(nW - nD));
    refL1 = dthetaD * sum(wx.' * abs(nD));
    errL2 = sqrt(dthetaD * sum(wx.' * (nW - nD).^2));
    refL2 = sqrt(dthetaD * sum(wx.' * nD.^2));

    PW = wx.' * nW; PW = PW(:);
    PD = wx.' * nD; PD = PD(:);

    relL1P = dthetaD * sum(abs(PW - PD)) / max(dthetaD * sum(abs(PD)), realmin);
    relL2P = sqrt(dthetaD * sum((PW - PD).^2)) / max(sqrt(dthetaD * sum(PD.^2)), realmin);

    PWn = PW / max(dthetaD * sum(PW), realmin);
    PDn = PD / max(dthetaD * sum(PD), realmin);
    relL1Pn = dthetaD * sum(abs(PWn - PDn)) / max(dthetaD * sum(abs(PDn)), realmin);

    [~, idW] = max(PW);
    [~, idD] = max(PD);
    thetaW = thetaD(idW);
    thetaDir = thetaD(idD);
    dPeak = periodic_distance_scalar(thetaW, thetaDir, 1.0);

    sigmaW = sigma_theta_from_P(thetaD, PW, thetaW, 1.0);
    sigmaD = sigma_theta_from_P(thetaD, PD, thetaDir, 1.0);

    row = struct();
    row.K_wkb = K_wkb;
    row.K_direct = K_direct;
    row.eps = epsVal;
    row.Nx = numel(xD) - 1;
    row.t_wkb = wkb.t;
    row.t_direct = direct.t;
    row.relL1_n = errL1 / max(refL1, realmin);
    row.relL2_n = errL2 / max(refL2, realmin);
    row.relL1_P = relL1P;
    row.relL2_P = relL2P;
    row.relL1_P_normalized = relL1Pn;
    row.theta_wkb = thetaW;
    row.theta_direct = thetaDir;
    row.dT_peak = dPeak;
    row.sigma_wkb = sigmaW;
    row.sigma_direct = sigmaD;
    row.wkb_steps = wkb.step;
    row.direct_steps = direct.step;
    row.reconstructMethod = string(reconMethod);
end

function nW = reconstruct_wkb_density_on_grid(wkb, xTarget, thetaTarget, epsVal, method)
%RECONSTRUCT_WKB_DENSITY_ON_GRID 把 W,u 重构到目标 x/theta 网格后计算 n。
% 正确顺序：W,u -> 插值 -> W_fine exp(u_fine/eps)。

    xW = wkb.op.x(:);
    thetaW = wkb.op.theta(:);
    W = wkb.W;
    u = wkb.u;

    % x 方向通常相同；若不同，只做线性插值。
    if numel(xW) == numel(xTarget) && max(abs(xW - xTarget(:))) < 1e-12
        W_x = W;
    else
        W_x = interp1(xW, W, xTarget(:), 'linear', 'extrap');
    end

    % theta 方向重构 W。
    W_xt = zeros(numel(xTarget), numel(thetaTarget));
    for j = 1:numel(xTarget)
        W_xt(j, :) = periodic_interp(thetaW, W_x(j, :), thetaTarget, 1.0, method).';
    end

    % theta 方向重构 u。u 通常是 1 x K；也兼容 Nx x K。
    if isvector(u)
        u_t = periodic_interp(thetaW, u(:), thetaTarget, 1.0, method).';
        U_xt = repmat(u_t, numel(xTarget), 1);
    else
        if numel(xW) == numel(xTarget) && max(abs(xW - xTarget(:))) < 1e-12
            u_x = u;
        else
            u_x = interp1(xW, u, xTarget(:), 'linear', 'extrap');
        end
        U_xt = zeros(numel(xTarget), numel(thetaTarget));
        for j = 1:numel(xTarget)
            U_xt(j, :) = periodic_interp(thetaW, u_x(j, :), thetaTarget, 1.0, method).';
        end
    end

    % 插值可能产生极小负 W。W 是振幅，负值没有物理意义，截断。
    W_xt(W_xt < 0) = 0;

    arg = U_xt / epsVal;
    arg = min(max(arg, -745), 700);
    nW = W_xt .* exp(arg);
end

function fq = periodic_interp(theta, f, thetaq, period, method)
%PERIODIC_INTERP 周期插值。推荐 method='spline' 或 'pchip'。

    theta = theta(:);
    f = f(:);
    thetaq = thetaq(:);

    if nargin < 5 || isempty(method)
        method = 'spline';
    end

    if numel(theta) > 2 && abs((theta(end) - theta(1)) - period) < 1e-12
        theta = theta(1:end-1);
        f = f(1:end-1);
    end

    thetaExt = [theta; theta(1) + period];
    fExt = [f; f(1)];
    tq = mod(thetaq - theta(1), period) + theta(1);

    fq = interp1(thetaExt, fExt, tq, method);
end

function wx = trapz_weights_from_x(x)
%TRAPZ_WEIGHTS_FROM_X 非均匀 x 网格的梯形积分权重。

    x = x(:);
    Nx = numel(x);
    wx = zeros(Nx,1);
    wx(1) = 0.5 * (x(2) - x(1));
    wx(end) = 0.5 * (x(end) - x(end-1));
    for j = 2:Nx-1
        wx(j) = 0.5 * (x(j+1) - x(j-1));
    end
end

function d = periodic_distance_scalar(a, b, period)
    d = abs(a - b);
    d = min(d, period - d);
end

function sig = sigma_theta_from_P(theta, P, thetaPeak, period)
    dist = abs(theta(:) - thetaPeak);
    dist = min(dist, period - dist);
    sig = sqrt(sum((dist.^2) .* P(:)) / max(sum(P(:)), realmin));
end
