function result = run_wkb_1d(par)
%RUN_WKB_1D 运行一维有限差分 WKB 求解器。
%   输入 par 由 model.default_params_1d 生成。该函数是核心程序：
%   1) 由 (W,u) 重构 rho；
%   2) 对每个 theta 求空间主特征值 H(theta,rho)；
%   3) 更新相位 u；
%   4) 更新振幅 W；
%   5) 做 gauge 归一化并输出诊断量。

%-------------------------
% 初始化网格、算子、输出目录和进度条
%-------------------------
[W, u, D, Kx, grid] = model.initial_wkb_1d(par);
op = src.build_operators_1d(grid);
par.outdir = utils.ensure_dir(par.outdir);
tag = utils.build_tag(par);
prog = utils.progress_init('WKB-1D', par);
livePlotEverySteps = local_liveplot_every_steps(par);
lp = utils.liveplot_init_1d(par, 'wkb');

if isempty(par.snapshotTimes)
    snapshotTimes = [];
else
    snapshotTimes = par.snapshotTimes(:).';
end
nextSnap = 1;
history = [];
historyEverySteps = local_history_every_steps(par);
lastInfo = struct();
lastPlotState = struct();

% 统一振幅方程版本名，便于诊断和保存。
switch lower(par.amplitudeVariant)
    case {'split','split-wkb'}
        variant = 'split';
    case {'density-compatible','dc'}
        variant = 'density-compatible';
    otherwise
        error('Unknown amplitudeVariant "%s".', par.amplitudeVariant);
end

t = 0;
step = 0;
residual = Inf;


%% 保存初始快照 t = 0
if isfield(par, 'saveInitialSnapshot') && par.saveInitialSnapshot
    t = 0;

    snapName0 = sprintf('baseline_eps%.4g_Nx%d_K%d_dt%.4g_split_direct-log_t0.mat', ...
        par.eps, par.Nx, par.Ntheta, par.dt);

    save(fullfile(par.outdir, snapName0), ...
        'W', 'u', 'D', 'Kx', 'grid', 'par', 't');

    fprintf('[WKB-1D] 已保存初值快照: t=0\n');
end

%-------------------------
% 主时间循环
%-------------------------
while t < par.T && step < par.maxSteps
    % 当前密度和有效 Hamiltonian。H 的计算是最耗时的部分之一。
    [rho, ~] = src.reconstruct_rho_1d(W, u, par.eps, op, par.rhoReconstruction);
    H = src.solve_H_fd_1d(D, Kx, rho, op);

    uOld = u;
    WOld = W;

    % 相位方程：半隐式处理 epsilon*u_{theta theta}。
    uStep = src.step_phase_1d(u, H, par.eps, par.dt, op, par.phaseHamiltonian, par.lfAlpha);

    % 振幅方程：split 版本和 density-compatible 版本二选一。
    switch variant
        case 'split'
            WStep = src.update_w_split_fd_1d(W, uStep, D, Kx, rho, H, par.eps, par.dt, op, par);
        case 'density-compatible'
            WStep = src.update_w_density_compatible_fd_1d(W, uStep, D, Kx, rho, H, par.eps, par.dt, op, par);
    end

    % gauge 归一化：保持 n = W exp(u/eps) 不变，同时令 max(u)=0。
    [W, u] = src.normalize_gauge(WStep, uStep, par.eps, 'max');
    t = t + par.dt;
    step = step + 1;

    % 稳态残差，同时检查 u 和 W。
    residual = max(max(abs(u(:)-uOld(:))) / par.dt, ...
                   max(abs(W(:)-WOld(:))) / (par.dt*(1 + max(abs(W(:))))));
  
    % 诊断历史不在每一步都算，因为 gammaR 和 H 都比较贵。
    if step == 1 || mod(step, historyEverySteps) == 0 || residual <= par.tol
        [rhoNow, nNow] = src.reconstruct_rho_1d(W, u, par.eps, op, par.rhoReconstruction);
        HNow = src.solve_H_fd_1d(D, Kx, rhoNow, op);
        dg = src.compute_diagnostics_1d(W, u, D, Kx, rhoNow, HNow, par.eps, op, par, variant);
        history = utils.append_history(history, t, residual, dg);
        lastInfo = local_progress_info(dg);
        lastPlotState = local_make_plot_state(W, u, nNow, rhoNow, HNow, Kx, op, par, t, step, residual, dg);
    end

    % 进度输出：即使本步没有重新计算详细诊断，也会显示最新已知 theta/gammaR。
    prog = utils.progress_update(prog, step, t, residual, lastInfo);

    % 在线图像监测：不需要每一步刷新，否则会明显拖慢计算。
    if lp.enabled && ~isempty(fieldnames(lastPlotState)) && ...
            (step == 1 || mod(step, livePlotEverySteps) == 0 || residual <= par.tol)
        lastPlotState.saveFrame = isfield(par, 'livePlotSave') && par.livePlotSave;
        lp = utils.liveplot_update_1d(lp, 'wkb', lastPlotState);
        if isfield(par, 'livePlotPause') && par.livePlotPause > 0
            pause(par.livePlotPause);
        end
    end

    % 按用户给定时间保存快照。
    if par.storeSnapshots && nextSnap <= numel(snapshotTimes) && t + 1e-12 >= snapshotTimes(nextSnap)
        vars = struct('W',W,'u',u,'D',D,'Kx',Kx,'grid',grid,'par',par,'t',t,'history',history);
        utils.save_snapshot(par.outdir, tag, t, vars);
        if par.verbose
            fprintf('[WKB-1D] 已保存快照: t=%.6g\n', t);
        end
        nextSnap = nextSnap + 1;
    end

    if par.stopByResidual && residual <= par.tol
        break;
    end
end

%-------------------------
% 最终重构、诊断和保存
%-------------------------
[rho, n] = src.reconstruct_rho_1d(W, u, par.eps, op, par.rhoReconstruction);
H = src.solve_H_fd_1d(D, Kx, rho, op);
diagInfo = src.compute_diagnostics_1d(W, u, D, Kx, rho, H, par.eps, op, par, variant);
result = struct('W',W,'u',u,'n',n,'rho',rho,'H',H,'D',D,'Kx',Kx,'grid',grid, ...
                'op',op,'par',par,'t',t,'step',step,'residual',residual, ...
                'history',history,'diagnostics',diagInfo,'tag',tag,'variant',variant);

utils.progress_finish(prog, step, t, residual, local_progress_info(diagInfo));
outfile = fullfile(par.outdir, [tag '_final.mat']);
save(outfile, '-struct', 'result');
if par.verbose
    fprintf('[WKB-1D] 结果已保存: %s\n', outfile);
end
utils.liveplot_finish_1d(lp);
end

function historyEverySteps = local_history_every_steps(par)
% 根据 par.historyEverySteps 或 par.historyEveryTime 计算诊断记录间隔。
if isfield(par, 'historyEverySteps') && ~isempty(par.historyEverySteps) && ...
        isnumeric(par.historyEverySteps) && isscalar(par.historyEverySteps) && par.historyEverySteps > 0
    historyEverySteps = max(1, round(par.historyEverySteps));
elseif isfield(par, 'historyEveryTime') && ~isempty(par.historyEveryTime) && ...
        isnumeric(par.historyEveryTime) && isscalar(par.historyEveryTime) && par.historyEveryTime > 0
    historyEverySteps = max(1, round(par.historyEveryTime / par.dt));
else
    historyEverySteps = max(1, round(0.1 / par.dt));
end
end


function livePlotEverySteps = local_liveplot_every_steps(par)
% 根据 par.livePlotEverySteps 或 par.livePlotEveryTime 计算在线图刷新间隔。
if isfield(par, 'livePlotEverySteps') && ~isempty(par.livePlotEverySteps) && ...
        isnumeric(par.livePlotEverySteps) && isscalar(par.livePlotEverySteps) && par.livePlotEverySteps > 0
    livePlotEverySteps = max(1, round(par.livePlotEverySteps));
elseif isfield(par, 'livePlotEveryTime') && ~isempty(par.livePlotEveryTime) && ...
        isnumeric(par.livePlotEveryTime) && isscalar(par.livePlotEveryTime) && par.livePlotEveryTime > 0
    livePlotEverySteps = max(1, round(par.livePlotEveryTime / par.dt));
else
    livePlotEverySteps = max(1, round(1 / par.dt));
end
end

function state = local_make_plot_state(W, u, n, rho, H, Kx, op, par, t, step, residual, dg)
% 组织在线图像监测所需的数据。
state = struct();
state.W = W;
state.u = u;
state.n = n;
state.rho = rho;
state.H = H;
state.Kx = Kx;
state.x = op.x;
state.theta = op.theta;
state.P = dg.P;
state.theta_peak = dg.theta_wkb;
state.theta_m = par.theta_m;
state.sigma_theta = dg.sigma_theta;
state.gammaR = dg.gammaR;
state.rho_max = dg.rho_max;
state.residual = residual;
state.t = t;
state.T = par.T;
state.step = step;
state.saveFrame = false;
end

function info = local_progress_info(dg)
% 从完整诊断量中提取一行进度输出需要的标量。
info = struct();
if isempty(dg)
    return;
end
info.theta_wkb = dg.theta_wkb;
info.theta_direct = dg.theta_direct;
info.err_wkb_to_m = dg.err_wkb_to_m;
info.sigma_theta = dg.sigma_theta;
info.gammaR = dg.gammaR;
info.rho_max = dg.rho_max;
info.Hmin = dg.Hmin;
end
