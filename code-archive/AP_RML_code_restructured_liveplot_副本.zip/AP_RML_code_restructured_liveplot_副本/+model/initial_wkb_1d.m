% function [W, u, D, K, grid] = initial_wkb_1d(par)
% %INITIAL_WKB_1D Initial data and coefficients for the WKB solver.
% grid = model.make_grid_1d(par);
% x = grid.x;
% theta = grid.theta;
% D = par.D_fun(theta);
% K = par.K_fun(x);
% 
% u = -par.alpha0 * (1 - cos(2*pi*(theta - par.theta0)));
% W = repmat(1 + 0.1*cos(2*pi*x), 1, par.Ntheta);
% [W, u] = src.normalize_gauge(W, u, par.eps, 'max');
% end


function [W, u, D, K, grid] = initial_wkb_1d(par)
%INITIAL_WKB_1D Initial data and coefficients for the WKB solver.
% 用于 Test 2 的初值：theta 方向均匀，用来观察 long-time trait concentration.

grid = model.make_grid_1d(par);
x = grid.x;
theta = grid.theta;

D = par.D_fun(theta);
K = par.K_fun(x);

% theta 方向 homogeneous，避免初值预设峰值
u = zeros(1, par.Ntheta);

% 若 K(x) 本身非均匀，用这个最干净
rho0 = ones(size(x));

% 若完全均匀时选择机制不明显，可以改成下面这一行
% rho0 = 1 + 0.05*cos(2*pi*x);

W = repmat(rho0, 1, par.Ntheta);

[W, u] = src.normalize_gauge(W, u, par.eps, 'max');
end