%% plot_test3_trait_marginal.m
% Test 3: trait marginal comparison at a fixed time
%
% 画：
%   P_dir(theta) = int n_dir(x,theta) dx
%   P_WKB(theta) = int n_WKB(x,theta) dx
%
% 其中
%   n_WKB = W exp(u/eps)
%
% 本脚本固定某个时刻 targetTime，
% 自动寻找最接近该时刻的 WKB 和 direct snapshot 文件，
% 并在同一张图中画两条 trait marginal 曲线。

clear; clc; close all;

%% ========== 用户需要检查的部分 ==========

% 自动定位项目根目录
thisFile = mfilename('fullpath');
if isempty(thisFile)
    thisDir = pwd;
else
    thisDir = fileparts(thisFile);
end

rootCandidates = {
    pwd, ...
    thisDir, ...
    fileparts(thisDir), ...
    fileparts(fileparts(thisDir))
};

root = '';
for ii = 1:numel(rootCandidates)
    cand = rootCandidates{ii};
    if isempty(cand)
        continue;
    end

    if isfile(fullfile(cand, 'startup_AP_RML.m')) && ...
            isfolder(fullfile(cand, 'data'))
        root = cand;
        break;
    end
end

if isempty(root)
    error('无法自动定位项目根目录。请确认 startup_AP_RML.m 和 data 文件夹在同一级目录。');
end

% 数据目录
dataDir = fullfile(root, 'data', 'test3_compare_n');

% 固定命名。按实际参数修改这一行即可。
caseName = 'baseline_eps0.001_Nx100_K128_dt0.0001_split_direct-log';

% 固定要画的时刻
targetTime = 10;

% 如果 mat 文件里面没有 eps/epsilon 变量，就用这里的 epsVal
epsVal = 1e-3;

% theta 周期
thetaPeriod = 1.0;

% 是否对 P(theta) 做 WENO 后处理，使曲线更光滑
useWENO = true;

% WENO 后处理加密倍数
thetaRefine = 8;

% 是否归一化 marginal。
% false: 画真实 P(theta)
% true : 画 P(theta)/(int P(theta)dtheta)，只比较形状和峰值位置
normalizeMarginal = false;

% 是否保存图片
saveFig = true;

%% ========== 自动寻找固定时刻的 WKB 和 direct 文件 ==========

fileWKB = find_snapshot_file(dataDir, caseName, targetTime, false);
fileDIR = find_snapshot_file(dataDir, caseName, targetTime, true);

timeTag = sprintf('t%.6g', targetTime);

fprintf('项目根目录: %s\n', root);
fprintf('数据目录:   %s\n', dataDir);
fprintf('WKB 文件:   %s\n', fileWKB);
fprintf('direct 文件:%s\n', fileDIR);

assert(isfile(fileWKB), '找不到 WKB 文件：%s', fileWKB);
assert(isfile(fileDIR), '找不到 direct 文件：%s', fileDIR);

%% ========== 读取数据 ==========

Swkb0 = load(fileWKB);
Sdir0 = load(fileDIR);

% 兼容 one/direct/wkb/snapshots 等保存格式
Swkb = select_snapshot_struct(Swkb0);
Sdir = select_snapshot_struct(Sdir0);

%% ========== 提取 x, theta, eps ==========

x = get_from_paths(Sdir, ...
    {'x','direct.x','wkb.x','one.x','op.x','op.xgrid','op.xx','xx','xgrid','x_grid','xGrid'}, ...
    true, []);

if isempty(x)
    x = get_from_paths(Swkb, ...
        {'x','direct.x','wkb.x','one.x','op.x','op.xgrid','op.xx','xx','xgrid','x_grid','xGrid'}, ...
        false, []);
end

theta = get_from_paths(Sdir, ...
    {'theta','direct.theta','wkb.theta','one.theta','op.theta','op.theta_grid','op.th','th','theta_grid','thetaGrid'}, ...
    true, []);

if isempty(theta)
    theta = get_from_paths(Swkb, ...
        {'theta','direct.theta','wkb.theta','one.theta','op.theta','op.theta_grid','op.th','th','theta_grid','thetaGrid'}, ...
        false, []);
end

x = grid_vector(x, 'x');
theta = grid_vector(theta, 'theta');

Nx = numel(x);
Ntheta = numel(theta);

epsRead = get_from_paths(Swkb, ...
    {'eps','epsilon','vareps','epsVal','par.eps','one.eps','wkb.eps','direct.eps'}, ...
    true, epsVal);

epsVal = double(epsRead);
epsVal = epsVal(end);

%% ========== 提取 direct density ==========

nDirRaw = get_from_paths(Sdir, ...
    {'n_direct','ndir','n_dir','nDir','direct.n','one.n','n','density','n_final','n_end'}, ...
    false, []);

nDir = to_xt_matrix(nDirRaw, Nx, Ntheta, 'n_direct');

%% ========== 提取 WKB density 或者 W,u ==========

nWKB_raw = get_from_paths(Swkb, ...
    {'n_wkb','nWKB','wkb.n_wkb','wkb.n','one.n_wkb','n'}, ...
    true, []);

if isempty(nWKB_raw)
    Wraw = get_from_paths(Swkb, ...
        {'W_wkb','W','w','wkb.W','wkb.w','one.W_wkb','one.W','W_final','w_final','amp','amplitude'}, ...
        false, []);

    uraw = get_from_paths(Swkb, ...
        {'u_wkb','u','U','wkb.u','wkb.U','one.u_wkb','one.u','u_final','U_final','phase','phi'}, ...
        false, []);

    W = to_xt_matrix(Wraw, Nx, Ntheta, 'W');
    u = to_u_array(uraw, Nx, Ntheta, 'u');

    nWKB = reconstruct_wkb_density(W, u, epsVal);
else
    nWKB = to_xt_matrix(nWKB_raw, Nx, Ntheta, 'n_wkb');
end

%% ========== 计算 trait marginal ==========

wx = trapz_weights_from_x(x);

Pdir = wx.' * nDir;
Pwkb = wx.' * nWKB;

Pdir = Pdir(:);
Pwkb = Pwkb(:);

dtheta = thetaPeriod / Ntheta;

if normalizeMarginal
    Pdir = Pdir / max(dtheta * sum(Pdir), realmin);
    Pwkb = Pwkb / max(dtheta * sum(Pwkb), realmin);
    yText = 'normalized trait marginal';
else
    yText = 'trait marginal P(\theta)';
end

% 峰值位置
[~, idDir] = max(Pdir);
[~, idWKB] = max(Pwkb);

thetaDirPeak = theta(idDir);
thetaWKBPeak = theta(idWKB);

distPeak = abs(thetaDirPeak - thetaWKBPeak);
distPeak = min(distPeak, thetaPeriod - distPeak);

relL1P = dtheta * sum(abs(Pdir - Pwkb)) / max(dtheta * sum(abs(Pdir)), realmin);
relL2P = sqrt(dtheta * sum((Pdir - Pwkb).^2)) / ...
         max(sqrt(dtheta * sum(Pdir.^2)), realmin);

fprintf('\nTrait marginal comparison:\n');
fprintf('  target time = %.8g\n', targetTime);
fprintf('  eps = %.6g\n', epsVal);
fprintf('  Nx = %d, Ntheta = %d\n', Nx, Ntheta);
fprintf('  theta_dir peak = %.8g\n', thetaDirPeak);
fprintf('  theta_WKB peak = %.8g\n', thetaWKBPeak);
fprintf('  periodic peak distance = %.6e\n', distPeak);
fprintf('  relative L1 of P = %.6e\n', relL1P);
fprintf('  relative L2 of P = %.6e\n\n', relL2P);

%% ========== WENO 后处理，使曲线更光滑 ==========

if useWENO && thetaRefine > 1
    NthetaPlot = thetaRefine * Ntheta;
    thetaPlot = linspace(theta(1), theta(1) + thetaPeriod, NthetaPlot + 1).';
    thetaPlot(end) = [];

    PdirPlot = weno5_periodic_interp(theta, Pdir, thetaPlot, thetaPeriod);
    PwkbPlot = weno5_periodic_interp(theta, Pwkb, thetaPlot, thetaPeriod);

    % 截断极小负值
    tolNeg = 1e-13 * max(1, max(abs([PdirPlot(:); PwkbPlot(:)])));
    PdirPlot(PdirPlot < 0 & abs(PdirPlot) < tolNeg) = 0;
    PwkbPlot(PwkbPlot < 0 & abs(PwkbPlot) < tolNeg) = 0;
else
    thetaPlot = theta;
    PdirPlot = Pdir;
    PwkbPlot = Pwkb;
end

%% ========== 画图：固定时刻，两条曲线放在同一张图里 ==========

figure('Color', 'w', 'Position', [120, 120, 760, 520]);
hold on; box on;

h1 = plot(thetaPlot, PdirPlot, '-', ...
    'LineWidth', 2.6);

h2 = plot(thetaPlot, PwkbPlot, '--', ...
    'LineWidth', 2.6);

xlabel('\theta', 'Interpreter', 'tex');
ylabel(yText, 'Interpreter', 'tex');

legend([h1, h2], ...
    {'Direct density', 'WKB reconstruction'}, ...
    'Location', 'best', ...
    'Interpreter', 'tex');

title(sprintf('Trait marginal at t = %.4g, \\epsilon = %.3g', ...
    targetTime, epsVal), ...
    'Interpreter', 'tex');

xlim([theta(1), theta(1) + thetaPeriod]);
set(gca, 'FontSize', 13, 'LineWidth', 1.0);

%% ========== 保存图片 ==========

if saveFig
    outDir = fullfile(dataDir, 'figures');
    if ~exist(outDir, 'dir')
        mkdir(outDir);
    end

    if normalizeMarginal
        outName = sprintf('test3_trait_marginal_normalized_%s_eps%.3g.png', timeTag, epsVal);
    else
        outName = sprintf('test3_trait_marginal_%s_eps%.3g.png', timeTag, epsVal);
    end

    outFile = fullfile(outDir, outName);

    if exist('exportgraphics', 'file')
        exportgraphics(gcf, outFile, 'Resolution', 300);
    else
        print(gcf, outFile, '-dpng', '-r300');
    end

    fprintf('图片已保存：%s\n', outFile);
end

%% ========================================================================
%% 局部函数
%% ========================================================================

function fileName = find_snapshot_file(dataDir, caseName, targetTime, isDirect)
% 按目标时间自动寻找最接近的 snapshot 文件。
%
% isDirect = false:
%   baseline_..._t5.mat
%
% isDirect = true:
%   baseline_..._direct_t5.mat

    if isDirect
        pattern = fullfile(dataDir, [caseName '_direct_t*.mat']);
    else
        pattern = fullfile(dataDir, [caseName '_t*.mat']);
    end

    files = dir(pattern);

    if isempty(files)
        if isDirect
            error('没有找到 direct 中间时刻文件：%s', pattern);
        else
            error('没有找到 WKB 中间时刻文件：%s', pattern);
        end
    end

    times = NaN(numel(files), 1);

    for i = 1:numel(files)
        name = files(i).name;

        if isDirect
            token = regexp(name, '_direct_t([0-9eE+\-.]+)\.mat$', 'tokens', 'once');
        else
            token = regexp(name, '_t([0-9eE+\-.]+)\.mat$', 'tokens', 'once');
        end

        if ~isempty(token)
            times(i) = str2double(token{1});
        end
    end

    good = isfinite(times);

    if ~any(good)
        error('找到文件，但无法从文件名解析时间：%s', pattern);
    end

    files = files(good);
    times = times(good);

    [~, id] = min(abs(times - targetTime));

    fileName = fullfile(dataDir, files(id).name);

    fprintf('目标时刻 %.8g，选中文件时刻 %.8g: %s\n', ...
        targetTime, times(id), fileName);
end

function S = select_snapshot_struct(S0)
% 兼容几种保存格式：
%   S.one
%   S.direct
%   S.wkb
%   S.snapshots
%   普通结构

    S = S0;

    if isfield(S0, 'one')
        S = S0.one;
        return;
    end

    if isfield(S0, 'direct')
        S = S0.direct;
        return;
    end

    if isfield(S0, 'wkb')
        S = S0.wkb;
        return;
    end

    if isfield(S0, 'snapshots')
        snaps = S0.snapshots;
        if isempty(snaps)
            error('snapshots 为空。');
        end
        S = snaps(end);
        return;
    end
end

function val = get_from_paths(S, paths, optional, defaultVal)
% 按路径列表读取变量，例如：
%   {'n_direct','direct.n','wkb.W','par.eps'}
%
% 若 optional=true 且找不到，则返回 defaultVal。

    if nargin < 3
        optional = false;
    end
    if nargin < 4
        defaultVal = [];
    end

    for i = 1:numel(paths)
        [ok, val] = get_one_path(S, paths{i});
        if ok
            return;
        end
    end

    if optional
        val = defaultVal;
    else
        error('找不到变量。候选路径为：%s', strjoin(paths, ', '));
    end
end

function [ok, val] = get_one_path(S, path)
    ok = false;
    val = [];

    parts = strsplit(path, '.');
    cur = S;

    for i = 1:numel(parts)
        name = parts{i};

        if isstruct(cur) && isfield(cur, name)
            cur = cur.(name);
        else
            return;
        end
    end

    ok = true;
    val = cur;
end

function v = grid_vector(vRaw, whichGrid)
% 把 x/theta 网格整理成列向量。

    vRaw = double(squeeze(vRaw));

    if isvector(vRaw)
        v = vRaw(:);
        return;
    end

    if ndims(vRaw) ~= 2
        error('%s 网格不是向量或二维矩阵。', whichGrid);
    end

    col1 = vRaw(:, 1);
    row1 = vRaw(1, :);

    if numel(unique(col1)) > 1
        v = col1(:);
    elseif numel(unique(row1)) > 1
        v = row1(:);
    else
        v = unique(vRaw(:), 'stable');
        v = v(:);
    end
end

function A = to_xt_matrix(Araw, Nx, Ntheta, varName)
% 整理为 Nx x Ntheta。

    Araw = double(squeeze(Araw));

    if isvector(Araw)
        if numel(Araw) ~= Nx * Ntheta
            error('%s 是向量，但长度不是 Nx*Ntheta。', varName);
        end
        A = reshape(Araw, Nx, Ntheta);
        return;
    end

    if ndims(Araw) == 2
        if isequal(size(Araw), [Nx, Ntheta])
            A = Araw;
            return;
        elseif isequal(size(Araw), [Ntheta, Nx])
            A = Araw.';
            return;
        elseif numel(Araw) == Nx * Ntheta
            A = reshape(Araw, Nx, Ntheta);
            return;
        else
            error('%s 尺寸不匹配。size = [%s], 期望 %d x %d。', ...
                varName, num2str(size(Araw)), Nx, Ntheta);
        end
    end

    sz = size(Araw);
    dimsX = find(sz == Nx);
    dimsT = find(sz == Ntheta);

    for ix = 1:numel(dimsX)
        for it = 1:numel(dimsT)
            dx = dimsX(ix);
            dt = dimsT(it);

            if dx == dt
                continue;
            end

            perm = [dx, dt, setdiff(1:ndims(Araw), [dx, dt])];
            Ap = permute(Araw, perm);

            idx = repmat({':'}, 1, ndims(Ap));
            for d = 3:ndims(Ap)
                idx{d} = size(Ap, d);
            end

            A = squeeze(Ap(idx{:}));

            if isequal(size(A), [Nx, Ntheta])
                return;
            end
        end
    end

    error('%s 无法整理成 Nx x Ntheta。size = [%s]', ...
        varName, num2str(size(Araw)));
end

function u = to_u_array(uraw, Nx, Ntheta, varName)
% 把 u 整理成 1 x Ntheta 或 Nx x Ntheta。

    uraw = double(squeeze(uraw));

    if isvector(uraw)
        if numel(uraw) ~= Ntheta
            error('%s 是向量，但长度不是 Ntheta。', varName);
        end
        u = uraw(:).';
        return;
    end

    if ndims(uraw) == 2
        sz = size(uraw);

        if isequal(sz, [Nx, Ntheta])
            u = uraw;
            return;
        elseif isequal(sz, [Ntheta, Nx])
            u = uraw.';
            return;
        elseif sz(1) == Ntheta
            u = uraw(:, end).';
            return;
        elseif sz(2) == Ntheta
            u = uraw(end, :);
            return;
        end
    end

    u = to_xt_matrix(uraw, Nx, Ntheta, varName);
end

function n = reconstruct_wkb_density(W, u, epsVal)
% n = W exp(u/eps)

    if isvector(u)
        U = repmat(u(:).', size(W, 1), 1);
    else
        U = u;
    end

    arg = U / epsVal;
    arg = min(max(arg, -745), 700);

    n = W .* exp(arg);

    tolNeg = 1e-13 * max(1, max(abs(n(:))));
    n(n < 0 & abs(n) < tolNeg) = 0;
end

function wx = trapz_weights_from_x(x)
% 根据 x 网格构造梯形积分权重。

    x = x(:);
    Nx = numel(x);

    if Nx < 2
        error('x 网格点数太少。');
    end

    wx = zeros(Nx, 1);

    wx(1) = 0.5 * (x(2) - x(1));
    wx(end) = 0.5 * (x(end) - x(end-1));

    for j = 2:Nx-1
        wx(j) = 0.5 * (x(j+1) - x(j-1));
    end
end

function fq = weno5_periodic_interp(theta, f, thetaq, period)
% 周期 WENO5 点值重构，用于平滑画 P(theta)。

    theta = theta(:);
    f = f(:);
    thetaq = thetaq(:);

    if nargin < 4 || isempty(period)
        period = 1.0;
    end

    if numel(theta) > 2
        if abs((theta(end) - theta(1)) - period) < 1e-10 * max(1, period)
            theta = theta(1:end-1);
            f = f(1:end-1);
        end
    end

    N = numel(theta);

    if N ~= numel(f)
        error('theta 和 f 长度不一致。');
    end

    if N < 5
        thetaExt = [theta - period; theta; theta + period];
        fExt = [f; f; f];
        tq = mod(thetaq - theta(1), period) + theta(1);
        fq = interp1(thetaExt, fExt, tq, 'pchip');
        return;
    end

    a = theta(1);
    dtheta = period / N;

    fq = zeros(size(thetaq));

    scaleF = max(1, max(abs(f)));
    epsW = 1e-14 * scaleF^2 + 1e-30;

    for iq = 1:numel(thetaq)

        s = mod((thetaq(iq) - a) / dtheta, N);

        q = round(s);
        r = s - q;
        q = mod(q, N);
        i = q + 1;

        fm2 = f(wrap_index(i - 2, N));
        fm1 = f(wrap_index(i - 1, N));
        f0  = f(wrap_index(i,     N));
        fp1 = f(wrap_index(i + 1, N));
        fp2 = f(wrap_index(i + 2, N));

        p0 = lagrange3_eval(r, -2, -1,  0, fm2, fm1, f0);
        p1 = lagrange3_eval(r, -1,  0,  1, fm1, f0,  fp1);
        p2 = lagrange3_eval(r,  0,  1,  2, f0,  fp1, fp2);

        beta0 = (13/12) * (fm2 - 2*fm1 + f0)^2 ...
              + (1/4)  * (fm2 - 4*fm1 + 3*f0)^2;

        beta1 = (13/12) * (fm1 - 2*f0 + fp1)^2 ...
              + (1/4)  * (fm1 - fp1)^2;

        beta2 = (13/12) * (f0 - 2*fp1 + fp2)^2 ...
              + (1/4)  * (3*f0 - 4*fp1 + fp2)^2;

        d0 = r^2/12 - r/4 + 1/6;
        d1 = 2/3 - r^2/6;
        d2 = r^2/12 + r/4 + 1/6;

        a0 = d0 / (epsW + beta0)^2;
        a1 = d1 / (epsW + beta1)^2;
        a2 = d2 / (epsW + beta2)^2;

        asum = a0 + a1 + a2;

        w0 = a0 / asum;
        w1 = a1 / asum;
        w2 = a2 / asum;

        fq(iq) = w0*p0 + w1*p1 + w2*p2;
    end
end

function id = wrap_index(id, N)
    id = mod(id - 1, N) + 1;
end

function y = lagrange3_eval(x, x0, x1, x2, y0, y1, y2)
    L0 = (x - x1) * (x - x2) / ((x0 - x1) * (x0 - x2));
    L1 = (x - x0) * (x - x2) / ((x1 - x0) * (x1 - x2));
    L2 = (x - x0) * (x - x1) / ((x2 - x0) * (x2 - x1));

    y = L0*y0 + L1*y1 + L2*y2;
end