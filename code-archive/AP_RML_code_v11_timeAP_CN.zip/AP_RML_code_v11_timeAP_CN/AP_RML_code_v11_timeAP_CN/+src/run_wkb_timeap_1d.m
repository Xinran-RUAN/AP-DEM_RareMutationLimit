function result = run_wkb_timeap_1d(par)
%RUN_WKB_TIMEAP_1D  v11 实验版 WKB 时间积分器。
%
%  本函数实现用户要求测试的两个方向：
%
%  方案 1：par.timeIntegrator = 'implicit-coupled'
%    全隐式耦合 Picard 时间步。每个大时间步内用 Picard 迭代同时更新
%    rho^{n+1}, H^{n+1}, u^{n+1}, W^{n+1}。这样做的目的不是求稳态，
%    而是在 time evolution 中避免简单冻结 H^n 带来的 O(dt) 相位误差。
%
%  方案 3：par.timeIntegrator = 'projective'
%    projective / micro-macro 时间积分。先用若干 micro steps 解析 O(eps)
%    快松弛层，然后对慢变量做宏步外推。默认只外推 phase u 的形状，
%    W 作为快变量保留在 micro-relaxed 状态，避免 log(W) 外推导致爆炸。
%
%  两个方案都保持 WKB 框架：主变量始终是 W 和 u。代码中出现的重构密度
%  rho 只用于计算非局部项和诊断，不作为主要求解变量。
%
%  重要提醒：这两个算法是研究/排错版，不是已经证明的 time-AP 格式。
%  它们的作用是帮助判断：小 epsilon 下的失败到底来自 H(t) 冻结误差、
%  快层没有解析，还是来自 rho 重构/相位峰欠解析。

par = local_preconfigure(par);
[W, u, D, Kx, grid] = model.initial_wkb_1d(par);
op = src.build_operators_1d(grid);
variant = local_normalize_variant(par.amplitudeVariant);
timeIntegrator = lower(char(par.timeIntegrator));

par.outdir = utils.ensure_dir(par.outdir);
tag = utils.build_tag(par);
prog = utils.progress_init('WKB-1D', par);
lp = utils.liveplot_init_1d(par, 'wkb');
livePlotEverySteps = local_every_steps(par, 'livePlotEverySteps', 'livePlotEveryTime', 1.0);
historyEverySteps = local_every_steps(par, 'historyEverySteps', 'historyEveryTime', 0.5);

history = [];
t = 0;
step = 0;
residual = Inf;
failed = false;
failureReason = '';
lastInfo = struct();
lastPlotState = struct();

while t < par.T && step < par.maxSteps
    Wold = W;
    uold = u;
    [rhoOld, ~] = src.reconstruct_rho_1d(Wold, uold, par.eps, op, par.rhoReconstruction);
    HrawOld = src.solve_H_fd_1d(D, Kx, rhoOld, op);
    [Hold, ~] = src.shift_effective_hamiltonian_1d(HrawOld, par);
    [dtStep, dtInfo] = src.select_wkb_time_step_1d(par, t, Wold, uold, D, Kx, rhoOld, Hold, op, variant);
    if dtStep <= 0 || ~isfinite(dtStep)
        failed = true;
        failureReason = '时间步 dtStep 非正或非有限';
        break;
    end

    switch timeIntegrator
        case {'implicit-coupled','fully-implicit-coupled','coupled-implicit'}
            [Wtry, utry, stepInfo] = local_step_implicit_coupled(Wold, uold, D, Kx, dtStep, op, par, variant);
        case {'projective','micro-macro','projective-micro'}
            [Wtry, utry, stepInfo] = local_step_projective(Wold, uold, D, Kx, dtStep, op, par, variant);
        otherwise
            error('run_wkb_timeap_1d should not be called for timeIntegrator="%s".', timeIntegrator);
    end

    if stepInfo.failed
        failed = true;
        failureReason = stepInfo.failureReason;
        break;
    end

    W = Wtry;
    u = utry;
    t = t + dtStep;
    step = step + 1;

    % 每个宏步结束后，用当前状态重新计算 rho/H/diagnostics。
    [rhoNow, nNow, rhoInfo] = src.reconstruct_rho_1d(W, u, par.eps, op, par.rhoReconstruction);
    HrawNow = src.solve_H_fd_1d(D, Kx, rhoNow, op);
    [HNow, hGaugeInfo] = src.shift_effective_hamiltonian_1d(HrawNow, par);

    residualMode = lower(local_get_string(par, 'residualMode', 'wkb-steady'));
    [updateResidual, resInfo] = src.compute_wkb_residual_1d(W, u, Wold, uold, par.eps, dtStep, op, 'scaled-gauge-invariant');
    steadyInfo = src.compute_wkb_steady_residual_1d(W, u, D, Kx, rhoNow, HNow, par.eps, op, par, variant);
    if any(strcmp(residualMode, {'wkb-steady','steady','steady-wkb'}))
        residual = steadyInfo.res_wkb_steady;
    else
        residual = updateResidual;
    end

    dtInfo.dt = dtStep;
    dtInfo.timeIntegratorCode = local_integrator_code(timeIntegrator);
    if isfield(stepInfo,'numRetries'), dtInfo.numRetries = stepInfo.numRetries; end

    dg = src.compute_diagnostics_1d(W, u, D, Kx, rhoNow, HNow, par.eps, op, par, variant);
    monInfo = src.monitor_wkb_small_eps_1d(W, u, Wold, uold, par.eps, dtStep, op, par, stepInfo.ampInfo, dtInfo, steadyInfo);
    % 字段名兼容 utils.append_history / progress_update。
    monInfo.neighborJumpOverEps = monInfo.maxNeighborJumpOverEps;
    if isfield(monInfo,'WMax'), monInfo.W_max = monInfo.WMax; end
    if isfield(stepInfo,'ampInfo') && isstruct(stepInfo.ampInfo)
        ampInfo = stepInfo.ampInfo;
    else
        ampInfo = struct();
    end
    dg = local_merge_structs(dg, hGaugeInfo, steadyInfo, monInfo, ampInfo, stepInfo);
    dg.rhoReconstructLogMax = get_field(rhoInfo,'logrhoMax',NaN);
    dg.rhoReconstructNumCappedHigh = get_field(rhoInfo,'numCappedHigh',get_field(rhoInfo,'numCappedRhoHigh',0));

    if step == 1 || mod(step, historyEverySteps) == 0 || residual <= par.tol || get_field(stepInfo,'forceHistory',0) > 0
        history = utils.append_history(history, t, residual, dg, resInfo, dtInfo);
        lastInfo = local_progress_info(dg, resInfo, dtInfo, timeIntegrator);
        lastPlotState = local_make_plot_state(W, u, nNow, rhoNow, HNow, Kx, op, par, t, step, residual, dg);
    end

    prog = utils.progress_update(prog, step, t, residual, lastInfo);

    if lp.enabled && ~isempty(fieldnames(lastPlotState)) && ...
            (step == 1 || mod(step, livePlotEverySteps) == 0 || residual <= par.tol)
        lastPlotState.saveFrame = isfield(par, 'livePlotSave') && par.livePlotSave;
        lp = utils.liveplot_update_1d(lp, 'wkb', lastPlotState);
        if isfield(par, 'livePlotPause') && par.livePlotPause > 0
            pause(par.livePlotPause);
        end
    end

    if par.stopByResidual && isfinite(residual) && residual <= par.tol
        break;
    end

    if any(~isfinite(W(:))) || any(~isfinite(u(:))) || ~isfinite(residual)
        failed = true;
        failureReason = '宏步结束后 W/u/residual 出现 NaN/Inf';
        break;
    end
end

try
    [rho, n] = src.reconstruct_rho_1d(W, u, par.eps, op, par.rhoReconstruction);
    Hraw = src.solve_H_fd_1d(D, Kx, rho, op);
    [H, hGaugeInfoFinal] = src.shift_effective_hamiltonian_1d(Hraw, par);
    diagInfo = src.compute_diagnostics_1d(W, u, D, Kx, rho, H, par.eps, op, par, variant);
    steadyFinal = src.compute_wkb_steady_residual_1d(W, u, D, Kx, rho, H, par.eps, op, par, variant);
    diagInfo = local_merge_structs(diagInfo, hGaugeInfoFinal, steadyFinal);
catch ME
    rho = NaN(op.nx,1); n = NaN(op.nx,op.Ntheta); H = NaN(1,op.Ntheta);
    diagInfo = struct('theta_wkb',NaN,'err_wkb_to_m',NaN,'sigma_theta',NaN, ...
        'rho_max',Inf,'gammaR',Inf,'failureReason',['final diagnostics failed: ' ME.message]);
    residual = Inf;
end
if failed
    diagInfo.failed = true;
    diagInfo.failureReason = failureReason;
    if par.verbose
        fprintf('\n[WKB-1D] 警告：实验版时间积分器提前停止。原因: %s\n', failureReason);
    end
else
    diagInfo.failed = false;
    diagInfo.failureReason = '';
end

result = struct('W',W,'u',u,'n',n,'rho',rho,'H',H,'D',D,'Kx',Kx,'grid',grid, ...
                'op',op,'par',par,'t',t,'step',step,'residual',residual, ...
                'history',history,'diagnostics',diagInfo,'tag',tag,'variant',variant, ...
                'timeIntegrator',timeIntegrator);

utils.progress_finish(prog, step, t, residual, local_progress_info(diagInfo, struct(), struct(), timeIntegrator));
outfile = fullfile(par.outdir, [tag '_final.mat']);
save(outfile, '-struct', 'result');
if par.verbose
    fprintf('[WKB-1D] 结果已保存: %s\n', outfile);
end
utils.liveplot_finish_1d(lp);
end

%==========================================================================
% 方案 1：全隐式耦合 Picard
%==========================================================================
function [Wnew, unew, info] = local_step_implicit_coupled(Wold, uold, D, Kx, dt, op, par, variant)
% 在一个宏步内求解近似固定点：
%   rho^* = R[W^*,u^*], H^*=H(rho^*),
%   (W^*,u^*) = Step(W^n,u^n; rho^*,H^*).
% 这不是直接求稳态，而是全隐式时间步。Picard 迭代收敛后，H 使用的是
% 当前时间层的 rho，而不是旧时间层的 rho。
info = struct('failed',false,'failureReason','','implicitIter',0, ...
              'implicitRelChange',Inf,'implicitConverged',0,'numRetries',0);
maxIter = round(local_get_num(par,'implicitMaxIter',12));
tol = local_get_num(par,'implicitTol',1e-7);
relax = local_get_num(par,'implicitRelax',0.7);
minIter = round(local_get_num(par,'implicitMinIter',2));
relax = min(max(relax, 0.05), 1.0);

Wguess = Wold;
uguess = uold;
Wnew = Wold;
unew = uold;
lastStepInfo = struct();

for it = 1:maxIter
    [rhoGuess, ~] = src.reconstruct_rho_1d(Wguess, uguess, par.eps, op, par.rhoReconstruction);
    if any(~isfinite(rhoGuess(:)))
        info.failed = true;
        info.failureReason = 'implicit Picard 中 rhoGuess 出现 NaN/Inf';
        return;
    end
    Hraw = src.solve_H_fd_1d(D, Kx, rhoGuess, op);
    if any(~isfinite(Hraw(:)))
        info.failed = true;
        info.failureReason = 'implicit Picard 中 H 特征值计算失败';
        return;
    end
    [Hguess, hInfo] = src.shift_effective_hamiltonian_1d(Hraw, par);
    [Wcand, ucand, oneInfo] = src.wkb_one_step_frozenH_1d(Wold, uold, D, Kx, rhoGuess, Hguess, par.eps, dt, op, par, variant);
    lastStepInfo = oneInfo;
    if oneInfo.failed
        info.failed = true;
        info.failureReason = ['implicit Picard 一步算子失败: ' oneInfo.failureReason];
        info.ampInfo = oneInfo.ampInfo;
        return;
    end

    % Picard 欠松弛。这里的混合仅用于非线性迭代，不是额外物理模型。
    Wmix = (1-relax)*Wguess + relax*Wcand;
    umix = (1-relax)*uguess + relax*ucand;
    Wmix = max(real(Wmix), 0);
    [Wmix, umix] = src.normalize_gauge(Wmix, umix, par.eps, 'max');

    relU = max(abs(umix(:)-uguess(:))) / max(1, max(abs(umix(:))));
    relW = max(abs(Wmix(:)-Wguess(:))) / max(1, max(abs(Wmix(:))));
    rel = max(relU, relW);

    Wguess = Wmix;
    uguess = umix;
    Wnew = Wguess;
    unew = uguess;

    info.implicitIter = it;
    info.implicitRelChange = rel;
    info.HrawMinImplicit = get_field(hInfo,'HrawMin',NaN);
    info.HrawMaxImplicit = get_field(hInfo,'HrawMax',NaN);

    if it >= minIter && rel < tol
        info.implicitConverged = 1;
        break;
    end
end

if info.implicitConverged == 0
    failTol = local_get_num(par,'implicitFailureTol',5e-2);
    if local_get_bool(par,'implicitRetryOnFail',true) && info.implicitRelChange > failTol
        info.failed = true;
        info.failureReason = sprintf('implicit Picard 未充分收敛: rel=%.3g', info.implicitRelChange);
        return;
    end
end

if isfield(lastStepInfo,'ampInfo')
    info.ampInfo = lastStepInfo.ampInfo;
else
    info.ampInfo = struct();
end
info.forceHistory = double(info.implicitConverged == 0);
end

%==========================================================================
% 方案 3：projective / micro-macro
%==========================================================================
function [Wnew, unew, info] = local_step_projective(Wold, uold, D, Kx, dtMacro, op, par, variant)
% 先用 micro steps 解析快层，再对慢变量投影。默认 mode='u-only'：
%   - W 在 micro-relaxed 状态停止，不做大步外推；
%   - u 的形状用最后两个 micro steps 的差分外推；
% 这样比同时外推 log(W) 更稳健，也更符合“W 是快变量、u 是慢相位”的
% micro-macro 思路。
info = struct('failed',false,'failureReason','','projectiveMicroStepsUsed',0, ...
              'projectiveMicroDt',NaN,'projectiveRemainingDt',NaN, ...
              'projectiveModeCode',0,'numRetries',0);

mode = lower(local_get_string(par,'projectiveMode','u-only'));
M = max(2, round(local_get_num(par,'projectiveMicroSteps',8)));
corrector = max(0, round(local_get_num(par,'projectiveCorrectorSteps',0)));

% 根据当前 H/rho 估计 micro dt。这里允许 macro dt 与 eps 无关，但 micro dt
% 必须能解析 O(eps) 快层。注意总的 micro+corrector 时间不能超过宏步 dtMacro，
% 否则 projective 步会悄悄多走物理时间；因此后面会再次截断 dtm。
[rho0, ~] = src.reconstruct_rho_1d(Wold, uold, par.eps, op, par.rhoReconstruction);
Hraw0 = src.solve_H_fd_1d(D, Kx, rho0, op);
[H0, ~] = src.shift_effective_hamiltonian_1d(Hraw0, par);
scale = max([1, max(abs(H0(:))), max(max(Kx(:)-rho0(:),0))]);
dtm = local_get_num(par,'projectiveMicroDtFactor',0.25) * par.eps / scale;
dtm = max(dtm, local_get_num(par,'projectiveMinMicroDt',1e-12));
dtm = min(dtm, local_get_num(par,'projectiveMaxMicroDt',Inf));
% 保证 M 个 micro steps 加 corrector steps 的物理时间不超过宏步。
dtm = min(dtm, dtMacro / max(M + corrector, 1));
if ~(isfinite(dtm) && dtm > 0)
    info.failed = true;
    info.failureReason = 'projective micro dt 非正或非有限';
    return;
end

Wprev = Wold; uprev = uold;
Wcur = Wold; ucur = uold;
ampInfoLast = struct();

for m = 1:M
    Wbefore = Wcur;
    ubefore = ucur;
    [rhoM, ~] = src.reconstruct_rho_1d(Wcur, ucur, par.eps, op, par.rhoReconstruction);
    HMraw = src.solve_H_fd_1d(D, Kx, rhoM, op);
    [HM, ~] = src.shift_effective_hamiltonian_1d(HMraw, par);
    [Wnext, unext, oneInfo] = src.wkb_one_step_frozenH_1d(Wcur, ucur, D, Kx, rhoM, HM, par.eps, dtm, op, par, variant);
    if oneInfo.failed
        info.failed = true;
        info.failureReason = ['projective micro step 失败: ' oneInfo.failureReason];
        info.ampInfo = oneInfo.ampInfo;
        return;
    end
    Wprev = Wbefore; uprev = ubefore;
    Wcur = Wnext; ucur = unext;
    ampInfoLast = oneInfo.ampInfo;
end

microTime = M * dtm;
rem = max(dtMacro - (M + corrector) * dtm, 0);
info.projectiveMicroStepsUsed = M;
info.projectiveMicroDt = dtm;
info.projectiveRemainingDt = rem;

% gauge-invariant 相位差分：去掉两个 micro 状态的常数 gauge，只外推形状。
up = uprev(:).' - max(uprev(:));
uc = ucur(:).' - max(ucur(:));
du = (uc - up) / dtm;
clipU = local_get_num(par,'projectiveDerivativeClipU',50);
du = min(max(du, -clipU), clipU);

unew = ucur + rem * du;
Wnew = Wcur;
info.projectiveModeCode = 1;

if any(strcmp(mode, {'u-logw','logw','full'}))
    % 可选：同时外推 log(W)。这更激进，可能更快，但也更容易在小 epsilon
    % 下制造指数跨度；因此不是默认。
    floorW = max(local_get_num(par,'WFloor',realmin), realmin);
    lwp = log(max(Wprev, floorW));
    lwc = log(max(Wcur, floorW));
    dlw = (lwc - lwp) / dtm;
    clipLW = local_get_num(par,'projectiveDerivativeClipLogW',50);
    dlw = min(max(dlw, -clipLW), clipLW);
    logWnew = lwc + rem * dlw;
    logWnew = min(max(logWnew, -650), 650);
    Wnew = exp(logWnew);
    info.projectiveModeCode = 2;
end

% 常数 gauge 归一化，不改变重构密度。
[Wnew, unew] = src.normalize_gauge(Wnew, unew, par.eps, 'max');

% 外推后做少量 micro corrector，让 W 与新的 u/rho 重新靠近快流形。
for c = 1:corrector
    [rhoC, ~] = src.reconstruct_rho_1d(Wnew, unew, par.eps, op, par.rhoReconstruction);
    HCraw = src.solve_H_fd_1d(D, Kx, rhoC, op);
    [HC, ~] = src.shift_effective_hamiltonian_1d(HCraw, par);
    [Wnew, unew, oneInfo] = src.wkb_one_step_frozenH_1d(Wnew, unew, D, Kx, rhoC, HC, par.eps, min(dtm,dtMacro), op, par, variant);
    if oneInfo.failed
        info.failed = true;
        info.failureReason = ['projective corrector 失败: ' oneInfo.failureReason];
        info.ampInfo = oneInfo.ampInfo;
        return;
    end
    ampInfoLast = oneInfo.ampInfo;
end

if any(~isfinite(Wnew(:))) || any(~isfinite(unew(:)))
    info.failed = true;
    info.failureReason = 'projective 宏步结束后 W/u 出现 NaN/Inf';
end
info.ampInfo = ampInfoLast;
info.forceHistory = 1;
end

%==========================================================================
% 工具函数
%==========================================================================
function par = local_preconfigure(par)
if ~isfield(par,'rhoReconstruction') || isempty(par.rhoReconstruction)
    par.rhoReconstruction = 'laplace-hybrid';
end
if isfield(par,'eps') && par.eps <= 1e-4 && any(strcmpi(par.rhoReconstruction, {'direct','direct-log'}))
    par.rhoReconstruction = 'laplace-hybrid';
    fprintf('[WKB-1D] 小 epsilon 检测：实验版时间积分器自动使用 laplace-hybrid 重构 rho。\n');
end
if ~isfield(par,'reactionDiscretization') || isempty(par.reactionDiscretization)
    par.reactionDiscretization = 'logistic-exact';
end
if ~isfield(par,'ifMode') || isempty(par.ifMode)
    par.ifMode = 'h-only';
end
if ~isfield(par,'hamiltonianGauge') || isempty(par.hamiltonianGauge)
    par.hamiltonianGauge = 'min';
end
if ~isfield(par,'thetaRephase') || isempty(par.thetaRephase)
    par.thetaRephase = false;
end
end

function variant = local_normalize_variant(name)
name = lower(char(name));
switch name
    case {'wkb-if-split','wkb-if','balanced-wkb-if'}
        variant = 'wkb-if-split';
    case {'split-if','balanced-split','if-split'}
        variant = 'split-if';
    case {'split','split-wkb'}
        variant = 'split';
    case {'density-compatible','dc','density-compatible-if','dc-if','density-if','integrating-factor'}
        variant = 'wkb-if-split';
    case {'density-compatible-semidiscrete','dc-semidiscrete','density-compatible-old','dc-old'}
        variant = 'density-compatible-semidiscrete';
    otherwise
        error('Unknown amplitudeVariant "%s".', name);
end
end

function n = local_every_steps(par, fieldSteps, fieldTime, defaultTime)
if isfield(par, fieldSteps) && ~isempty(par.(fieldSteps)) && isnumeric(par.(fieldSteps)) && isscalar(par.(fieldSteps)) && par.(fieldSteps) > 0
    n = max(1, round(par.(fieldSteps)));
elseif isfield(par, fieldTime) && ~isempty(par.(fieldTime)) && isnumeric(par.(fieldTime)) && isscalar(par.(fieldTime)) && par.(fieldTime) > 0
    n = max(1, round(par.(fieldTime) / par.dt));
else
    n = max(1, round(defaultTime / par.dt));
end
end

function state = local_make_plot_state(W, u, n, rho, H, Kx, op, par, t, step, residual, dg)
state = struct();
state.W = real(W);
state.u = real(u);
state.n = real(n);
state.rho = real(rho);
state.H = real(H);
state.Kx = real(Kx);
state.x = op.x;
state.theta = op.theta;
state.P = real(dg.P);
state.theta_peak = dg.theta_wkb;
state.theta_m = par.theta_m;
state.sigma_theta = dg.sigma_theta;
state.gammaR = dg.gammaR;
state.rho_max = dg.rho_max;
state.residual = residual;
state.t = t;
state.T = par.T;
state.step = step;
state.saveFrame = false;
end

function info = local_progress_info(dg, resInfo, dtInfo, timeIntegrator)
if nargin < 2 || isempty(resInfo), resInfo = struct(); end
if nargin < 3 || isempty(dtInfo), dtInfo = struct(); end
if nargin < 4, timeIntegrator = ''; end
info = struct();
if isstruct(dg)
    info.theta_wkb = get_field(dg,'theta_wkb',NaN);
    info.theta_direct = get_field(dg,'theta_direct',NaN);
    info.err_wkb_to_m = get_field(dg,'err_wkb_to_m',NaN);
    info.sigma_theta = get_field(dg,'sigma_theta',NaN);
    info.gammaR = get_field(dg,'gammaR',NaN);
    info.rho_max = get_field(dg,'rho_max',NaN);
    info.Hmin = get_field(dg,'Hmin',NaN);
    info.res_phase_steady = get_field(dg,'res_phase_steady',NaN);
    info.res_density_steady = get_field(dg,'res_density_steady',NaN);
    info.res_amp_w_steady = get_field(dg,'res_amplitude_steady',get_field(dg,'res_amp_w_steady',NaN));
    info.phaseCFL = get_field(dg,'phaseCFL',NaN);
    info.jumpEps = get_field(dg,'neighborJumpOverEps',NaN);
    info.peakGrid = get_field(dg,'peakWidthOverGrid',NaN);
    info.logQMax = get_field(dg,'logQMax',NaN);
    info.seedLogRange = get_field(dg,'seedLogRange',NaN);
    info.reactionScaleMax = get_field(dg,'reactionScaleMax',NaN);
    info.implicitIter = get_field(dg,'implicitIter',NaN); %#ok<STRNU>
    info.implicitRelChange = get_field(dg,'implicitRelChange',NaN); %#ok<STRNU>
    info.projectiveMicroStepsUsed = get_field(dg,'projectiveMicroStepsUsed',NaN); %#ok<STRNU>
    info.projectiveMicroDt = get_field(dg,'projectiveMicroDt',NaN); %#ok<STRNU>
end
if isstruct(resInfo)
    if isfield(resInfo,'res_n'), info.res_n = resInfo.res_n; end
    if isfield(resInfo,'res_u'), info.res_u = resInfo.res_u; end
    if isfield(resInfo,'res_W_legacy'), info.res_W_legacy = resInfo.res_W_legacy; end
end
if isstruct(dtInfo)
    info.dt = get_field(dtInfo,'dt',NaN);
    info.lambdaR = get_field(dtInfo,'lambdaR',NaN);
    info.lambdaH = get_field(dtInfo,'lambdaH',NaN);
    info.ifLogRangeEstimate = get_field(dtInfo,'ifLogRangeEstimate',NaN);
    if isfield(dtInfo,'numRetries'), info.numRetries = dtInfo.numRetries; end
end
if ~isempty(timeIntegrator)
    info.note = ['timeIntegrator=' char(timeIntegrator)];
end
end

function c = local_integrator_code(s)
s = lower(char(s));
if any(strcmp(s, {'implicit-coupled','fully-implicit-coupled','coupled-implicit'}))
    c = 1;
elseif any(strcmp(s, {'projective','micro-macro','projective-micro'}))
    c = 3;
else
    c = 0;
end
end

function out = local_merge_structs(varargin)
out = struct();
for i = 1:nargin
    s = varargin{i};
    if ~isstruct(s), continue; end
    f = fieldnames(s);
    for j = 1:numel(f)
        out.(f{j}) = s.(f{j});
    end
end
end

function v = get_field(s, name, defaultValue)
v = defaultValue;
if isstruct(s) && isfield(s,name) && ~isempty(s.(name)) && isnumeric(s.(name)) && isscalar(s.(name))
    v = double(s.(name));
end
end

function v = local_get_num(s, name, defaultValue)
v = defaultValue;
if isstruct(s) && isfield(s,name) && ~isempty(s.(name)) && isnumeric(s.(name)) && isscalar(s.(name))
    v = double(s.(name));
end
end

function v = local_get_string(s, name, defaultValue)
v = defaultValue;
if isstruct(s) && isfield(s,name) && ~isempty(s.(name))
    v = char(s.(name));
end
end

function tf = local_get_bool(s, name, defaultValue)
tf = defaultValue;
if isstruct(s) && isfield(s,name) && ~isempty(s.(name))
    tf = logical(s.(name));
end
end
