function par = default_params_1d(profile)
%DEFAULT_PARAMS_1D 一维 WKB/direct 程序的默认参数。
%   profile = 'baseline'      文档中的基准算例；
%   profile = 'heterogeneous' 非平凡非均匀算例。
%
%   本版本的默认设置面向小 epsilon 稳健计算：主求解器仍然推进 WKB 变量
%   (W,u)，并没有回到原始密度方程。小 epsilon 下的病态通过时间积分因子、
%   H 的标量 gauge 平移、well-prepared 初始质量和诊断监测来处理。

if nargin < 1 || isempty(profile)
    profile = 'baseline';
end
par.profile = profile;

%-------------------------
% 网格和时间推进参数
%-------------------------
par.Nx = 80;                  % x 方向子区间数；实际节点数为 Nx+1
par.Ntheta = 64;              % 周期 trait 网格点数
par.dt = 1e-3;                % 时间步长；若启用自适应时间步，它作为最大时间步
par.T = 20;                   % 终止时间
par.maxSteps = Inf;           % 额外最大步数；Inf 表示只受 T 控制
par.tol = 1e-8;               % 停止阈值
par.saveEvery = Inf;          % 预留字段
par.outdir = utils.output_dir(profile);

%-------------------------
% 小突变参数和初值参数
%-------------------------
par.eps = 1e-2;
par.theta0 = 0.70;            % 初始相位峰值位置，故意与 theta_m 不同
par.alpha0 = 0.05;            % 初始相位宽度参数
par.initialPhaseMode = 'peaked';    % 'peaked': 光滑峰；'flat': u=0，适合排查小 epsilon 快层
par.prepareInitialMass = true;      % true: 只缩放 W，使初始 rho 为 O(1)，避免近空种群初始快层
par.initialRhoProfile = 'scaledK';  % 'scaledK', 'constant', 或 'current'
par.initialRhoScale = 0.5;          % scaledK: rho0≈0.5*K(x)；constant: rho0≈0.5

%-------------------------
% v11 时间积分器实验选项
%-------------------------
% 'frozen'            : 原来的时间推进；H=H(rho^n) 在一个时间步内冻结。
% 'implicit-coupled'  : 方案 1，全隐式耦合 Picard。每个大时间步内迭代更新
%                       rho^{n+1}, H^{n+1}, u^{n+1}, W^{n+1}，用于测试
%                       是否可以减弱 H(t) 冻结误差。
% 'projective'        : 方案 3，micro-macro/projective。先用若干小步解析
%                       O(eps) 快层，再对慢变量做外推。
par.timeIntegrator = 'frozen';

% 方案 1：全隐式耦合 Picard 参数。
par.implicitMaxIter = 12;               % 每个时间步最大 Picard 迭代次数
par.implicitTol = 1e-7;                 % Picard 相对变化停止阈值
par.implicitRelax = 0.7;                % 欠松弛系数；小 epsilon 下建议 0.3--0.8
par.implicitMinIter = 2;                % 至少迭代次数，避免第一轮偶然停止
par.implicitRetryOnFail = true;         % Picard 不收敛或试探步失败时缩小 dt 重试
par.implicitFailureTol = 5e-2;          % 若最终相对变化大于该值，可触发拒步

% 方案 3：projective / micro-macro 参数。
par.projectiveMicroSteps = 8;           % 每个宏步前的小步数
par.projectiveMicroDtFactor = 0.25;     % micro dt = factor*eps / scale
par.projectiveMinMicroDt = 1e-12;       % micro dt 下限
par.projectiveMaxMicroDt = Inf;         % micro dt 上限；Inf 表示不限制
par.projectiveMode = 'u-only';          % 'u-only' 或 'u-logw'；默认只外推相位
par.projectiveDerivativeClipU = 50;     % 外推 u_t 的安全截断
par.projectiveDerivativeClipLogW = 50;  % 外推 log(W)_t 的安全截断
par.projectiveCorrectorSteps = 0;       % 外推后再做几个小步校正，防止偏离慢流形
par.projectiveUseMacroRhoRefresh = true;% 外推后重构 rho/H 作为诊断

%-------------------------
% WKB 数值格式选择
%-------------------------
par.phaseHamiltonian = 'godunov';
par.lfAlpha = 10;

% 新版默认 wkb-if-split：仍然求解 W 和 u，只对 W 方程时间零阶刚性作积分因子处理。
% 兼容旧脚本时，run_wkb_1d 会把 'density-compatible-if' 也导向该 WKB-IF 格式，
% 避免小 epsilon 下构造 exp((u_{k+1}-u_k)/eps) 的指数比值矩阵。
par.amplitudeVariant = 'wkb-if-split';
par.reactionDiscretization = 'logistic-exact'; % 小 epsilon 默认：在 W 上作 exact logistic 反应缩放；不求解 n 方程
par.transportImplicit = true;
par.rhoReconstruction = 'laplace-hybrid'; % 小 epsilon 推荐：用 Laplace 重构 rho，避免粗 theta 网格下直接求和失真
par.residualMode = 'wkb-steady'; % 直接监测 WKB 稳态方程；单步 residual 仍另存 history

%-------------------------
% 小 epsilon 稳健化选项
%-------------------------
par.expClip = 700;
par.gaugeMode = 'auto';              % 'auto': WKB-IF 不强制 max-gauge；旧格式用 max-gauge
par.ifGaugeBalance = true;           % 保留旧字段
par.ifGaugeStrategy = 'phase-peak';   % 只做常数 gauge，把二次插值峰值规范到 0
par.ifRhsLogTarget = [];             % 为空时自动取 max(log(10),-0.5log(eps))
par.ifRhsLogClip = 120;               % 旧字段；v8 中主要由 ifSeedLogAbsMax/RangeMax 触发拒步重试
par.ifSeedLogAbsMax = 600;            % 仅在接近双精度溢出时才拒步
par.ifSeedLogRangeMax = 500;          % log(qW) 跨度主要作为诊断量
par.rejectOnSeedLogRange = false;     % v10 默认不因 W 的自然指数跨度直接拒步
par.ifRhsLogHardClip = 650;           % 防止 MATLAB 中间溢出
par.clipNegativeW = true;            % 将线性求解造成的极小负 W 截断
par.WFloor = 0;
par.monitorMatrixCondition = false;  % true: 对振幅矩阵做 condest，排错有用但更慢
par.enableSmallEpsMonitor = true;    % 记录 logQ、phaseCFL、峰宽/网格比等诊断量
par.monitorWarnThreshold = 80;

% v10 关键修正：只使用 H 的标量 gauge 平移，不使用 theta 依赖 rephase。
% theta 依赖 rephase 虽可保持 n 不变，但会改变 u_theta，进而污染 fittest trait 定位。
% hamiltonianGauge='min' 表示在 phase 和 amplitude 中统一使用 H-min(H)，
% 去掉 H 的公共偏移，避免 exp(dt*H/eps) 的无意义整体刚性。
par.hamiltonianGauge = 'min';
par.thetaRephase = false;
par.thetaRephaseStatistic = 'median';
par.thetaRephaseSmoothPasses = 0;
par.thetaRephaseMaxAbsShift = 0;
par.thetaRephaseUsePeakGauge = false;

par.ifMode = 'h-only';                 % 只对平移后的 H 项作积分因子
par.reactionScaleMaxAllowed = 1e8;     % exact reaction 缩放保护，仅防止极端下溢/上溢
par.reactionScaleMinAllowed = 1e-8;
par.reactionScaleRetryLimit = 1e4;    % 若一次反应缩放超过此量级，则优先缩步重试
par.adaptiveIfLogRange = true;       % 限制 IF 指数在 theta 间的相对跨度，防止 W 振幅指数分离
par.ifLogRangeMax = 80;              % 允许的 max(log q)-min(log q)；超过则自动缩小 dt
par.rhoBlowupThreshold = 1e100;        % 若超过该阈值，判定计算失败而不是误报收敛
par.rhoLogRetryMax = 120;             % 若重构 rho 的 log 尺度过大，拒绝本步并缩小 dt
par.enableStepRetry = true;           % 试探步若出现病态，自动拒绝并缩小 dt 后重试
par.maxStepRetries = 12;              % 每个物理时间步最多重试次数
par.retryDtFactor = 0.5;              % 每次拒步后的 dt 缩小比例
par.dtMinRetry = 1e-12;               % 拒步重试允许的最小 dt

%-------------------------
% 可选自适应时间步
%-------------------------
par.adaptiveTimeStep = false;
par.adaptiveStrategy = 'auto';       % WKB-IF 下 auto=phase-cfl；旧格式 auto=eps-source
par.adaptiveSafety = 0.5;
par.phaseCflSafety = 0.45;
par.dtMax = [];
par.dtMin = 0;

%-------------------------
% 停止、快照和进度输出控制
%-------------------------
par.stopByResidual = true;
par.storeSnapshots = true;
par.snapshotTimes = [];
par.verbose = true;
par.progressEveryPercent = 5;
par.progressEverySeconds = 10;
par.progressEverySteps = [];
par.historyEveryTime = 0.5;
par.historyEverySteps = [];

%-------------------------
% 运行中图像监测控制
%-------------------------
par.livePlot = false;
par.livePlotMode = 'monitor';
par.livePlotEveryTime = 0.5;
par.livePlotEverySteps = [];
par.livePlotSave = false;
par.livePlotPause = 0.0;

%-------------------------
% 系数函数。baseline 对应文档中的主算例。
%-------------------------
switch lower(profile)
    case 'baseline'
        theta_m = 0.35;
        K0 = 1.0;
        K1 = 0.5;
        Dmin = 0.2;
        D1 = 0.4;
        par.theta_m = theta_m;
        par.K0 = K0;
        par.K1 = K1;
        par.Dmin = Dmin;
        par.D1 = D1;
        par.K_fun = @(x) K0 + K1 * cos(2*pi*x);
        par.D_fun = @(theta) Dmin + D1 * (1 - cos(2*pi*(theta - theta_m)));
    case 'heterogeneous'
        theta_m = 0.25;
        par.theta_m = theta_m;
        par.K_fun = @(x) 1 + 0.35*cos(2*pi*x) + 0.20*cos(4*pi*x);
        par.D_fun = @(theta) 0.15 + 0.35*(1 - cos(2*pi*(theta - theta_m))) + ...
                             0.08*(1 - cos(4*pi*(theta - theta_m)));
    otherwise
        error('Unknown profile "%s".', profile);
end
end
