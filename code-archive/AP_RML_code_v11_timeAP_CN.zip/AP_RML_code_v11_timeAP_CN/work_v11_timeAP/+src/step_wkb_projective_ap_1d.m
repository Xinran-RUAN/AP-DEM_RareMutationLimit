function [Wnew, unew, info] = step_wkb_projective_ap_1d(Wold, uold, D, Kx, dtMacro, op, par, variant)
%STEP_WKB_PROJECTIVE_AP_1D  projective / micro-macro AP 试验时间推进。
%
%  目的：
%  -----------------------------------------------------------------------
%  原动态方程在 eps->0 时含有 O(eps) 快松弛层。若直接用一个大步长 dtMacro
%  推进，旧格式相当于用大步长跨过快层，容易得到错误的 rho/H/u 演化。
%
%  projective 思路是：
%    1. 先用若干个 O(eps) 的微步解析快松弛；
%    2. 用最后两个微步估计慢变量的时间导数；
%    3. 对剩余的大时间间隔做投影外推。
%
%  本函数是试验实现，主变量仍然是 W 和 u：
%    - 对 u 作模常数外推；
%    - 对 W 的正振幅作 log(W) 外推，避免破坏非负性；
%    - 外推后再用一次很短的 WKB 单步作 correction，可选。
%
%  这不是已经证明的 AP 格式，而是用来判断“micro-macro/projective 方向”
%  是否能改善 dt>>eps 下的动态演化。

if nargin < 8 || isempty(variant)
    variant = 'wkb-if-split';
end

info = struct();
info.timeIntegratorUsed = 'projective-ap-micro-macro';
info.needsRetry = false;
info.retryReason = '';
info.projectiveAccepted = 0;

%--------------------------------------------------------------
% 1. 选择微步长。默认 dtMicro = c*eps，但也受相位 CFL 限制。
%--------------------------------------------------------------
epsv = par.eps;
M = max(2, round(local_get_num(par, 'projectiveNumMicroSteps', 6)));
microSafety = local_get_num(par, 'projectiveMicroSafety', 0.2);
dtMicroUser = local_get_num(par, 'projectiveMicroDt', NaN);
if isfinite(dtMicroUser) && dtMicroUser > 0
    dtMicro = dtMicroUser;
else
    dtMicro = microSafety * epsv;
end

% 用当前状态估计相位 CFL，防止微步自身不稳定。
try
    [rho0, ~] = src.reconstruct_rho_1d(Wold, uold, epsv, op, par.rhoReconstruction);
    H0raw = src.solve_H_fd_1d(D, Kx, rho0, op);
    [H0, ~] = src.shift_effective_hamiltonian_1d(H0raw, par);
    dtInfo0 = src.time_step_stability_info_1d(Wold, uold, Kx, rho0, H0, epsv, max(dtMicro,realmin), op, par, variant);
    if isfinite(dtInfo0.phaseSpeedMax) && dtInfo0.phaseSpeedMax > 0
        dtCfl = local_get_num(par,'phaseCflSafety',0.45) * op.dtheta / dtInfo0.phaseSpeedMax;
        dtMicro = min(dtMicro, dtCfl);
    end
catch
    % 若估计失败，不在这里终止；后面的微步会给出更明确的信息。
end

dtMicro = min(dtMicro, dtMacro);
if ~(isfinite(dtMicro) && dtMicro > 0)
    info.needsRetry = true;
    info.retryReason = 'projective 微步长非正或非有限';
    Wnew = Wold; unew = uold;
    return;
end

% 如果宏步比 M 个微步还短，则退化为若干普通小步。
if M*dtMicro >= dtMacro
    nSmall = max(1, ceil(dtMacro/dtMicro));
    dtSmall = dtMacro/nSmall;
    Wcur = Wold; ucur = uold;
    for m = 1:nSmall
        [Wcur, ucur, stepInfo] = src.wkb_single_step_1d(Wcur, ucur, D, Kx, dtSmall, op, par, variant);
        if local_get_field(stepInfo,'needsRetry',0)
            info.needsRetry = true;
            info.retryReason = ['projective 退化小步失败: ' local_get_string(stepInfo,'retryReason','')];
            Wnew = Wcur; unew = ucur;
            return;
        end
    end
    Wnew = Wcur; unew = ucur;
    info.projectiveDegeneratedToMicroSteps = true;
    info.projectiveMicroDt = dtSmall;
    info.projectiveNumMicroStepsUsed = nSmall;
    info.projectiveAccepted = 1;
    return;
end

%--------------------------------------------------------------
% 2. 微步 burst：从 (Wold,uold) 连续做 M 个小步。
%--------------------------------------------------------------
Wprev = Wold; uprev = uold;
Wcur = Wold; ucur = uold;
lastInfo = struct();
for m = 1:M
    Wprev = Wcur;
    uprev = ucur;
    [Wcur, ucur, stepInfo] = src.wkb_single_step_1d(Wprev, uprev, D, Kx, dtMicro, op, par, variant);
    lastInfo = stepInfo;
    if local_get_field(stepInfo,'needsRetry',0) || any(~isfinite(Wcur(:))) || any(~isfinite(ucur(:)))
        info.needsRetry = true;
        info.retryReason = ['projective 微步失败: ' local_get_string(stepInfo,'retryReason','W/u 非有限')];
        Wnew = Wcur; unew = ucur;
        return;
    end
end

%--------------------------------------------------------------
% 3. 根据最后两个微步估计慢导数。
%    u 按模常数比较，W 用 log(W) 比较。
%--------------------------------------------------------------
uprev0 = uprev - max(uprev(:));
ucur0  = ucur  - max(ucur(:));
duSlow = (ucur0 - uprev0) / dtMicro;

logWprev = log(max(real(Wprev), realmin));
logWcur  = log(max(real(Wcur),  realmin));
dlogWSlow = (logWcur - logWprev) / dtMicro;

tauProject = dtMacro - M*dtMicro;
projectiveFactor = tauProject / dtMicro;
maxFactor = local_get_num(par, 'projectiveMaxFactor', 2000);
info.projectiveFactor = projectiveFactor;
if projectiveFactor > maxFactor
    info.needsRetry = true;
    info.retryReason = sprintf('projective 外推因子过大: %.3g > %.3g', projectiveFactor, maxFactor);
    Wnew = Wcur; unew = ucur;
    return;
end

%--------------------------------------------------------------
% 4. 投影外推。
%    为避免一次外推造成指数爆炸，对 logW 的变化量做安全截断。
%--------------------------------------------------------------
maxLogIncrement = local_get_num(par, 'projectiveMaxLogWIncrement', 80);
logWIncrement = tauProject * dlogWSlow;
logWIncrement = min(max(logWIncrement, -maxLogIncrement), maxLogIncrement);
logWProj = logWcur + logWIncrement;
logWProj = min(max(logWProj, -650), 650);
Wproj = exp(logWProj);

uProj = ucur0 + tauProject * duSlow;
% u 的常数 gauge 选为 max(u)=0。注意这里只平移常数，不做 theta 依赖 rephase。
[Wproj, uProj] = src.normalize_gauge(Wproj, uProj, epsv, 'max');

info.projectiveMicroDt = dtMicro;
info.projectiveNumMicroStepsUsed = M;
info.projectiveTau = tauProject;
info.projectiveDuInf = norm(tauProject*duSlow(:), Inf);
info.projectiveLogWIncrementMax = max(logWIncrement(:));
info.projectiveLogWIncrementMin = min(logWIncrement(:));
% 合并时让 projective 外层诊断优先。
info = local_merge(lastInfo, info);

%--------------------------------------------------------------
% 5. 可选 correction：外推后用一个很短的 WKB 步重新贴近离散方程。
%    默认关闭；若打开，correctionDt 通常取 dtMicro 或更小。
%--------------------------------------------------------------
if local_get_bool(par, 'projectiveCorrection', false)
    dtCorr = min(local_get_num(par,'projectiveCorrectionDt',dtMicro), dtMicro);
    [Wcorr, ucorr, corrInfo] = src.wkb_single_step_1d(Wproj, uProj, D, Kx, dtCorr, op, par, variant);
    info = local_merge(info, corrInfo);
    info.projectiveCorrectionUsed = 1;
    if local_get_field(corrInfo,'needsRetry',0)
        info.needsRetry = true;
        info.retryReason = ['projective correction 失败: ' local_get_string(corrInfo,'retryReason','')];
        Wnew = Wproj; unew = uProj;
        return;
    end
    Wnew = Wcorr;
    unew = ucorr;
else
    info.projectiveCorrectionUsed = 0;
    Wnew = Wproj;
    unew = uProj;
end

if any(~isfinite(Wnew(:))) || any(~isfinite(unew(:)))
    info.needsRetry = true;
    info.retryReason = 'projective 外推后 W/u 出现 NaN/Inf';
else
    info.projectiveAccepted = 1;
end
end

function val = local_get_num(s, name, defaultValue)
val = defaultValue;
if isstruct(s) && isfield(s,name) && ~isempty(s.(name)) && isnumeric(s.(name)) && isscalar(s.(name))
    val = double(s.(name));
end
end

function val = local_get_string(s, name, defaultValue)
val = defaultValue;
if isstruct(s) && isfield(s,name) && ~isempty(s.(name))
    val = char(s.(name));
end
end

function tf = local_get_bool(s, name, defaultValue)
tf = defaultValue;
if isstruct(s) && isfield(s,name) && ~isempty(s.(name))
    tf = logical(s.(name));
end
end

function v = local_get_field(s, name, defaultValue)
v = defaultValue;
if isstruct(s) && isfield(s,name) && ~isempty(s.(name))
    v = s.(name);
    if isnumeric(v) && isscalar(v), v = double(v); end
end
end

function out = local_merge(varargin)
out = struct();
for i = 1:nargin
    s = varargin{i};
    if ~isstruct(s), continue; end
    f = fieldnames(s);
    for j = 1:numel(f)
        out.(f{j}) = s.(f{j});
    end
end
end
