function [Wnew, unew, info] = step_wkb_fully_implicit_coupled_1d(Wold, uold, D, Kx, dt, op, par, variant)
%STEP_WKB_FULLY_IMPLICIT_COUPLED_1D  H-rho 全隐式耦合的 WKB 试验步。
%
%  目的：
%  -----------------------------------------------------------------------
%  当前小 epsilon 动态计算失败的核心原因之一是：
%
%       H_k(t)=H_k(rho(t))
%
%  在时间步内变化，而旧格式用 H^n 冻结推进 u 与 W。由于 u 的误差会在
%  exp(u/eps) 中被 1/eps 放大，这种显式冻结会在 eps 很小时造成严重误差。
%
%  本函数实现一个“全隐式耦合”的试验版本：在同一个时间步内寻找
%
%       rho^{n+1} = Reconstruction[W^{n+1},u^{n+1}],
%       H^{n+1}   = H(rho^{n+1}),
%
%  并用该 H^{n+1} 来推进相位和振幅。实际求解采用 Picard 外迭代，
%  不是大型 Newton，但已经能测试“把 H 放到 n+1 层”是否改善大步长行为。
%
%  重要说明：
%  -----------------------------------------------------------------------
%  1. 主变量仍然是 W 和 u；
%  2. rho 只作为非局部系数和收敛诊断使用；
%  3. 本函数不是求解原始 n 方程，也不是直接求稳态；
%  4. 这是一个试验性 time integrator，尚未作为论文中已证明的 AP 格式。
%
%  Picard 迭代格式：
%  -----------------------------------------------------------------------
%  给定猜测 (W^m,u^m)，重构 rho^m 并计算 H^m=H(rho^m)，然后从旧时刻
%  (W^n,u^n) 出发，用 rho^m,H^m 做一次 WKB 单步，得到 (W^{m+1},u^{m+1})。
%  若 rho/H/u 的变化足够小则接受。

if nargin < 8 || isempty(variant)
    variant = 'wkb-if-split';
end

maxIter = local_get_num(par, 'implicitMaxIter', 20);
tolRho  = local_get_num(par, 'implicitTolRho', 1e-8);
tolU    = local_get_num(par, 'implicitTolU', 1e-8);
relax   = local_get_num(par, 'implicitRelaxation', 1.0);
relax   = min(max(relax, 0.05), 1.0);

info = struct();
info.timeIntegratorUsed = 'fully-implicit-coupled-picard';
info.implicitConverged = 0;
info.implicitIterations = 0;
info.implicitTolRho = tolRho;
info.implicitTolU = tolU;
info.implicitRelaxation = relax;
info.needsRetry = false;
info.retryReason = '';

% 初始猜测：用旧状态作为第 0 次猜测。若 par.implicitInitialGuess='semiimplicit'，
% 也可以先做一次旧格式半隐式预测。
Wguess = Wold;
uguess = uold;
if strcmpi(local_get_string(par,'implicitInitialGuess','old'), 'semiimplicit')
    try
        [Wguess, uguess, predInfo] = src.wkb_single_step_1d(Wold, uold, D, Kx, dt, op, par, variant);
        info.predictorUsed = 1;
        info.predictorNeedsRetry = local_get_field(predInfo,'needsRetry',0);
    catch ME
        info.predictorUsed = 0;
        info.predictorFailure = ME.message;
        Wguess = Wold;
        uguess = uold;
    end
else
    info.predictorUsed = 0;
end

rhoPrev = [];
HPrev = [];
lastStepInfo = struct();

for it = 1:maxIter
    %----------------------------------------------------------
    % 1. 用当前猜测计算 rho^m 和 H^m。
    %----------------------------------------------------------
    [rhoGuess, ~, rhoInfo] = src.reconstruct_rho_1d(Wguess, uguess, par.eps, op, par.rhoReconstruction);
    if any(~isfinite(rhoGuess(:)))
        info.needsRetry = true;
        info.retryReason = 'fully implicit Picard 中 rhoGuess 出现 NaN/Inf';
        break;
    end
    Hraw = src.solve_H_fd_1d(D, Kx, rhoGuess, op);
    if any(~isfinite(Hraw(:)))
        info.needsRetry = true;
        info.retryReason = 'fully implicit Picard 中 H 特征值出现 NaN/Inf';
        break;
    end
    [HGuess, hGaugeInfo] = src.shift_effective_hamiltonian_1d(Hraw, par);

    %----------------------------------------------------------
    % 2. 从旧时刻 (Wold,uold) 出发，使用 n+1 层猜测系数 rho^m,H^m 做一步。
    %----------------------------------------------------------
    try
        [Wcand, ucand, stepInfo] = src.wkb_single_step_1d(Wold, uold, D, Kx, dt, op, par, variant, rhoGuess, HGuess);
    catch ME
        info.needsRetry = true;
        info.retryReason = ['fully implicit Picard 的 WKB 单步失败: ' ME.message];
        break;
    end
    lastStepInfo = stepInfo;
    if local_get_field(stepInfo,'needsRetry',0) || any(~isfinite(Wcand(:))) || any(~isfinite(ucand(:)))
        info.needsRetry = true;
        rr = local_get_string(stepInfo,'retryReason','WKB 单步要求重试或产生非有限值');
        info.retryReason = ['fully implicit Picard 内部: ' rr];
        break;
    end

    %----------------------------------------------------------
    % 3. 计算 Picard 收敛误差。
    %    u 只按模常数比较；rho/H 比较相对变化。
    %----------------------------------------------------------
    [rhoCand, ~, rhoCandInfo] = src.reconstruct_rho_1d(Wcand, ucand, par.eps, op, par.rhoReconstruction);
    HcandRaw = src.solve_H_fd_1d(D, Kx, rhoCand, op);
    [Hcand, ~] = src.shift_effective_hamiltonian_1d(HcandRaw, par);

    uErr = local_phase_diff_norm(ucand, uguess);
    rhoErr = norm(rhoCand(:)-rhoGuess(:), Inf) / max(1, norm(rhoCand(:), Inf));
    HErr = norm(Hcand(:)-HGuess(:), Inf) / max(1, norm(Hcand(:), Inf));

    info.implicitIterations = it;
    info.implicitLastUErr = uErr;
    info.implicitLastRhoErr = rhoErr;
    info.implicitLastHErr = HErr;
    info.implicitRhoMax = max(rhoCand(:));
    info.implicitHRange = max(Hcand(:))-min(Hcand(:));
    info = local_merge(info, rhoInfo, hGaugeInfo, rhoCandInfo);

    if rhoErr <= tolRho && uErr <= tolU
        Wguess = Wcand;
        uguess = ucand;
        rhoPrev = rhoCand; %#ok<NASGU>
        HPrev = Hcand; %#ok<NASGU>
        info.implicitConverged = 1;
        break;
    end

    %----------------------------------------------------------
    % 4. 非线性欠松弛。为避免 W 的线性插值破坏正性，这里对 log(W) 插值。
    %    这只是 Picard 迭代中的数值松弛，不改变最终格式定义。
    %----------------------------------------------------------
    if relax < 0.999
        [Wguess, uguess] = local_relax_wkb_pair(Wguess, uguess, Wcand, ucand, relax, par.eps);
    else
        Wguess = Wcand;
        uguess = ucand;
    end

    rhoPrev = rhoGuess; %#ok<NASGU>
    HPrev = HGuess; %#ok<NASGU>
end

Wnew = Wguess;
unew = uguess;
% 合并时让 Picard 外层的 needsRetry/retryReason 优先，避免被子步的 false 覆盖。
info = local_merge(lastStepInfo, info);

if info.implicitConverged == 0 && ~info.needsRetry
    % 没有发散，但 Picard 没收敛。默认要求外层缩步重试；若用户只想观察，
    % 可设置 par.implicitAcceptUnconverged=true。
    if local_get_bool(par, 'implicitAcceptUnconverged', false)
        info.implicitAcceptedUnconverged = true;
    else
        info.needsRetry = true;
        info.retryReason = sprintf('fully implicit Picard 未收敛: iter=%d, rhoErr=%.3e, uErr=%.3e', ...
            info.implicitIterations, local_get_field(info,'implicitLastRhoErr',Inf), local_get_field(info,'implicitLastUErr',Inf));
    end
end
end

function d = local_phase_diff_norm(u1, u0)
u1 = real(u1(:)); u0 = real(u0(:));
u1 = u1 - max(u1);
u0 = u0 - max(u0);
d = norm(u1-u0, Inf);
end

function [Wmix, umix] = local_relax_wkb_pair(Wold, uold, Wnew, unew, omega, eps)
% 对 u 作模常数线性欠松弛；对 W 作 log 欠松弛，保持正性。
% 这是非线性迭代的内部技巧，不作为物理时间推进的一部分解释。
uold0 = uold - max(uold(:));
unew0 = unew - max(unew(:));
umix = (1-omega)*uold0 + omega*unew0;
logWold = log(max(real(Wold), realmin));
logWnew = log(max(real(Wnew), realmin));
logWmix = (1-omega)*logWold + omega*logWnew;
logWmix = min(max(logWmix, -650), 650);
Wmix = exp(logWmix);
% 最后只做一个非常小心的 max gauge。由于 umix 已经 max≈0，这里 c 很小。
[Wmix, umix] = src.normalize_gauge(Wmix, umix, eps, 'max');
end

function out = local_merge(varargin)
out = struct();
for i = 1:nargin
    s = varargin{i};
    if ~isstruct(s), continue; end
    f = fieldnames(s);
    for j = 1:numel(f)
        out.(f{j}) = s.(f{j});
    end
end
end

function val = local_get_num(s, name, defaultValue)
val = defaultValue;
if isstruct(s) && isfield(s,name) && ~isempty(s.(name)) && isnumeric(s.(name)) && isscalar(s.(name))
    val = double(s.(name));
end
end

function val = local_get_string(s, name, defaultValue)
val = defaultValue;
if isstruct(s) && isfield(s,name) && ~isempty(s.(name))
    val = char(s.(name));
end
end

function tf = local_get_bool(s, name, defaultValue)
tf = defaultValue;
if isstruct(s) && isfield(s,name) && ~isempty(s.(name))
    tf = logical(s.(name));
end
end

function v = local_get_field(s, name, defaultValue)
v = defaultValue;
if isstruct(s) && isfield(s,name) && ~isempty(s.(name))
    v = s.(name);
    if isnumeric(v) && isscalar(v), v = double(v); end
end
end
