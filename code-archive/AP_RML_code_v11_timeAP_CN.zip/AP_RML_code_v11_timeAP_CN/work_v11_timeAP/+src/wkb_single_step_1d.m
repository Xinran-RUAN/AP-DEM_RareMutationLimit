function [Wnew, unew, info] = wkb_single_step_1d(Wold, uold, D, Kx, dt, op, par, variant, rhoGiven, HGiven)
%WKB_SINGLE_STEP_1D  只推进一次 WKB 变量 (W,u) 的基础时间步。
%
%  这个函数是新版 time-AP 试验代码的“原子步”。它的设计目标是：
%
%  1. 主变量始终是 WKB 变量 W 和 u，不把主求解器改成直接求 n；
%  2. 可以由普通半隐式推进、全隐式 Picard 外迭代、projective 微步共同调用；
%  3. 若外层已经给定 rho 和 H，则使用外层给定值，这样可以构造
%     H^{n+1}=H(rho^{n+1}) 的隐式耦合；
%  4. 若外层没有给定，则在当前状态 (Wold,uold) 上重构 rho 并计算 H。
%
%  输入：
%    Wold, uold  : 上一时刻的 WKB 变量；
%    D, Kx       : D(theta) 与 K(x)；
%    dt          : 本步时间步长；
%    op          : 离散算子结构体；
%    par         : 参数结构体；
%    variant     : 振幅更新格式，例如 'wkb-if-split', 'split' 等；
%    rhoGiven    : 可选，外层给定的 rho；
%    HGiven      : 可选，外层给定的已经 gauge 平移后的 H。
%
%  输出：
%    Wnew, unew  : 本步之后的 WKB 变量；
%    info        : 诊断量。所有重要步骤都有中文字段说明。
%
%  注意：本函数只是“一步格式”，不做拒步重试。拒步重试由 run_wkb_1d
%  或外层 time integrator 负责。

if nargin < 8 || isempty(variant)
    variant = 'wkb-if-split';
end
if nargin < 9
    rhoGiven = [];
end
if nargin < 10
    HGiven = [];
end

info = struct();
info.stepKind = 'single-wkb-step';
info.dt = dt;
info.variantUsed = char(variant);
info.usedGivenRho = ~isempty(rhoGiven);
info.usedGivenH = ~isempty(HGiven);

%--------------------------------------------------------------
% 1. 得到本步使用的 rho 与 H。
%    全隐式 Picard 外迭代会把 rho^{(m)},H^{(m)} 传进来；
%    普通步则使用旧时刻状态计算 rho^n,H^n。
%--------------------------------------------------------------
if isempty(rhoGiven)
    [rho, ~, rhoInfo] = src.reconstruct_rho_1d(Wold, uold, par.eps, op, par.rhoReconstruction);
else
    rho = rhoGiven;
    rhoInfo = struct();
end

if isempty(HGiven)
    Hraw = src.solve_H_fd_1d(D, Kx, rho, op);
    [H, hGaugeInfo] = src.shift_effective_hamiltonian_1d(Hraw, par);
else
    H = HGiven;
    hGaugeInfo = struct('hamiltonianGaugeFromOuter',1);
end

info.rhoMaxUsed = max(rho(:));
info.rhoMinUsed = min(rho(:));
info.HMaxUsed = max(H(:));
info.HMinUsed = min(H(:));
info.HRangeUsed = max(H(:))-min(H(:));
info = local_merge(info, rhoInfo, hGaugeInfo);

%--------------------------------------------------------------
% 2. 相位步。这里仍然使用现有的 HJ 离散。
%    对 fully-implicit-coupled 外层而言，H 是外层隐式迭代给定的
%    H(rho^{(m)})，因此至少在 H-rho 耦合上是隐式的。
%--------------------------------------------------------------
uRaw = src.step_phase_1d(uold, H, par.eps, dt, op, par.phaseHamiltonian, par.lfAlpha);

%--------------------------------------------------------------
% 3. 振幅步。所有分支都更新 W，不把主问题改为直接求 n。
%--------------------------------------------------------------
variant = lower(char(variant));
switch variant
    case {'wkb-if-split','wkb-if','balanced-wkb-if'}
        [Wnew, unew, ampInfo] = src.update_w_wkb_if_split_fd_1d(Wold, uold, uRaw, D, Kx, rho, H, par.eps, dt, op, par);
    case {'split-if','balanced-split','if-split'}
        [uAmp, ~, gaugeInfo] = src.choose_phase_gauge_1d(uold, uRaw, par.eps, par);
        [Wtmp, ampInfo] = src.update_w_split_if_fd_1d(Wold, uold, uAmp, D, Kx, rho, H, par.eps, dt, op, par);
        [Wnew, unew, postGaugeInfo] = src.stabilize_wkb_gauge_1d(Wtmp, uAmp, par.eps, par);
        ampInfo = local_merge(ampInfo, gaugeInfo, postGaugeInfo);
    case {'split','split-wkb'}
        [Wtmp, ampInfo] = src.update_w_split_fd_1d(Wold, uRaw, D, Kx, rho, H, par.eps, dt, op, par);
        [Wnew, unew] = src.normalize_gauge(Wtmp, uRaw, par.eps, 'max');
    case {'density-compatible-semidiscrete','dc-semidiscrete','density-compatible-old','dc-old'}
        [Wtmp, ampInfo] = src.update_w_density_compatible_fd_1d(Wold, uRaw, D, Kx, rho, H, par.eps, dt, op, par);
        [Wnew, unew] = src.normalize_gauge(Wtmp, uRaw, par.eps, 'max');
    otherwise
        % 为了兼容旧脚本，density-compatible-if 在 run_wkb_1d 中通常已经被
        % 映射到 wkb-if-split。若这里仍收到未知名字，明确报错，避免静默错用。
        error('Unknown amplitude variant in wkb_single_step_1d: %s', variant);
end

info = local_merge(info, ampInfo);
info.numNonfiniteWStep = nnz(~isfinite(Wnew(:)));
info.numNonfiniteUStep = nnz(~isfinite(unew(:)));
info.WMaxStep = max(abs(Wnew(:)));
info.uMaxAbsStep = max(abs(unew(:)));

%--------------------------------------------------------------
% 4. 若振幅子步已经检测到需要重试，把信息向上传递。
%--------------------------------------------------------------
if ~isfield(info,'needsRetry')
    info.needsRetry = false;
end
if ~isfield(info,'retryReason')
    info.retryReason = '';
end
if info.numNonfiniteWStep > 0 || info.numNonfiniteUStep > 0
    info.needsRetry = true;
    if isempty(info.retryReason)
        info.retryReason = 'single WKB step 产生 NaN/Inf';
    end
end
end

function out = local_merge(varargin)
out = struct();
for i = 1:nargin
    s = varargin{i};
    if ~isstruct(s), continue; end
    f = fieldnames(s);
    for j = 1:numel(f)
        out.(f{j}) = s.(f{j});
    end
end
end
