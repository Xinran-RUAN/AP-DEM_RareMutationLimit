% RUN_TRY_PROJECTIVE_AP_1D
% 试验 v11 的第 3 个方案：micro-macro / projective AP 时间推进。
%
% 用法：
%   startup_AP_RML
%   run_try_projective_ap_1d
%
% 说明：
%   每个宏步中先做若干 O(eps) 微步，再对 WKB 变量 (u,logW) 做投影外推。
%   这是试验算法，用来判断 projective 方向是否能改善 dt>>eps 的动态演化。

root = fileparts(fileparts(mfilename('fullpath')));
addpath(root);
startup_AP_RML;

par = model.default_params_1d('baseline');
par.eps = 1e-4;
par.Nx = 50;
par.Ntheta = 64;
par.T = 20;
par.dt = 1e-3;
par.dtMax = par.dt;
par.tol = 1e-8;

par.timeIntegrator = 'projective-ap';
par.amplitudeVariant = 'wkb-if-split';
par.reactionDiscretization = 'logistic-exact';
par.rhoReconstruction = 'laplace-hybrid';
par.residualMode = 'wkb-steady';

par.projectiveNumMicroSteps = 6;
par.projectiveMicroSafety = 0.2;      % dt_micro≈0.2*eps
par.projectiveMicroDt = [];
par.projectiveMaxFactor = 2000;
par.projectiveMaxLogWIncrement = 80;
par.projectiveCorrection = false;

par.adaptiveTimeStep = true;
par.adaptiveStrategy = 'phase-cfl';
par.enableStepRetry = true;
par.maxStepRetries = 12;
par.retryDtFactor = 0.5;

par.initialPhaseMode = 'peaked';
par.prepareInitialMass = true;
par.hamiltonianGauge = 'min';
par.thetaRephase = false;

par.verbose = true;
par.livePlot = true;
par.livePlotEveryTime = 0.5;
par.historyEverySteps = 50;
par.storeSnapshots = false;
par.outdir = utils.output_dir('try_projective_ap_1d');

wkb = src.run_wkb_1d(par);
src.diagnose_wkb_history_1d(wkb.history, true);
