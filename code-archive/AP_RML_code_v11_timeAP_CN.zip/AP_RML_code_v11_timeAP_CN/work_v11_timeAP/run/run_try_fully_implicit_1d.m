% RUN_TRY_FULLY_IMPLICIT_1D
% 试验 v11 的第 1 个方案：H-rho 全隐式耦合 Picard 时间推进。
%
% 用法：
%   startup_AP_RML
%   run_try_fully_implicit_1d
%
% 说明：
%   这个脚本仍然求解 WKB 变量 W 和 u，不求解原始 n 方程。
%   若 Picard 在给定 dt 下不收敛，run_wkb_1d 会拒绝本步并缩小 dt 重试。

root = fileparts(fileparts(mfilename('fullpath')));
addpath(root);
startup_AP_RML;

par = model.default_params_1d('baseline');
par.eps = 1e-4;
par.Nx = 50;
par.Ntheta = 64;
par.T = 20;
par.dt = 1e-3;
par.dtMax = par.dt;
par.tol = 1e-8;

par.timeIntegrator = 'fully-implicit-coupled';
par.amplitudeVariant = 'wkb-if-split';
par.reactionDiscretization = 'logistic-exact';
par.rhoReconstruction = 'laplace-hybrid';
par.residualMode = 'wkb-steady';

par.implicitMaxIter = 20;
par.implicitTolRho = 1e-8;
par.implicitTolU = 1e-8;
par.implicitRelaxation = 1.0;   % 若不收敛，可试 0.5 或 0.3
par.implicitInitialGuess = 'semiimplicit';

par.adaptiveTimeStep = true;
par.adaptiveStrategy = 'phase-cfl';
par.enableStepRetry = true;
par.maxStepRetries = 12;
par.retryDtFactor = 0.5;

par.initialPhaseMode = 'peaked';
par.prepareInitialMass = true;
par.hamiltonianGauge = 'min';
par.thetaRephase = false;

par.verbose = true;
par.livePlot = true;
par.livePlotEveryTime = 0.5;
par.historyEverySteps = 50;
par.storeSnapshots = false;
par.outdir = utils.output_dir('try_fully_implicit_1d');

wkb = src.run_wkb_1d(par);
src.diagnose_wkb_history_1d(wkb.history, true);
