% RUN_MAIN_1D 普通一维主程序：只跑一组参数，不做成组数值测试。
% 用法：
%   startup_AP_RML
%   run_main_1d
%
% 说明：
%   这个脚本适合日常检查模型、生成一组基准数据或调参数。
%   与 run_test*.m 不同，这里没有 eps/grid 的循环，也不计算测试表格。
%
% 运行速度提醒：
%   WKB 主程序每一步都要对每个 theta_k 求一个 x 方向主特征值。因此运行时间
%   对 Nx 和 Ntheta 很敏感。旧代码常用 N_x=5, N_theta=50；如果这里直接用
%   Nx=200, Ntheta=128，会比旧代码慢很多。建议先用 runMode='quick' 调通，
%   最后生成正式数据时再改成 'paper'。

root = fileparts(fileparts(mfilename('fullpath')));
addpath(root);
startup_AP_RML;

%==============================
% 0. 选择运行模式
%==============================
% 'quick' : 日常调试和看现象，较快；
% 'paper' : 接近论文正式数据，较慢；
% 'oldlike' : 接近旧代码网格规模，非常快，但 x 方向很粗，只适合排错。
runMode = 'quick';

% v11 新增：选择时间积分器。
%   'semiimplicit'           : 旧的半隐式/积分因子推进；
%   'fully-implicit-coupled' : 第 1 个方案，Picard 外迭代更新 H^{n+1}=H(rho^{n+1})；
%   'projective-ap'          : 第 3 个方案，O(eps) 微步 + projective 外推。
% 建议先分别运行后比较 history 中的 implIt/implRho 或 projFac/microDt。
timeIntegratorChoice = 'fully-implicit-coupled';
% timeIntegratorChoice = 'projective-ap';

%==============================
% 1. 选择模型和数值参数
%==============================
par = model.default_params_1d('baseline');   % 'baseline' 或 'heterogeneous'
par.eps = 1e-4;   % 可改为 1e-2, 1e-3, 1e-6 等；新版默认仍在 WKB 框架下求解 W 和 u

switch lower(runMode)
    case 'quick'
        par.Nx = 50;
        par.Ntheta = 64;
        par.T = 100;
        par.dt = 1e-3;
        par.tol = 1e-8;
        par.historyEveryTime = 1.0;
        par.storeSnapshots = false;
        par.snapshotTimes = [];
    case 'paper'
        par.Nx = 200;
        par.Ntheta = 128;
        par.T = 30;
        par.dt = 1e-3;
        par.tol = 1e-9;
        par.historyEveryTime = 0.5;
        par.storeSnapshots = true;
        par.snapshotTimes = [1, 5, 10, 20, par.T];
    case 'oldlike'
        par.Nx = 10;          % 比旧代码 N_x=5 略细，但仍然很快
        par.Ntheta = 50;
        par.T = 5;
        par.dt = 2e-3;
        par.tol = 1e-8;
        par.historyEveryTime = 1.0;
        par.storeSnapshots = false;
        par.snapshotTimes = [];
    otherwise
        error('Unknown runMode "%s".', runMode);
end

% WKB 格式选项。
par.phaseHamiltonian = 'godunov';            % 'godunov', 'lf', 或 'weno5'
par.amplitudeVariant = 'wkb-if-split';      % 新版推荐：纯 WKB 时间平衡格式，仍然求解 W 和 u
par.reactionDiscretization = 'logistic-exact'; % 在 W 上作 exact logistic 反应缩放，避免 dt/eps 大时 rho 爆炸
par.residualMode = 'wkb-steady';        % 直接监测 WKB 稳态方程 residual；单步 residual 另存 history
par.rhoReconstruction = 'laplace-hybrid'; % 小 epsilon 下 direct-log 会欠解析尖峰，默认使用 Laplace-hybrid
par.timeIntegrator = timeIntegratorChoice;   % v11: 选择全隐式耦合或 projective AP 试验积分器

% 全隐式耦合 Picard 参数。若 Picard 不收敛，run_wkb_1d 会拒绝本步并缩小 dt 重试。
par.implicitMaxIter = 20;
par.implicitTolRho = 1e-8;
par.implicitTolU = 1e-8;
par.implicitRelaxation = 1.0;
par.implicitInitialGuess = 'semiimplicit';

% projective AP 参数。只有 timeIntegratorChoice='projective-ap' 时会使用。
par.projectiveNumMicroSteps = 6;
par.projectiveMicroSafety = 0.2;
par.projectiveMaxFactor = 2000;
par.projectiveMaxLogWIncrement = 80;
par.projectiveCorrection = false;

% 若希望在给定 dt 偏大时自动缩小时间步，可设为 true。
% split-if 下默认 adaptiveStrategy='phase-cfl'，不会强制 dt=O(eps)。
par.adaptiveTimeStep = true;
par.adaptiveStrategy = 'phase-cfl';
par.phaseCflSafety = 0.45;
par.adaptiveIfLogRange = true;        % 限制 IF 指数相对跨度；eps=1e-6 时通常会把 1e-3 降到约 1e-4
par.ifLogRangeMax = 80;
par.adaptiveSafety = 0.5;
par.dtMax = par.dt;

% 小 epsilon 推荐的 WKB 内部稳健化选项。
par.gaugeMode = 'auto';       % 旧字段，保留兼容
par.ifGaugeStrategy = 'phase-peak'; % 只做常数 gauge，把相位二次插值峰值规范到 0
par.ifMode = 'h-only';        % 只用积分因子抵消 H 项，避免 full IF 中 |u_theta|^2/eps 放大
par.prepareInitialMass = true;
par.initialPhaseMode = 'peaked';   % 若想使用你测试过的均匀相位初值，可改为 'flat'
par.initialRhoProfile = 'scaledK';
par.initialRhoScale = 0.5;
par.monitorMatrixCondition = false; % 排查奇异矩阵时可改 true
par.enableStepRetry = true;   % 若 qW/rho/residual 出现病态，拒绝本步并缩小 dt 重试
par.maxStepRetries = 12;
par.retryDtFactor = 0.5;
par.ifSeedLogAbsMax = 600;    % 接近双精度溢出时才缩步
par.ifSeedLogRangeMax = 500;  % 主要作为诊断，不再默认拒步
par.rejectOnSeedLogRange = false;
par.rhoLogRetryMax = 120;      % 监测 Laplace rho 的 log 尺度；超过则缩步

% v10 核心：不使用 theta 依赖 rephase。只对 H 做标量 gauge 平移。
% 这样可以避免公共 H 偏移带来的 exp(dt*H/eps) 刚性，同时不改变 u_theta。
par.hamiltonianGauge = 'min';
par.thetaRephase = false;
par.thetaRephaseStatistic = 'median';
par.thetaRephaseSmoothPasses = 0;
par.thetaRephaseMaxAbsShift = 0;

par.historyEverySteps = 100;  % 小 epsilon 调试时多记录一些点，方便 diagnose

% 输出和进度控制。
par.outdir = utils.output_dir(['main_single_case_' runMode]);
par.verbose = true;
par.progressEveryPercent = 5;                % 每 5%% 预计进度至少输出一次
par.progressEverySeconds = 10;               % 或每 10 秒输出一次


% 运行过程中的图像监测。和旧代码边算边画的思路一致。
% 注意：会稍微增加耗时，因此 paper 档默认关闭。
switch lower(runMode)
    case 'quick'
        par.livePlot = true;
        par.livePlotEveryTime = 0.5;
    case 'oldlike'
        par.livePlot = true;
        par.livePlotEveryTime = 0.5;
    otherwise
        par.livePlot = false;
        par.livePlotEveryTime = 2.0;
end
par.livePlotEverySteps = [];
par.livePlotSave = false;                    % 若想保存在线图帧，改成 true
par.livePlotPause = 0.0;                     % 若想每次刷新后暂停，可设成 0.1 等

% 是否同时跑直接密度方程。默认 false，因为 direct 在小 eps 下更慢且容易欠分辨。
runDirect = false;

fprintf('\n========== RUN_MAIN_1D: 单组参数主程序 ==========' );
fprintf('\nrunMode=%s, profile=%s, eps=%.4g, Nx=%d, Ntheta=%d, T=%.4g, dt=%.4g\n', ...
    runMode, par.profile, par.eps, par.Nx, par.Ntheta, par.T, par.dt);
fprintf('预计最多步数: %d；WKB 未知量规模约: %d x %d = %d\n', ...
    ceil(par.T/par.dt), par.Nx+1, par.Ntheta, (par.Nx+1)*par.Ntheta);
fprintf('outdir=%s\n', par.outdir);
fprintf('livePlot=%d, livePlotEveryTime=%.4g\n', par.livePlot, par.livePlotEveryTime);

%==============================
% 2. 运行 WKB 求解器
%==============================
wkb = src.run_wkb_1d(par);

%==============================
% 3. 可选：运行原始密度方程直接求解器
%==============================
if runDirect
    direct = src.run_direct_1d(par); %#ok<SNASGU>
else
    direct = []; %#ok<NASGU>
end

%==============================
% 4. 保存本次单组运行摘要
%==============================
summary = struct();
summary.runMode = runMode;
summary.profile = par.profile;
summary.eps = par.eps;
summary.Nx = par.Nx;
summary.Ntheta = par.Ntheta;
summary.T = par.T;
summary.dt = par.dt;
summary.amplitudeVariant = par.amplitudeVariant;
summary.reactionDiscretization = par.reactionDiscretization;
summary.residualMode = par.residualMode;
summary.rhoReconstruction = par.rhoReconstruction;
summary.timeIntegrator = par.timeIntegrator;
summary.ifMode = par.ifMode;
summary.adaptiveTimeStep = par.adaptiveTimeStep;
summary.adaptiveStrategy = par.adaptiveStrategy;
summary.gaugeMode = par.gaugeMode;
summary.ifGaugeStrategy = par.ifGaugeStrategy;
summary.hamiltonianGauge = par.hamiltonianGauge;
summary.enableStepRetry = par.enableStepRetry;
summary.initialPhaseMode = par.initialPhaseMode;
summary.prepareInitialMass = par.prepareInitialMass;
summary.thetaRephase = par.thetaRephase;
summary.thetaRephaseStatistic = par.thetaRephaseStatistic;
summary.theta_m = par.theta_m;
summary.theta_wkb = wkb.diagnostics.theta_wkb;
summary.err_wkb_to_m = wkb.diagnostics.err_wkb_to_m;
summary.sigma_theta = wkb.diagnostics.sigma_theta;
summary.rho_max = wkb.diagnostics.rho_max;
summary.gammaR = wkb.diagnostics.gammaR;
summary.residual = wkb.residual;
summary.steps = wkb.step;

utils.ensure_dir(par.outdir);
save(fullfile(par.outdir, 'summary_main_1d.mat'), 'summary', 'wkb', 'direct');

disp('RUN_MAIN_1D 摘要:');
disp(summary);
fprintf('RUN_MAIN_1D 完成。结果目录: %s\n', par.outdir);
