# v11：WKB 时间积分器试验版说明

本版本在 v10 的基础上实现了两个新的 **time evolution** 方向的试验算法，用来测试小 \(\varepsilon\) 且 `dt >> eps` 时，是否可以缓解旧动态推进格式中的病态。两个算法都仍然以 WKB 变量 `W` 和 `u` 为主未知量，没有把主求解器改成直接求原始密度方程。

## 1. 为什么要改时间积分器

此前数值现象表明：WKB 分解能够剥离 trait 方向的主指数集中，但当前动态推进中

```math
H_k(t)=H_k(\rho(t))
```

会随时间变化。如果一步里冻结 `H^n`，相位误差会进入 `exp(u/eps)` 并被 `1/eps` 放大。无 mutation 的 age-structured 模型中，主特征值 `Lambda(x)` 不随时间变，所以 `u` 的主要项可精确积分；本模型中 `H(rho(t))` 与 `W,u,rho` 强耦合，因此不能直接照搬那个大步长机制。

## 2. 新增时间积分器

参数入口为：

```matlab
par.timeIntegrator = 'semiimplicit';              % 旧默认格式
par.timeIntegrator = 'fully-implicit-coupled';    % 方案 1：H-rho 全隐式 Picard
par.timeIntegrator = 'projective-ap';             % 方案 3：micro-macro / projective AP
```

### 2.1 `fully-implicit-coupled`

该模式在每个时间步内做 Picard 外迭代，目标是近似实现

```math
\rho^{n+1}=Q[W^{n+1},u^{n+1}],\qquad H^{n+1}=H(\rho^{n+1}).
```

也就是说，本步的相位和振幅更新不再使用冻结的 `H^n`，而是迭代使用 `H(rho^{(m)})`。它仍然从旧时刻 `(W^n,u^n)` 出发，更新新的 `(W^{n+1},u^{n+1})`，主变量没有变成 `n`。

主要参数：

```matlab
par.implicitMaxIter = 20;              % Picard 最大迭代次数
par.implicitTolRho = 1e-8;             % rho 相对变化阈值
par.implicitTolU = 1e-8;               % u 模常数差异阈值
par.implicitRelaxation = 1.0;          % 欠松弛，若不收敛可试 0.5 或 0.3
par.implicitInitialGuess = 'semiimplicit';
par.implicitAcceptUnconverged = false; % false: 未收敛则拒步缩小 dt
```

输出诊断：

```matlab
history.implicitIterations
history.implicitConverged
history.implicitLastRhoErr
history.implicitLastUErr
history.implicitLastHErr
```

### 2.2 `projective-ap`

该模式先用若干个 `O(eps)` 微步解析快松弛层，再根据最后两个微步估计慢变量时间导数，并对剩余宏步做投影外推。其思想是：不要用一个大步直接跨过快层，而是先让解贴近慢流形。

主要参数：

```matlab
par.projectiveNumMicroSteps = 6;       % 微步个数
par.projectiveMicroSafety = 0.2;       % dt_micro ≈ 0.2*eps
par.projectiveMicroDt = [];            % 手动指定微步长；空表示自动
par.projectiveMaxFactor = 2000;        % tau_project/dt_micro 最大允许值
par.projectiveMaxLogWIncrement = 80;   % 限制一次投影中 log(W) 变化
par.projectiveCorrection = false;      % 可选：投影后做一个短 correction 步
```

输出诊断：

```matlab
history.projectiveFactor
history.projectiveMicroDt
history.projectiveNumMicroStepsUsed
history.projectiveTau
history.projectiveDuInf
```

## 3. 推荐测试方式

在 `run/run_main_1d.m` 中修改：

```matlab
timeIntegratorChoice = 'fully-implicit-coupled';
% timeIntegratorChoice = 'projective-ap';
```

建议先用温和参数测试：

```matlab
par.eps = 1e-4;
par.dt  = 1e-3;
par.Nx = 50;
par.Ntheta = 64;
```

然后再尝试：

```matlab
par.eps = 1e-6;
par.dt  = 1e-3;
```

运行后执行：

```matlab
src.diagnose_wkb_history_1d(wkb.history, true)
```

重点看：

- 全隐式模式：`implIt`, `implRho`, `implU`；
- projective 模式：`projFac`, `microDt`, `microN`；
- 通用病态量：`seedRange`, `logWrange`, `phaseCFL`, `resPhase`, `resAmpW`, `peakGrid`。

## 4. 重要限制

这两个新积分器都是试验代码，不是论文中已经证明的 AP 格式。

- `fully-implicit-coupled` 使用 Picard 迭代，不是完整 Newton；若耦合太强，可能需要缩小 `dt` 或使用欠松弛。
- `projective-ap` 的外推可能放大误差，特别是 `projectiveFactor` 很大时；因此加入了 `projectiveMaxFactor` 和 `projectiveMaxLogWIncrement` 保护。
- 若 `peakWidthOverGrid < 1`，说明密度峰形已经低于 trait 网格分辨率。此时应主要看 WKB 相位峰位置，而不要强求原始密度峰形漂亮。

## 5. 新增主要文件

```text
+src/wkb_single_step_1d.m
+src/step_wkb_fully_implicit_coupled_1d.m
+src/step_wkb_projective_ap_1d.m
README_v11_timeAP_中文.md
```
