function result = run_direct_1d(par)
%RUN_DIRECT_1D 运行原始密度 n 方程的一维直接求解器。
%   该函数主要用于与 WKB 重构结果对比。因为直接解 n 会在小 eps
%   时出现很窄的 theta 峰，所以在粗 theta 网格上通常更容易欠分辨。

%-------------------------
% 初始化密度、算子、输出目录和进度条
%-------------------------
[n, D, Kx, grid, W0, u0] = model.initial_direct_1d(par);
op = src.build_operators_1d(grid);
par.outdir = utils.ensure_dir(par.outdir);
tag = [utils.build_tag(par) '_direct'];
prog = utils.progress_init('DIR-1D', par);

history.t = [];
history.residual = [];
history.theta_direct = [];
history.err_direct_to_m = [];
history.sigma_theta = [];
historyEverySteps = local_history_every_steps(par);
lastInfo = struct();

t = 0;
step = 0;
residual = Inf;

%-------------------------
% 主时间循环：半隐式更新原始 n 方程
%-------------------------
while t < par.T && step < par.maxSteps
    nOld = n;
    n = src.update_direct_density_fd_1d(n, D, Kx, par.eps, par.dt, op);
    t = t + par.dt;
    step = step + 1;
    residual = max(abs(n(:)-nOld(:))) / (par.dt*(1 + max(abs(n(:)))));

    % 记录 trait marginal 的峰值位置和宽度。
    if step == 1 || mod(step, historyEverySteps) == 0 || residual <= par.tol
        wx = utils.trapz_weights(op.nx, op.dx);
        P = wx.' * n;
        [~, idP] = max(P);
        theta_direct = op.theta(idP);
        dist = utils.periodic_distance(op.theta, theta_direct);
        history.t(end+1,1) = t;
        history.residual(end+1,1) = residual;
        history.theta_direct(end+1,1) = theta_direct;
        history.err_direct_to_m(end+1,1) = utils.periodic_distance(theta_direct, par.theta_m);
        history.sigma_theta(end+1,1) = sqrt(sum((dist.^2).*P)/max(sum(P),realmin));
        lastInfo.theta_direct = theta_direct;
        lastInfo.err_direct_to_m = history.err_direct_to_m(end);
        lastInfo.sigma_theta = history.sigma_theta(end);
    end

    prog = utils.progress_update(prog, step, t, residual, lastInfo);

    if par.stopByResidual && residual <= par.tol
        break;
    end
end

%-------------------------
% 最终诊断和保存
%-------------------------
rho = op.dtheta * sum(n, 2);
wx = utils.trapz_weights(op.nx, op.dx);
P = wx.' * n;
[~, idP] = max(P);
diagInfo.theta_direct = op.theta(idP);
diagInfo.err_direct_to_m = utils.periodic_distance(diagInfo.theta_direct, par.theta_m);
diagInfo.rho_min = min(rho);
diagInfo.rho_max = max(rho);
diagInfo.P = P;
result = struct('n',n,'rho',rho,'D',D,'Kx',Kx,'grid',grid,'op',op,'par',par, ...
                't',t,'step',step,'residual',residual,'history',history, ...
                'diagnostics',diagInfo,'tag',tag,'W0',W0,'u0',u0);

finishInfo.theta_direct = diagInfo.theta_direct;
finishInfo.err_direct_to_m = diagInfo.err_direct_to_m;
finishInfo.rho_max = diagInfo.rho_max;
utils.progress_finish(prog, step, t, residual, finishInfo);
outfile = fullfile(par.outdir, [tag '_final.mat']);
save(outfile, '-struct', 'result');
if par.verbose
    fprintf('[DIR-1D] 结果已保存: %s\n', outfile);
end
end

function historyEverySteps = local_history_every_steps(par)
% 根据 par.historyEverySteps 或 par.historyEveryTime 计算诊断记录间隔。
if isfield(par, 'historyEverySteps') && ~isempty(par.historyEverySteps) && ...
        isnumeric(par.historyEverySteps) && isscalar(par.historyEverySteps) && par.historyEverySteps > 0
    historyEverySteps = max(1, round(par.historyEverySteps));
elseif isfield(par, 'historyEveryTime') && ~isempty(par.historyEveryTime) && ...
        isnumeric(par.historyEveryTime) && isscalar(par.historyEveryTime) && par.historyEveryTime > 0
    historyEverySteps = max(1, round(par.historyEveryTime / par.dt));
else
    historyEverySteps = max(1, round(0.1 / par.dt));
end
end
