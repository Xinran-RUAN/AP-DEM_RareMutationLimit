function [W, u, D, K, grid] = initial_wkb_1d(par)
%INITIAL_WKB_1D WKB 求解器的初值和系数。
%
%  小 epsilon 时需要注意：如果采用 max(u)=0 且 W=O(1) 的尖峰相位初值，
%  则 rho=int W exp(u/eps)dtheta 可能只有 O(Delta theta) 或更小，
%  这会让计算从“近乎空种群”开始，产生很强的初始快层。
%  本函数提供 prepareInitialMass 选项：只缩放 W，使初始 rho 为 O(1)，
%  不改变 u 的峰值位置，也不改变 WKB 框架。

grid = model.make_grid_1d(par);
x = grid.x;
theta = grid.theta;
D = par.D_fun(theta);
K = par.K_fun(x);

phaseMode = local_get_string(par, 'initialPhaseMode', 'peaked');
switch lower(phaseMode)
    case {'peaked','old','single-peak'}
        u = -par.alpha0 * (1 - cos(2*pi*(theta - par.theta0)));
    case {'flat','homogeneous','uniform'}
        % 平相位初值适合小 epsilon 排查：不预设 trait 峰，选择由 HJ 方程产生。
        u = zeros(1, par.Ntheta);
    otherwise
        error('Unknown initialPhaseMode "%s".', phaseMode);
end

W = repmat(1 + 0.1*cos(2*pi*x), 1, par.Ntheta);

% 初始 gauge。这里仍用 max 只是为了避免初始重构上溢；后续时间步可用 incremental gauge。
[W, u] = src.normalize_gauge(W, u, par.eps, 'max');

if local_get_logical(par, 'prepareInitialMass', true)
    op = src.build_operators_1d(grid);
    [rho0, ~] = src.reconstruct_rho_1d(W, u, par.eps, op, 'direct-log');
    profile = local_get_string(par, 'initialRhoProfile', 'scaledK');
    scale = local_get_num(par, 'initialRhoScale', 0.5);
    switch lower(profile)
        case {'scaledk','k','carrying'}
            rhoTarget = max(scale * K(:), 1e-12);
        case {'constant','ones','one'}
            rhoTarget = scale * ones(size(K(:)));
        case {'current','none'}
            rhoTarget = rho0(:);
        otherwise
            error('Unknown initialRhoProfile "%s".', profile);
    end
    fac = rhoTarget(:) ./ max(rho0(:), realmin);
    W = bsxfun(@times, W, fac);
end
end

function val = local_get_string(s, name, defaultValue)
val = defaultValue;
if isstruct(s) && isfield(s, name) && ~isempty(s.(name))
    val = char(s.(name));
end
end

function val = local_get_num(s, name, defaultValue)
val = defaultValue;
if isstruct(s) && isfield(s, name) && ~isempty(s.(name)) && isnumeric(s.(name)) && isscalar(s.(name))
    val = double(s.(name));
end
end

function tf = local_get_logical(s, name, defaultValue)
tf = defaultValue;
if isstruct(s) && isfield(s, name) && ~isempty(s.(name))
    tf = logical(s.(name));
end
end
