function par = default_params_1d(profile)
%DEFAULT_PARAMS_1D 一维 WKB/direct 程序的默认参数。
%   profile = 'baseline'      文档中的基准算例；
%   profile = 'heterogeneous' 非平凡非均匀算例。
%
%   本版本的默认设置面向小 epsilon 稳健计算：主求解器仍然推进 WKB 变量
%   (W,u)，并没有回到原始密度方程。小 epsilon 下的病态通过时间积分因子、
%   技术 gauge 平衡、well-prepared 初始质量和诊断监测来处理。

if nargin < 1 || isempty(profile)
    profile = 'baseline';
end
par.profile = profile;

%-------------------------
% 网格和时间推进参数
%-------------------------
par.Nx = 80;                  % x 方向子区间数；实际节点数为 Nx+1
par.Ntheta = 64;              % 周期 trait 网格点数
par.dt = 1e-3;                % 时间步长；若启用自适应时间步，它作为最大时间步
par.T = 20;                   % 终止时间
par.maxSteps = Inf;           % 额外最大步数；Inf 表示只受 T 控制
par.tol = 1e-8;               % 停止阈值
par.saveEvery = Inf;          % 预留字段
par.outdir = utils.output_dir(profile);

%-------------------------
% 小突变参数和初值参数
%-------------------------
par.eps = 1e-2;
par.theta0 = 0.70;            % 初始相位峰值位置，故意与 theta_m 不同
par.alpha0 = 0.05;            % 初始相位宽度参数
par.initialPhaseMode = 'peaked';    % 'peaked': 光滑峰；'flat': u=0，适合排查小 epsilon 快层
par.prepareInitialMass = true;      % true: 只缩放 W，使初始 rho 为 O(1)，避免近空种群初始快层
par.initialRhoProfile = 'scaledK';  % 'scaledK', 'constant', 或 'current'
par.initialRhoScale = 0.5;          % scaledK: rho0≈0.5*K(x)；constant: rho0≈0.5

%-------------------------
% WKB 数值格式选择
%-------------------------
par.phaseHamiltonian = 'godunov';
par.lfAlpha = 10;

% 新版默认 wkb-if-split：仍然求解 W 和 u，只对 W 方程时间零阶刚性作积分因子处理。
% 兼容旧脚本时，run_wkb_1d 会把 'density-compatible-if' 也导向该 WKB-IF 格式，
% 避免小 epsilon 下构造 exp((u_{k+1}-u_k)/eps) 的指数比值矩阵。
par.amplitudeVariant = 'wkb-if-split';
par.reactionDiscretization = 'patankar'; % 'patankar', 'implicit', 'none'；WKB 主格式默认 Patankar 保持稳态零点
par.transportImplicit = true;
par.rhoReconstruction = 'direct-log';
par.residualMode = 'wkb-steady'; % 直接监测 WKB 稳态方程；单步 residual 仍另存 history

%-------------------------
% 小 epsilon 稳健化选项
%-------------------------
par.expClip = 700;
par.gaugeMode = 'auto';              % 'auto': WKB-IF 不强制 max-gauge；旧格式用 max-gauge
par.ifGaugeBalance = true;           % WKB-IF 内部平移 u^{n+1}，控制 qW 的数值范围
par.ifRhsLogTarget = [];             % 为空时自动取 max(log(10),-0.5log(eps))
par.ifRhsLogClip = 80;               % RHS 尾部 log 限幅半宽；限幅数量写入 history
par.clipNegativeW = true;            % 将线性求解造成的极小负 W 截断
par.WFloor = 0;
par.monitorMatrixCondition = false;  % true: 对振幅矩阵做 condest，排错有用但更慢
par.enableSmallEpsMonitor = true;    % 记录 logQ、phaseCFL、峰宽/网格比等诊断量
par.monitorWarnThreshold = 80;

%-------------------------
% 可选自适应时间步
%-------------------------
par.adaptiveTimeStep = false;
par.adaptiveStrategy = 'auto';       % WKB-IF 下 auto=phase-cfl；旧格式 auto=eps-source
par.adaptiveSafety = 0.5;
par.phaseCflSafety = 0.45;
par.dtMax = [];
par.dtMin = 0;

%-------------------------
% 停止、快照和进度输出控制
%-------------------------
par.stopByResidual = true;
par.storeSnapshots = true;
par.snapshotTimes = [];
par.verbose = true;
par.progressEveryPercent = 5;
par.progressEverySeconds = 10;
par.progressEverySteps = [];
par.historyEveryTime = 0.5;
par.historyEverySteps = [];

%-------------------------
% 运行中图像监测控制
%-------------------------
par.livePlot = false;
par.livePlotMode = 'monitor';
par.livePlotEveryTime = 0.5;
par.livePlotEverySteps = [];
par.livePlotSave = false;
par.livePlotPause = 0.0;

%-------------------------
% 系数函数。baseline 对应文档中的主算例。
%-------------------------
switch lower(profile)
    case 'baseline'
        theta_m = 0.35;
        K0 = 1.0;
        K1 = 0.5;
        Dmin = 0.2;
        D1 = 0.4;
        par.theta_m = theta_m;
        par.K0 = K0;
        par.K1 = K1;
        par.Dmin = Dmin;
        par.D1 = D1;
        par.K_fun = @(x) K0 + K1 * cos(2*pi*x);
        par.D_fun = @(theta) Dmin + D1 * (1 - cos(2*pi*(theta - theta_m)));
    case 'heterogeneous'
        theta_m = 0.25;
        par.theta_m = theta_m;
        par.K_fun = @(x) 1 + 0.35*cos(2*pi*x) + 0.20*cos(4*pi*x);
        par.D_fun = @(theta) 0.15 + 0.35*(1 - cos(2*pi*(theta - theta_m))) + ...
                             0.08*(1 - cos(4*pi*(theta - theta_m)));
    otherwise
        error('Unknown profile "%s".', profile);
end
end
