function [Wnew, uWork, info] = update_w_wkb_if_split_fd_1d(W, uOld, uRaw, D, Kx, rho, H, eps, dt, op, par)
%UPDATE_W_WKB_IF_SPLIT_FD_1D WKB 框架内的时间积分因子 split 振幅更新。
%
%   本函数仍然求解 WKB 变量 W 和 u，绝不把主求解器改回原始密度 n 方程。
%   核心改动是把旧格式中的时间差分
%       eps*(W^{n+1}-W^n)/dt
%   改成 WKB 链式法则兼容的
%       eps*(W^{n+1}-q_k W^n)/dt,
%       q_k = exp((u^n_k-u^{n+1}_k)/eps).
%
%   与 density-compatible 矩阵不同，这里只使用同一 theta 节点上的 q_k，
%   不出现 exp((u_{k+1}-u_k)/eps) 的相邻点指数比值，因此小 epsilon 时不会
%   产生那类奇异矩阵。
%
%   为了避免 q_k W^n 在双精度中上溢，利用 WKB gauge 自由度给 u^{n+1}
%   加一个常数 c。这个常数不改变 u 的导数、argmax 或重构密度，只是把
%   线性系统右端的数值范围平移到安全区间。
%
%   固定 u、rho、H 后，本步仍是关于 W^{n+1} 的线性系统。默认 Patankar
%   production-destruction 处理保留稳态方程的零点，并增强非负性。

if nargin < 11 || isempty(par)
    par = struct();
end
Ktheta = op.Ntheta;
nx = op.nx;
N = nx*Ktheta;
info = struct();

reactionMode = local_get_string(par, 'reactionDiscretization', 'patankar');

%-------------------------
% 1. 计算 WKB-IF 后的零阶系数 r_if。
%    q 已经补偿相位时间变化；剩余零阶项来自 K-rho 以及 trait 方向
%    split 链式法则中的 -Hhat-eps*u_thetatheta。
%-------------------------
HhatOld = src.numerical_hamiltonian(uOld, op.dtheta, par.phaseHamiltonian, par.lfAlpha);
dduRaw = (op.Ltheta * uRaw(:)).';  % 常数 gauge 不影响二阶差分
rBase = Kx(:) - rho(:);
rIfMat = bsxfun(@plus, rBase, -HhatOld(:).' - eps*dduRaw(:).');
rIf = rIfMat(:);
rPlus = max(rIf, 0);
rMinus = max(-rIf, 0);

%-------------------------
% 2. 选择技术 gauge，使 Patankar 右端不过大。
%-------------------------
Wpos = max(real(W), realmin);
logW = log(Wpos);
logQ0 = (uOld(:).' - uRaw(:).') / eps;

switch lower(reactionMode)
    case {'patankar','production-destruction','pd','positive','positivity'}
        prodFactor = eps + dt*reshape(rPlus, nx, Ktheta);
        logProd = log(max(prodFactor, realmin));
    case {'implicit','linear-implicit','fully-implicit'}
        logProd = log(eps) * ones(nx, Ktheta);
    case {'none','off'}
        logProd = log(eps) * ones(nx, Ktheta);
        rPlus(:) = 0; rMinus(:) = 0; rIf(:) = 0;
    otherwise
        % logistic-exact 会改变与 WKB split 稳态方程完全一致的 fixed point，
        % 因此在 WKB 主格式中不作为默认；这里自动退回 Patankar 并给出诊断。
        info.reactionModeRequested = reactionMode;
        reactionMode = 'patankar';
        prodFactor = eps + dt*reshape(rPlus, nx, Ktheta);
        logProd = log(max(prodFactor, realmin));
end

logRhs0 = bsxfun(@plus, logW + logProd, logQ0);
info.rhsLogMax_beforeGauge = max(logRhs0(:));
info.rhsLogMin_beforeGauge = min(logRhs0(:));
info.logQMax_raw = max(logQ0);
info.logQMin_raw = min(logQ0);
info.qLogMaxRaw = info.logQMax_raw;
info.qLogMinRaw = info.logQMin_raw;

useBalance = local_get_bool(par, 'ifGaugeBalance', true);
if useBalance
    target = local_get_num(par, 'ifRhsLogTarget', NaN);
    if ~isfinite(target)
        target = max(log(10), -0.5*log(max(eps, realmin)));
    end
    cGauge = eps * (info.rhsLogMax_beforeGauge - target);
else
    target = max(log(10), min(max(logRhs0(:)), 50));
    cGauge = 0;
end
uWork = uRaw + cGauge;
logQ = logQ0 - cGauge/eps;
logRhs = bsxfun(@plus, logW + logProd, logQ);

clipHalfWidth = local_get_num(par, 'ifRhsLogClip', 80);
if isfinite(clipHalfWidth) && clipHalfWidth > 0
    hi = target + clipHalfWidth;
    lo = target - clipHalfWidth;
else
    hi = 700; lo = -745;
end
logRhsClip = min(max(logRhs, lo), hi);

info.ifGaugeShift = cGauge;
info.ifRhsLogTarget = target;
info.logQMax = max(logQ);
info.logQMin = min(logQ);
info.qLogMax = info.logQMax;
info.qLogMin = info.logQMin;
info.qLogAbsMax = max(abs([info.logQMax, info.logQMin]));
info.numRhsLogClippedHigh = nnz(logRhs > hi);
info.numRhsLogClippedLow = nnz(logRhs < lo);
info.qClipCount = info.numRhsLogClippedHigh + info.numRhsLogClippedLow;
info.qClipFraction = info.qClipCount / max(numel(logRhs),1);
info.rhsLogMax_afterGauge = max(logRhs(:));
info.rhsLogMin_afterGauge = min(logRhs(:));
info.rhsLogMax_afterClip = max(logRhsClip(:));
info.rhsLogMin_afterClip = min(logRhsClip(:));

b = exp(logRhsClip(:));
b(~isfinite(b)) = 0;

%-------------------------
% 3. 在 W 变量上组装线性系统。
%-------------------------
DblockLx = kron(spdiags(D(:),0,Ktheta,Ktheta), op.Lx);
Lth = op.Ltheta_big;
Tmat = src.upwind_transport_matrix(uWork, op);
A = eps*speye(N) - dt*DblockLx - dt*eps^2*Lth;
if ~isfield(par,'transportImplicit') || par.transportImplicit
    A = A + dt*2*eps*Tmat;
else
    b = b - dt*2*eps*(Tmat*W(:));
end

switch lower(reactionMode)
    case {'patankar','production-destruction','pd','positive','positivity'}
        A = A + dt*spdiags(rMinus,0,N,N);
    case {'implicit','linear-implicit','fully-implicit'}
        A = A - dt*spdiags(rIf,0,N,N);
    case {'none','off'}
        % nothing
end

info.matrixDiagMin = min(abs(diag(A)));
info.matrixDiagMax = max(abs(diag(A)));
info.matrixCondEst = NaN;
info.matrixRcondEst = NaN;
if local_get_bool(par, 'monitorMatrixCondition', false)
    try
        info.matrixCondEst = condest(A);
        info.matrixRcondEst = 1 / info.matrixCondEst;
    catch
        info.matrixCondEst = NaN;
        info.matrixRcondEst = NaN;
    end
end

Wvec = A \ b;
Wnew = reshape(real(Wvec), nx, Ktheta);
info.numNonfiniteW = nnz(~isfinite(Wnew));
Wnew(~isfinite(Wnew)) = 0;
info.minWBeforeClip = min(Wnew(:));
info.maxWBeforeClip = max(Wnew(:));
if local_get_bool(par, 'clipNegativeW', true)
    floorW = local_get_num(par, 'WFloor', 0);
    info.numNegativeW = nnz(Wnew < floorW);
    Wnew = max(Wnew, floorW);
else
    info.numNegativeW = nnz(Wnew < 0);
end

info.rIfMax = max(rIf);
info.rIfMin = min(rIf);
info.rIfPlusMax = max(max(rIf),0);
info.rIfAbsMax = max(abs(rIf));
info.WmaxAfter = max(Wnew(:));
info.WminAfter = min(Wnew(:));
info.reactionModeUsed = reactionMode;
end

function val = local_get_string(s, name, defaultValue)
val = defaultValue;
if isstruct(s) && isfield(s, name) && ~isempty(s.(name))
    val = char(s.(name));
end
end

function tf = local_get_bool(s, name, defaultValue)
tf = defaultValue;
if isstruct(s) && isfield(s, name) && ~isempty(s.(name))
    tf = logical(s.(name));
end
end

function val = local_get_num(s, name, defaultValue)
val = defaultValue;
if isstruct(s) && isfield(s, name) && ~isempty(s.(name)) && isnumeric(s.(name)) && isscalar(s.(name))
    val = double(s.(name));
end
end
