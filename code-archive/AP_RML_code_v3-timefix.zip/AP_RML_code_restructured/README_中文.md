# AP_RML_code_restructured

用于 rare-mutation dispersal-selection 模型 WKB 形式的重构版 MATLAB 程序包。

## 目录结构

- `+model`：默认参数、网格、系数函数和初始数据。
- `+src`：一维有限差分 WKB 求解器、直接密度求解器以及诊断函数。
- `+utils`：路径管理、输出目录管理、进度显示和若干小型数值工具。
- `run`：主程序文件夹。`run_main_1d.m` 是普通的单参数主程序；`run_test*.m` 用于论文中的数值实验。
- `post`：后处理脚本，用于在数据保存后生成表格和图片。
- `src_2d_legacy`：从旧程序复制过来的二维有限元 legacy 代码，并配有一个包装实验脚本。
- `doc`：说明文档、TeX 记录以及 manuscript 修改内容。

## 快速开始

在 MATLAB 中进入项目根目录后运行：

```matlab
startup_AP_RML
run_smoke_test_1d
```

若只想进行一组普通参数的计算，可运行：

```matlab
run_main_1d
```

若要运行论文中的数值实验，例如：

```matlab
run_test3_fine_grid_compare_n
```

程序会输出起始信息、预计总步数、定期进度、已用时间、预计剩余时间、residual、当前选中特征以及最终保存路径。输出频率由以下参数控制：

```matlab
par.verbose = true;
par.progressEveryPercent = 5;
par.progressEverySeconds = 10;
par.progressEverySteps = [];
par.historyEveryTime = 0.2;
```

所有输出目录都通过 `utils.output_dir` 和 `utils.resolve_path` 相对于项目根目录进行解析。因此，脚本既可以从项目根目录运行，也可以从 `run/` 文件夹或其他当前工作目录运行。二维 legacy 路径只会在调用 `startup_AP_RML(true)` 或运行 `run_test6_2d_legacy` 时加入。

## 2026 时间步长与 residual 更新

本版本加入了 `time_step_issue_note.pdf` 中讨论的时间离散修正，主要包括以下内容。

- `par.amplitudeVariant = 'density-compatible-if'` 使用时间方向 density-compatible / integrating-factor 振幅更新，其中
  ```matlab
  q_k = exp((u_k^n-u_k^{n+1})/eps)
  ```
  该处理使全离散密度变量
  ```matlab
  n = W.*exp(u/eps)
  ```
  与密度层面的时间差分保持一致，从而减弱旧 split-WKB 时间离散中的 WKB 链式法则误差。

- `par.reactionDiscretization = 'patankar'` 在 density-compatible WKB 更新和直接密度求解器中使用 production-destruction 型反应项处理。若设为 `'implicit'`，则恢复旧的线性隐式反应项处理。

- `par.residualMode = 'gauge-invariant'` 使 WKB 停止准则使用重构密度 `n` 和模去常数后的相位变量，而不是直接使用依赖 gauge 的 `W`。旧的基于 `W` 的 residual 仍保存为
  ```matlab
  history.residual_W_legacy
  ```
  若需要旧模式，可设置
  ```matlab
  par.residualMode = 'legacy'
  ```

- `par.adaptiveTimeStep = true` 会开启可选的时间步长保护：
  ```matlab
  dt <= par.adaptiveSafety*eps/max(1,max r_+,max(abs(H)))
  ```
  其中 `par.dt` 作为最大允许时间步长。

旧的 split 更新仍可通过

```matlab
par.amplitudeVariant = 'split'
```

调用。此前的全离散 density-compatible 实现也保留为

```matlab
par.amplitudeVariant = 'density-compatible-semidiscrete'
```

用于对比实验。
