% RUN_MAIN_1D 普通一维主程序：只跑一组参数，不做成组数值测试。
% 用法：
%   startup_AP_RML
%   run_main_1d
%
% 说明：
%   这个脚本适合日常检查模型、生成一组基准数据或调参数。
%   与 run_test*.m 不同，这里没有 eps/grid 的循环，也不计算测试表格。
%
% 运行速度提醒：
%   WKB 主程序每一步都要对每个 theta_k 求一个 x 方向主特征值。因此运行时间
%   对 Nx 和 Ntheta 很敏感。旧代码常用 N_x=5, N_theta=50；如果这里直接用
%   Nx=200, Ntheta=128，会比旧代码慢很多。建议先用 runMode='quick' 调通，
%   最后生成正式数据时再改成 'paper'。

root = fileparts(fileparts(mfilename('fullpath')));
addpath(root);
startup_AP_RML;

%==============================
% 0. 选择运行模式
%==============================
% 'quick' : 日常调试和看现象，较快；
% 'paper' : 接近论文正式数据，较慢；
% 'oldlike' : 接近旧代码网格规模，非常快，但 x 方向很粗，只适合排错。
runMode = 'quick';

%==============================
% 1. 选择模型和数值参数
%==============================
par = model.default_params_1d('baseline');   % 'baseline' 或 'heterogeneous'
par.eps = 1e-2;

switch lower(runMode)
    case 'quick'
        par.Nx = 50;
        par.Ntheta = 64;
        par.T = 10;
        par.dt = 2e-3;
        par.tol = 1e-8;
        par.historyEveryTime = 1.0;
        par.storeSnapshots = false;
        par.snapshotTimes = [];
    case 'paper'
        par.Nx = 200;
        par.Ntheta = 128;
        par.T = 30;
        par.dt = 1e-3;
        par.tol = 1e-9;
        par.historyEveryTime = 0.5;
        par.storeSnapshots = true;
        par.snapshotTimes = [1, 5, 10, 20, par.T];
    case 'oldlike'
        par.Nx = 10;          % 比旧代码 N_x=5 略细，但仍然很快
        par.Ntheta = 50;
        par.T = 5;
        par.dt = 2e-3;
        par.tol = 1e-8;
        par.historyEveryTime = 1.0;
        par.storeSnapshots = false;
        par.snapshotTimes = [];
    otherwise
        error('Unknown runMode "%s".', runMode);
end

% WKB 格式选项。
par.phaseHamiltonian = 'godunov';            % 'godunov', 'lf', 或 'weno5'
par.amplitudeVariant = 'density-compatible-if'; % 新版默认：时间方向 density-compatible / integrating-factor
par.reactionDiscretization = 'patankar';   % 新版默认：Patankar 型反应项，增强保正性
par.residualMode = 'gauge-invariant';      % 新版默认：基于重构密度的 gauge-invariant residual
par.rhoReconstruction = 'direct-log';

% 若希望在给定 dt 偏大时自动缩小时间步，可设为 true。
% 自适应准则约为 dt <= eta*eps/max(1,max r_+,max|H|)。
par.adaptiveTimeStep = false;
par.adaptiveSafety = 0.5;
par.dtMax = par.dt;

% 输出和进度控制。
par.outdir = utils.output_dir(['main_single_case_' runMode]);
par.verbose = true;
par.progressEveryPercent = 5;                % 每 5%% 预计进度至少输出一次
par.progressEverySeconds = 10;               % 或每 10 秒输出一次


% 运行过程中的图像监测。和旧代码边算边画的思路一致。
% 注意：会稍微增加耗时，因此 paper 档默认关闭。
switch lower(runMode)
    case 'quick'
        par.livePlot = true;
        par.livePlotEveryTime = 0.5;
    case 'oldlike'
        par.livePlot = true;
        par.livePlotEveryTime = 0.5;
    otherwise
        par.livePlot = false;
        par.livePlotEveryTime = 2.0;
end
par.livePlotEverySteps = [];
par.livePlotSave = false;                    % 若想保存在线图帧，改成 true
par.livePlotPause = 0.0;                     % 若想每次刷新后暂停，可设成 0.1 等

% 是否同时跑直接密度方程。默认 false，因为 direct 在小 eps 下更慢且容易欠分辨。
runDirect = false;

fprintf('\n========== RUN_MAIN_1D: 单组参数主程序 ==========' );
fprintf('\nrunMode=%s, profile=%s, eps=%.4g, Nx=%d, Ntheta=%d, T=%.4g, dt=%.4g\n', ...
    runMode, par.profile, par.eps, par.Nx, par.Ntheta, par.T, par.dt);
fprintf('预计最多步数: %d；WKB 未知量规模约: %d x %d = %d\n', ...
    ceil(par.T/par.dt), par.Nx+1, par.Ntheta, (par.Nx+1)*par.Ntheta);
fprintf('outdir=%s\n', par.outdir);
fprintf('livePlot=%d, livePlotEveryTime=%.4g\n', par.livePlot, par.livePlotEveryTime);

%==============================
% 2. 运行 WKB 求解器
%==============================
wkb = src.run_wkb_1d(par);

%==============================
% 3. 可选：运行原始密度方程直接求解器
%==============================
if runDirect
    direct = src.run_direct_1d(par); %#ok<SNASGU>
else
    direct = []; %#ok<NASGU>
end

%==============================
% 4. 保存本次单组运行摘要
%==============================
summary = struct();
summary.runMode = runMode;
summary.profile = par.profile;
summary.eps = par.eps;
summary.Nx = par.Nx;
summary.Ntheta = par.Ntheta;
summary.T = par.T;
summary.dt = par.dt;
summary.amplitudeVariant = par.amplitudeVariant;
summary.reactionDiscretization = par.reactionDiscretization;
summary.residualMode = par.residualMode;
summary.adaptiveTimeStep = par.adaptiveTimeStep;
summary.theta_m = par.theta_m;
summary.theta_wkb = wkb.diagnostics.theta_wkb;
summary.err_wkb_to_m = wkb.diagnostics.err_wkb_to_m;
summary.sigma_theta = wkb.diagnostics.sigma_theta;
summary.rho_max = wkb.diagnostics.rho_max;
summary.gammaR = wkb.diagnostics.gammaR;
summary.residual = wkb.residual;
summary.steps = wkb.step;

utils.ensure_dir(par.outdir);
save(fullfile(par.outdir, 'summary_main_1d.mat'), 'summary', 'wkb', 'direct');

disp('RUN_MAIN_1D 摘要:');
disp(summary);
fprintf('RUN_MAIN_1D 完成。结果目录: %s\n', par.outdir);
