function [residual, info] = compute_wkb_residual_1d(Wnew, unew, Wold, uold, eps, dt, op, mode)
%COMPUTE_WKB_RESIDUAL_1D Gauge-aware residual for WKB variables.
%   mode='gauge-invariant' (default) uses the phase modulo constants and the
%   reconstructed density n=W*exp(u/eps):
%
%       max( ||u^{n+1}-u^n||_gauge/dt,
%            ||n^{n+1}-n^n||/(dt*(1+||n^{n+1}||)) ).
%
%   mode='legacy' reproduces the old W-based residual, which is not invariant
%   under the max-gauge normalization.
if nargin < 8 || isempty(mode)
    mode = 'gauge-invariant';
end
mode = lower(char(mode));

unewGauge = unew(:) - max(unew(:));
uoldGauge = uold(:) - max(uold(:));
resU = max(abs(unewGauge - uoldGauge)) / dt;

[~, nnew] = src.reconstruct_rho_1d(Wnew, unew, eps, op, 'direct-log');
[~, nold] = src.reconstruct_rho_1d(Wold, uold, eps, op, 'direct-log');
resN = max(abs(nnew(:)-nold(:))) / (dt*(1 + max(abs(nnew(:)))));
resWLegacy = max(abs(Wnew(:)-Wold(:))) / (dt*(1 + max(abs(Wnew(:)))));

switch mode
    case {'gauge-invariant','density','density-gauge','invariant'}
        residual = max(resU, resN);
    case {'density-only','n'}
        residual = resN;
    case {'legacy','w','old'}
        residual = max(resU, resWLegacy);
    otherwise
        error('Unknown residualMode "%s".', mode);
end

info = struct();
info.mode = mode;
info.res_u = resU;
info.res_n = resN;
info.res_W_legacy = resWLegacy;
info.residual = residual;
end
