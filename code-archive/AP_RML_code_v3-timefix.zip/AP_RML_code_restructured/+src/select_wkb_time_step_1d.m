function [dtStep, info] = select_wkb_time_step_1d(par, t, W, u, D, Kx, rho, H, op, variant)
%SELECT_WKB_TIME_STEP_1D Optional adaptive time-step selector.
%   If par.adaptiveTimeStep is false, this returns min(par.dt,T-t).  If it is
%   true, the step is restricted according to
%
%       dt <= eta*eps / max(1, max r_+, max |H|),
%
%   where eta=par.adaptiveSafety.  The user-provided par.dt is treated as the
%   maximum step size unless par.dtMax is explicitly smaller.
if nargin < 10 || isempty(variant)
    variant = 'split';
end
baseDt = get_num(par, 'dt', 1e-3);
T = get_num(par, 'T', Inf);
eps = get_num(par, 'eps', 1);
dtMax = baseDt;
% par.dt is always the default maximum step.  par.dtMax is an optional extra
% cap, mainly useful when adaptiveTimeStep=true.
if isfield(par, 'dtMax') && ~isempty(par.dtMax) && isnumeric(par.dtMax) && isscalar(par.dtMax)
    if isfinite(double(par.dtMax)) && double(par.dtMax) > 0
        dtMax = min(baseDt, double(par.dtMax));
    end
end
remaining = T - t;
if isfinite(remaining)
    dtMax = min(dtMax, max(remaining, 0));
end

useAdaptive = false;
if isfield(par, 'adaptiveTimeStep') && ~isempty(par.adaptiveTimeStep)
    useAdaptive = logical(par.adaptiveTimeStep);
elseif isfield(par, 'useAdaptiveDt') && ~isempty(par.useAdaptiveDt)
    useAdaptive = logical(par.useAdaptiveDt);
end

info = src.time_step_stability_info_1d(W, u, Kx, rho, H, eps, max(dtMax,realmin), op, par, variant);
info.dtSuggested = dtMax;
info.dtLimited = false;

if useAdaptive
    eta = get_num(par, 'adaptiveSafety', 0.5);
    if ~(isfinite(eta) && eta > 0)
        eta = 0.5;
    end
    denom = max([1, info.rplusMax, info.HabsMax]);
    dtCand = eta * eps / denom;
    info.dtSuggested = dtCand;
    if isfinite(dtCand) && dtCand > 0
        info.dtLimited = dtCand < dtMax;
        dtMax = min(dtMax, dtCand);
    end
end

dtMin = get_num(par, 'dtMin', 0);
if isfinite(dtMin) && dtMin > 0 && dtMax < dtMin && remaining > dtMin
    dtMax = dtMin;
end

dtStep = max(dtMax, 0);
info.dt = dtStep;
info.dtOverEps = dtStep / eps;
info.lambdaR = dtStep / eps * info.rplusMax;
info.lambdaH = dtStep / eps * info.HabsMax;
end

function val = get_num(s, name, defaultValue)
val = defaultValue;
if isstruct(s) && isfield(s, name) && ~isempty(s.(name)) && isnumeric(s.(name)) && isscalar(s.(name))
    val = double(s.(name));
end
end
