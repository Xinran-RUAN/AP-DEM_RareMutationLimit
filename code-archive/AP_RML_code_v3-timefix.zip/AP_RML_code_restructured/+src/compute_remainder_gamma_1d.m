function gammaR = compute_remainder_gamma_1d(W, u, D, eps, op, par, variant)
%COMPUTE_REMAINDER_GAMMA_1D Weighted positive-remainder diagnostic.
if nargin < 7 || isempty(variant)
    variant = 'split';
end
[~, n] = src.reconstruct_rho_1d(W, u, eps, op, 'direct-log');
Ktheta = op.Ntheta;
nx = op.nx;
E = exp(u/eps);
switch lower(variant)
    case {'density-compatible','dc','density-compatible-if','dc-if','density-if','integrating-factor','density-compatible-semidiscrete','dc-semidiscrete','density-compatible-old','dc-old'}
        Rvec = eps^2 * (op.Ltheta_big * n(:));
        R = reshape(Rvec, nx, Ktheta);
    otherwise
        Hhat = src.numerical_hamiltonian(u, op.dtheta, par.phaseHamiltonian, par.lfAlpha);
        ddu = (op.Ltheta * u(:)).';
        ddW = reshape(op.Ltheta_big * W(:), nx, Ktheta);
        T = src.upwind_transport_matrix(u, op);
        DthetaF = reshape(T * W(:), nx, Ktheta);
        WE = bsxfun(@times, W, E);
        R = eps^2*bsxfun(@times, ddW, E) - eps*bsxfun(@times, WE, ddu) ...
            - bsxfun(@times, WE, Hhat) - 2*eps*bsxfun(@times, DthetaF, E);
end
RD = op.dtheta * sum(bsxfun(@rdivide, R, D), 2);
m = op.dtheta * sum(n, 2);
gammaR = max(max(RD,0) ./ (m + 1e-14));
end
