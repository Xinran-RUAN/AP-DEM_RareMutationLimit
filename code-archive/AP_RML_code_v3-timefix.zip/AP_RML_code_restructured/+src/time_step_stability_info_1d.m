function info = time_step_stability_info_1d(W, u, Kx, rho, H, eps, dt, op, par, variant)
%TIME_STEP_STABILITY_INFO_1D Diagnostics for dt/eps stiffness indicators.
%   The indicators are meant as practical safeguards, not sharp stability
%   theorems.  For split WKB they use the local positive growth rate appearing
%   in the amplitude equation.  For the time-density-compatible variant, the
%   amplitude source is K-rho, while max|H| is still reported because H drives
%   the phase and the gauge shift.
if nargin < 10 || isempty(variant)
    variant = 'split';
end
if nargin < 9 || isempty(par)
    par = struct();
end

variant = lower(char(variant));
Ktheta = op.Ntheta;

switch variant
    case {'split','split-wkb'}
        ddu = (op.Ltheta * u(:)).';
        extra = -2*eps*ddu;
        r = src.reaction_vector_1d(Kx, rho, H, extra, op);
    case {'density-compatible-semidiscrete','dc-semidiscrete','density-compatible-old','dc-old'}
        ddu = (op.Ltheta * u(:)).';
        Hhat = src.numerical_hamiltonian(u, op.dtheta, par.phaseHamiltonian, par.lfAlpha);
        extra = Hhat - eps*ddu;
        r = src.reaction_vector_1d(Kx, rho, H, extra, op);
    otherwise
        % Time-density-compatible / integrating-factor update: H terms are
        % absorbed by the q_k factor, so the amplitude source is K-rho.
        rBase = Kx(:) - rho(:);
        r = repmat(rBase, Ktheta, 1);
end

info = struct();
info.rplusMax = max(max(r), 0);
info.rabsMax = max(abs(r));
info.HabsMax = max(abs(H(:)));
info.dtOverEps = dt / eps;
info.lambdaR = dt / eps * info.rplusMax;
info.lambdaH = dt / eps * info.HabsMax;
if ~isempty(W)
    info.Wmin = min(W(:));
else
    info.Wmin = NaN;
end
end
