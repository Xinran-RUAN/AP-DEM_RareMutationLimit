function history = append_history(history, t, residual, diag, resInfo, dtInfo)
%APPEND_HISTORY Append scalar diagnostics to a history struct.
%   resInfo and dtInfo are optional.  They store the new gauge-invariant
%   residual components and the adaptive time-step diagnostics.
if nargin < 5 || isempty(resInfo)
    resInfo = struct();
end
if nargin < 6 || isempty(dtInfo)
    dtInfo = struct();
end
if isempty(history)
    history.t = [];
    history.dt = [];
    history.residual = [];
    history.residual_u = [];
    history.residual_n = [];
    history.residual_W_legacy = [];
    history.lambdaR = [];
    history.lambdaH = [];
    history.rplusMax = [];
    history.HabsMax = [];
    history.theta_wkb = [];
    history.theta_direct = [];
    history.err_wkb_to_m = [];
    history.err_direct_to_m = [];
    history.sigma_theta = [];
    history.Hmin = [];
    history.H_at_wkb = [];
    history.gammaR = [];
    history.rho_max = [];
    history.W_min = [];
end
history.t(end+1,1) = t;
history.residual(end+1,1) = residual;
history.dt(end+1,1) = get_field(dtInfo, 'dt', NaN);
history.residual_u(end+1,1) = get_field(resInfo, 'res_u', NaN);
history.residual_n(end+1,1) = get_field(resInfo, 'res_n', NaN);
history.residual_W_legacy(end+1,1) = get_field(resInfo, 'res_W_legacy', NaN);
history.lambdaR(end+1,1) = get_field(dtInfo, 'lambdaR', NaN);
history.lambdaH(end+1,1) = get_field(dtInfo, 'lambdaH', NaN);
history.rplusMax(end+1,1) = get_field(dtInfo, 'rplusMax', NaN);
history.HabsMax(end+1,1) = get_field(dtInfo, 'HabsMax', NaN);
history.theta_wkb(end+1,1) = diag.theta_wkb;
history.theta_direct(end+1,1) = diag.theta_direct;
history.err_wkb_to_m(end+1,1) = diag.err_wkb_to_m;
history.err_direct_to_m(end+1,1) = diag.err_direct_to_m;
history.sigma_theta(end+1,1) = diag.sigma_theta;
history.Hmin(end+1,1) = diag.Hmin;
history.H_at_wkb(end+1,1) = diag.H_at_wkb;
history.gammaR(end+1,1) = diag.gammaR;
history.rho_max(end+1,1) = diag.rho_max;
history.W_min(end+1,1) = diag.W_min;
end

function val = get_field(s, name, defaultValue)
val = defaultValue;
if isstruct(s) && isfield(s, name) && ~isempty(s.(name)) && isnumeric(s.(name)) && isscalar(s.(name))
    val = double(s.(name));
end
end
