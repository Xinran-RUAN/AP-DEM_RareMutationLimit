function [Wn, un, c] = normalize_gauge(W, u, eps, mode)
%NORMALIZE_GAUGE Shift u and rescale W without changing n = W exp(u/eps).
if nargin < 4 || isempty(mode)
    mode = 'max';
end
switch lower(mode)
    case 'max'
        c = max(u);
    case 'none'
        c = 0;
    otherwise
        error('Unknown gauge mode "%s".', mode);
end
un = u - c;
Wn = W * exp(c/eps);
end
