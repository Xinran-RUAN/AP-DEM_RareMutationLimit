function [rho, n, info] = reconstruct_rho_1d(W, u, eps, op, mode)
%RECONSTRUCT_RHO_1D 由 WKB 变量重构 n 和 rho。
%   n(x,theta) = W(x,theta) * exp(u(theta)/eps)
%   rho(x)     = int n(x,theta) dtheta
%
% direct-log 模式先减去 max(u)，避免 exp(u/eps) 在小 eps 下上溢/下溢。
% laplace / laplace-hybrid 主要作为后处理诊断，用于测试少量 theta 点时
% 是否仍能准确定位集中位置。
if nargin < 5 || isempty(mode)
    mode = 'direct-log';
end
info = struct('mode', mode, 'usedFallback', false, 'thetaStar', NaN, 'dduStar', NaN);
switch lower(mode)
    case {'direct','direct-log'}
        s = max(u);
        Ew = exp((u - s)/eps);
        factor = exp(s/eps);
        n = factor * bsxfun(@times, W, Ew);
        rho = op.dtheta * sum(n, 2);
    case 'laplace'
        [rho, n, info] = src.reconstruct_laplace_1d(W, u, eps, op, false);
    case {'laplace-hybrid','hybrid-laplace'}
        [rho, n, info] = src.reconstruct_laplace_1d(W, u, eps, op, true);
    otherwise
        error('Unknown rho reconstruction mode "%s".', mode);
end
rho = real(rho(:));
end
