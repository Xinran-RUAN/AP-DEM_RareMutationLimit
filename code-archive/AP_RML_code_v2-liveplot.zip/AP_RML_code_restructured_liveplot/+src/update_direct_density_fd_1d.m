function nNew = update_direct_density_fd_1d(n, D, Kx, eps, dt, op)
%UPDATE_DIRECT_DENSITY_FD_1D 原始密度方程 n 的半隐式一步更新。
%   用于和 WKB 方法做对比。rho 使用当前 n^n 显式计算，扩散和反应
%   对 n^{n+1} 隐式，从而每一步只需求解一个线性系统。
Ktheta = op.Ntheta;
nx = op.nx;
N = nx*Ktheta;

rho = op.dtheta * sum(n, 2);
DblockLx = kron(spdiags(D(:),0,Ktheta,Ktheta), op.Lx);
Lth = op.Ltheta_big;
r = src.reaction_vector_1d(Kx, rho, zeros(1,Ktheta), zeros(1,Ktheta), op);

A = eps*speye(N) - dt*DblockLx - dt*eps^2*Lth - dt*spdiags(r,0,N,N);
b = eps*n(:);
nNew = reshape(A \ b, nx, Ktheta);
nNew = real(nNew);
end
