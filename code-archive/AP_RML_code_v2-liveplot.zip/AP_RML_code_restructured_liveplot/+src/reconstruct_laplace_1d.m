function [rho, n, info] = reconstruct_laplace_1d(W, u, eps, op, allowFallback)
%RECONSTRUCT_LAPLACE_1D Periodic three-point Laplace reconstruction.
% The local coordinate of the stencil is {-dtheta,0,dtheta}, avoiding the
% periodic-boundary bug that occurs if theta_{K} is used as 1-dtheta near 0.
if nargin < 5
    allowFallback = true;
end
K = op.Ntheta;
dth = op.dtheta;
[~, k] = max(u);
km = mod(k-2, K) + 1;
kp = mod(k, K) + 1;
um = u(km); u0 = u(k); up = u(kp);
denom = up - 2*u0 + um;
ddu = denom / dth^2;
info = struct('mode','laplace','usedFallback',false,'thetaStar',NaN,'dduStar',ddu);

bad = (~isfinite(ddu)) || ddu >= -1e-14 || abs(denom) < 1e-14;
if bad
    if allowFallback
        [rho, n] = src.reconstruct_rho_1d(W, u, eps, op, 'direct-log');
        info.usedFallback = true;
        info.mode = 'direct-log-fallback';
        return;
    else
        error('Laplace reconstruction failed: nonnegative or nearly zero second derivative at the maximum.');
    end
end

zStar = -0.5*dth*(up - um)/denom;
zStar = max(min(zStar, dth), -dth);
info.thetaStar = mod(op.theta(k) + zStar, 1);

zm = -dth; z0 = 0; zp = dth;
L1 = (zStar - z0)*(zStar - zp)/((zm-z0)*(zm-zp));
L2 = (zStar - zm)*(zStar - zp)/((z0-zm)*(z0-zp));
L3 = (zStar - zm)*(zStar - z0)/((zp-zm)*(zp-z0));
Wstar = W(:,km)*L1 + W(:,k)*L2 + W(:,kp)*L3;
Ustar = um*L1 + u0*L2 + up*L3;
rho = Wstar * exp(Ustar/eps) * sqrt(2*pi*eps/abs(ddu));
% Also return nodal n for diagnostics; this is not the Laplace approximation.
[~, n] = src.reconstruct_rho_1d(W, u, eps, op, 'direct-log');
end
