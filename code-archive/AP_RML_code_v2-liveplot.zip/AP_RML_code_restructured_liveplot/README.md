# AP_RML_code_restructured

Restructured MATLAB code for the WKB formulation of the rare-mutation dispersal-selection model.

## Layout

- `+model`: default parameters, grids, coefficient profiles, and initial data.
- `+src`: core numerical solvers and diagnostics for the 1D finite-difference WKB/direct solvers.
- `+utils`: path, output, progress display, and small numerical utilities.
- `run`: main scripts. `run_main_1d.m` is the ordinary one-case main program; `run_test*.m` are numerical experiments.
- `post`: post-processing scripts to generate tables/plots after data are saved.
- `src_2d_legacy`: 2D FEM legacy routines copied from the old code, with a wrapper experiment script.
- `doc`: notes and TeX/manuscript updates.

## Quick start

From the project root in MATLAB:

```matlab
startup_AP_RML
run_smoke_test_1d
```

For a normal single-parameter run, use:

```matlab
run_main_1d
```

For manuscript experiments, run for example:

```matlab
run_test3_fine_grid_compare_n
```

The solvers now print start information, estimated total steps, periodic progress lines, elapsed time, ETA, residual, selected trait, and final save paths. The output frequency is controlled by these fields in `par`:

```matlab
par.verbose = true;
par.progressEveryPercent = 5;
par.progressEverySeconds = 10;
par.progressEverySteps = [];
par.historyEveryTime = 0.2;
```

All output directories are resolved relative to the project root through `utils.output_dir` / `utils.resolve_path`, so scripts can be launched from the project root, from `run/`, or from another current folder. The 2D legacy path is added only when calling `startup_AP_RML(true)` or running `run_test6_2d_legacy`.
