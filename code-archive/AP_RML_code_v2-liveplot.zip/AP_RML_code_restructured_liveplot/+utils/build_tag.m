function tag = build_tag(par)
%BUILD_TAG Build a compact filename tag.
tag = sprintf('%s_eps%.3g_Nx%d_K%d_dt%.3g_%s_%s', par.profile, par.eps, par.Nx, par.Ntheta, par.dt, par.amplitudeVariant, par.rhoReconstruction);
tag = regexprep(tag, '[^A-Za-z0-9_\.-]', '_');
end
