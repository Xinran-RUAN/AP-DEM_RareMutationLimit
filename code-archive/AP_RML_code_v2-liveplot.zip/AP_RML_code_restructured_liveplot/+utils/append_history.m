function history = append_history(history, t, residual, diag)
%APPEND_HISTORY Append scalar diagnostics to a history struct.
if isempty(history)
    history.t = [];
    history.residual = [];
    history.theta_wkb = [];
    history.theta_direct = [];
    history.err_wkb_to_m = [];
    history.err_direct_to_m = [];
    history.sigma_theta = [];
    history.Hmin = [];
    history.H_at_wkb = [];
    history.gammaR = [];
    history.rho_max = [];
    history.W_min = [];
end
history.t(end+1,1) = t;
history.residual(end+1,1) = residual;
history.theta_wkb(end+1,1) = diag.theta_wkb;
history.theta_direct(end+1,1) = diag.theta_direct;
history.err_wkb_to_m(end+1,1) = diag.err_wkb_to_m;
history.err_direct_to_m(end+1,1) = diag.err_direct_to_m;
history.sigma_theta(end+1,1) = diag.sigma_theta;
history.Hmin(end+1,1) = diag.Hmin;
history.H_at_wkb(end+1,1) = diag.H_at_wkb;
history.gammaR(end+1,1) = diag.gammaR;
history.rho_max(end+1,1) = diag.rho_max;
history.W_min(end+1,1) = diag.W_min;
end
