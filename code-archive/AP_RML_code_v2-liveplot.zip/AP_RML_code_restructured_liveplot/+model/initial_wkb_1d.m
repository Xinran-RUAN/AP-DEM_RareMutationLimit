function [W, u, D, K, grid] = initial_wkb_1d(par)
%INITIAL_WKB_1D Initial data and coefficients for the WKB solver.
grid = model.make_grid_1d(par);
x = grid.x;
theta = grid.theta;
D = par.D_fun(theta);
K = par.K_fun(x);

u = -par.alpha0 * (1 - cos(2*pi*(theta - par.theta0)));
W = repmat(1 + 0.1*cos(2*pi*x), 1, par.Ntheta);
[W, u] = src.normalize_gauge(W, u, par.eps, 'max');
end
