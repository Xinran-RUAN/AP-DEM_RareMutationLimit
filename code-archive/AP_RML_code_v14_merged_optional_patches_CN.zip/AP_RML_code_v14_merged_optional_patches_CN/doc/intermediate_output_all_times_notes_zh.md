# 中间时刻完整数据保存说明

本次修改的目标是：WKB、time-AP/projective WKB 和 direct solver 在计算过程中都能按指定输出时刻保存完整数据，而不是只保存最终结果或只保存 history 标量诊断。

## 主要改动

1. 新增通用保存工具
   - `+utils/intermediate_save_init.m`
   - `+utils/intermediate_save_due.m`
   - `+utils/intermediate_save_step.m`
   - `+utils/intermediate_save_force_latest.m`

2. 修改 `+src/run_wkb_1d.m`
   - 普通 frozen-H WKB 路径现在也会保存 full snapshots。
   - 保存内容包括 `W, u, n, rho, H, D, Kx, grid, op, par, t, step, residual, history, diagnostics` 等。
   - 最终或失败退出时会强制写一次 `latest_checkpoint.mat`。

3. 修改 `+src/run_direct_1d.m`
   - direct solver 现在也会保存 full snapshots。
   - 保存内容包括 `n, rho, D, Kx, grid, op, par, t, step, residual, history, diagnostics, W0, u0` 等。
   - direct 的最近 checkpoint 默认保存为 `latest_checkpoint_direct.mat`，避免覆盖 WKB 的 `latest_checkpoint.mat`。

4. 修改 `run/run_main_1d.m`
   - `snapshotEveryTime` 改为与 `historyEveryTime` 一致。
   - `checkpointEveryTime` 也改为与 `historyEveryTime` 一致。
   - 因此 quick 模式默认每 1 个时间单位保存一次完整中间数据，paper 模式默认每 0.5 个时间单位保存一次完整中间数据。

5. 修改 `run/run_test3_fine_grid_compare_n.m`
   - 数值实验 3 默认保存 WKB 和 direct 的中间时刻完整数据。

## 输出文件位置

设输出目录为 `par.outdir`。完整中间数据保存到

```matlab
fullfile(par.outdir, 'snapshots')
```

文件名格式为

```text
<tag>_stepXXXXXXX_tYYYY.mat
```

例如 WKB 和 direct 会分别生成类似

```text
baseline_eps0.0001_..._step0001000_t1.mat
baseline_eps0.0001_..._direct_step0001000_t1.mat
```

此外最近状态会保存为

```text
latest_checkpoint.mat          % WKB 最近状态
latest_checkpoint_direct.mat   % direct 最近状态
```

## 常用设置

若希望每隔 1 个时间单位保存一次完整数据，可设置

```matlab
par.storeSnapshots = true;
par.snapshotEveryTime = 1.0;
par.saveLatestCheckpoint = true;
par.checkpointEveryTime = 1.0;
par.saveHistoryCheckpoint = true;
```

若希望与 history 记录频率完全一致，可设置

```matlab
par.snapshotEveryTime = par.historyEveryTime;
par.checkpointEveryTime = par.historyEveryTime;
```

不建议默认每个时间步都保存完整矩阵，因为 quick 模式也有约 20000 步，会产生大量 `.mat` 文件。
