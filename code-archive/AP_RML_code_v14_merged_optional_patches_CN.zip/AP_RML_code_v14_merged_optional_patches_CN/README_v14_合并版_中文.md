# AP_RML_code v14 合并版（旧版复现 + v13 可选补丁）

本目录由两个版本合并而来：

- 旧版：`AP_RML_code_restructured_liveplot_副本`
- 新版：`AP_RML_code_v13_timeAP_checkpoint_fix_save_all_mid`

合并原则是：**默认尽量复现旧版行为；v13 中的小 epsilon、time-AP、checkpoint、自动重构等修改全部保留，但改成显式可选项。**

---

## 1. 最重要的约定：画 `P(theta)` 时不要直接插值 `P`

对 WKB 结果画 trait marginal 时，正确顺序是：

```matlab
W(theta), u(theta) 先分别插值到细 theta 网格
n_fine = W_fine .* exp(u_fine/eps)
P(theta) = integral_x n_fine(x,theta) dx
```

不要先在粗网格上算

```matlab
P_k = integral_x W(x,theta_k).*exp(u(theta_k)/eps) dx
```

再对 `P_k` 插值。小 epsilon 下 `P` 可能非常尖，直接插值 `P` 会把相位指数和振幅混在一起，导致峰位、峰宽和质量都可能失真。

合并版新增了统一后处理接口：

```matlab
[P, nFine, WFine, UFine, thetaFine] = src.reconstruct_trait_marginal_from_wkb_1d( ...
    W, u, op, eps, thetaFine, 'spline');
```

已更新/保留的相关脚本：

- `post/post_test3_compare_n_reconstruction.m`
- `post/plot_test3_Ptheta_refinement.m`
- `post/plot_test3_trait_marginal.m`
- `post/post_test2_Ptheta.m`
- `post/post_plot_test2_Ptheta_eps.m`

其中 WKB 曲线都优先按 `W,u -> n -> P` 顺序处理；direct 解则按 `n -> P` 处理，即如果需要细化 theta，也先插值 `n(x,theta)`，再对 x 积分。

---

## 2. 默认行为：复现旧版

默认参数位于：

```matlab
+model/default_params_1d.m
```

默认设置偏向旧版：

```matlab
par = model.default_params_1d('baseline');
```

主要默认值：

```matlab
par.initialPhaseMode       = 'flat';       % u(theta)=0
par.initialAmplitudeMode   = 'flat-rho';   % W(x,theta)=1
par.initialGaugeMode       = 'legacy-max';
par.prepareInitialMass     = false;

par.timeIntegrator         = 'frozen';
par.phaseHamiltonian       = 'weno5';
par.amplitudeVariant       = 'split';
par.reactionDiscretization = 'implicit';
par.rhoReconstruction      = 'direct-log';
par.residualMode           = 'legacy';

par.smallEpsAutoPatches    = false;
par.enableV13AutoPatches   = false;
par.hamiltonianGauge       = 'none';
par.ifMode                 = 'none';
par.thetaRephase           = false;
par.enableStepRetry        = false;
```

`baseline` 模型也恢复为旧版形式：

```matlab
K(x) = K0 - K1*cos(2*pi*x)
```

如果需要复现 v13 曾经使用的符号相反模型，可用：

```matlab
par = model.default_params_1d('baseline-v13');
```

---

## 3. v13 补丁现在全部显式开启

新增预设函数：

```matlab
+model/apply_patch_preset_1d.m
```

用法：

```matlab
par = model.default_params_1d('baseline');
par = model.apply_patch_preset_1d(par, 'legacy');          % 强制旧版
par = model.apply_patch_preset_1d(par, 'v13-small-eps');   % v13 小 epsilon 稳健补丁
par = model.apply_patch_preset_1d(par, 'v13-projective');  % time-AP projective 实验
par = model.apply_patch_preset_1d(par, 'v13-implicit');    % time-AP implicit-coupled 实验
```

`v13-small-eps` 会显式打开：

```matlab
par.amplitudeVariant       = 'wkb-if-split';
par.reactionDiscretization = 'logistic-exact';
par.rhoReconstruction      = 'laplace-hybrid';
par.residualMode           = 'wkb-steady';
par.hamiltonianGauge       = 'min';
par.ifMode                 = 'h-only';
par.useSubgridPhasePeak    = true;
par.adaptiveIfLogRange     = true;
par.enableStepRetry        = true;
```

注意：`v13-small-eps` 仍然可以在调用后手动覆盖任意字段。例如想用旧版 flat 初值但试新版 WKB-IF，可以写：

```matlab
par = model.default_params_1d('baseline');
par = model.apply_patch_preset_1d(par, 'v13-small-eps');
par.initialPhaseMode = 'flat';
par.prepareInitialMass = false;
```

---

## 4. `density-compatible` 的旧语义已恢复

v13 中曾把 `density-compatible` 自动映射到 WKB integrating-factor 路径，这会改变旧脚本语义。

合并版中：

```matlab
par.amplitudeVariant = 'density-compatible';
```

明确表示旧版半离散 density-compatible 格式。

只有显式写下面这些名字时才走 v13 IF 路径：

```matlab
'wkb-if-split'
'density-compatible-if'
'dc-if'
'integrating-factor'
```

---

## 5. 中间时刻数据保存

普通 WKB、direct、time-AP 路径都支持中间快照和 checkpoint。

推荐设置：

```matlab
par.storeSnapshots = true;
par.saveIntermediate = true;
par.snapshotTimes = [0, 1, 2, 5, 10];
par.saveInitialSnapshot = true;
par.snapshotEveryTime = Inf;       % 只保存指定时刻
par.snapshotEverySteps = [];

par.saveLatestCheckpoint = true;
par.checkpointEveryTime = 0.5;
par.saveHistoryCheckpoint = true;
```

输出结构：

```text
outdir/
  <tag>_final.mat                 % WKB final
  <tag>_direct_final.mat          % direct final，已避免覆盖 WKB
  latest_checkpoint.mat           % WKB latest checkpoint
  latest_checkpoint_direct.mat    % direct latest checkpoint
  history_checkpoint.mat
  history_checkpoint_direct.mat
  snapshots/
    <tag>_step0000000_t0.mat
    <tag>_direct_step0000000_t0.mat
    ...
```

合并版已修复 v13 中容易漏掉的 `t=0`：如果 `snapshotTimes` 含 0 或 `saveInitialSnapshot=true`，WKB、direct、time-AP 都会保存初始时刻。

---

## 6. 已修复或隔离的旧版/新版问题

1. `run_test3_fine_grid_compare_n.m` 中旧副本把

   ```matlab
   wkb = src.run_wkb_1d(par);
   ```

   注释掉了，但后面仍使用 `wkb`。合并版已恢复运行 WKB。

2. 旧版和 v13 中 direct final 文件名可能与 WKB final 文件名冲突。合并版改成：

   ```text
   WKB:    <tag>_final.mat
   direct: <tag>_direct_final.mat
   ```

3. direct snapshots 现在也使用 `<tag>_direct_step...mat`，避免覆盖 WKB snapshots。

4. `t=0` 中间快照已补齐。

5. v13 的小 epsilon 自动补丁不再静默改写旧版参数；必须通过 `apply_patch_preset_1d` 或显式字段开启。

6. `compute_diagnostics_1d.m` 默认恢复旧版节点峰值 `theta_wkb`，同时保存 `theta_wkb_subgrid`；只有 `par.useSubgridPhasePeak=true` 时才把亚网格峰作为主诊断。

---

## 7. 推荐运行方式

从项目根目录启动：

```matlab
startup_AP_RML
```

快速主程序：

```matlab
run/run_main_1d
```

在 `run/run_main_1d.m` 中切换：

```matlab
experimentPreset = 'legacy';          % 默认：旧版复现
experimentPreset = 'v13-small-eps';   % 尝试 v13 小 epsilon 补丁
experimentPreset = 'v13-projective';  % 尝试 projective time-AP
experimentPreset = 'v13-implicit';    % 尝试 implicit-coupled time-AP
```

旧版测试脚本仍保留：

```matlab
run/run_test1_assumption_diagnostics
run/run_test2_long_time_concentration
run/run_test3_fine_grid_compare_n
run/run_test3_wkb_advantage_refinement
run/run_test4_coarse_theta_AP
run/run_test5_accuracy
```

`run_test3_fine_grid_compare_n` 会额外整理对齐快照到：

```text
data/test3_compare_n/snapshots_compare/
data/test3_compare_n/snapshots_compare_n.mat
```

---

## 8. 备注

- 本合并版尽量保证旧版默认可复现，同时保留新版实验能力。
- time-AP/projective/implicit-coupled 仍是实验版数值路径，适合排查和比较，不建议在未验证前直接作为最终论文基准。
- 小 epsilon 下若需要画图，请优先保存 `W,u`，不要只保存粗网格 `P`。
