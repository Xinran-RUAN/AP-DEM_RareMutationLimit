function [W, u, D, K, grid] = initial_wkb_1d(par)
%INITIAL_WKB_1D WKB 求解器的初值和系数。
%
%  合并版默认复现旧版当前副本的初值：
%      u(theta)=0,  W(x,theta)=1,
%  因此不会在人为初值中预先指定 trait 峰值。v13 中的 peaked 初值、
%  phase-peak gauge、well-prepared mass 都保留为显式选项。
%
%  重要：所有 gauge 或 W 缩放都只改变 WKB 分解方式，不直接求解 n 方程。
%  若 gauge 变换为 u <- u-c, W <- W*exp(c/eps)，则
%      W*exp(u/eps)
%  保持不变。

grid = model.make_grid_1d(par);
x = grid.x;
theta = grid.theta;
D = par.D_fun(theta);
K = par.K_fun(x);

%=========================================================================
% 1. 相位初值
%=========================================================================
phaseMode = local_get_string(par, 'initialPhaseMode', 'flat');
switch lower(phaseMode)
    case {'flat','homogeneous','uniform','legacy'}
        % 旧版当前副本使用的初值：theta 方向完全均匀。
        u = zeros(1, par.Ntheta);
    case {'peaked','old-peaked','single-peak'}
        % 早期 WKB 代码中常用的光滑单峰相位。
        u = -par.alpha0 * (1 - cos(2*pi*(theta - par.theta0)));
    otherwise
        error('Unknown initialPhaseMode "%s".', phaseMode);
end

%=========================================================================
% 2. 振幅初值
%=========================================================================
ampMode = local_get_string(par, 'initialAmplitudeMode', 'flat-rho');
switch lower(ampMode)
    case {'flat-rho','flat','ones','legacy'}
        % 与旧版副本一致：初始总量不随 x 预设振荡。
        rho0 = ones(size(x));
        W = repmat(rho0, 1, par.Ntheta);
    case {'mild-x','cos-x','old-peaked'}
        % 早期注释中保留的轻微 x 扰动。
        W = repmat(1 + 0.1*cos(2*pi*x), 1, par.Ntheta);
    case {'scaled-k','k'}
        W = repmat(max(K(:), 1e-12), 1, par.Ntheta);
    otherwise
        error('Unknown initialAmplitudeMode "%s".', ampMode);
end

%=========================================================================
% 3. 初始 gauge
%=========================================================================
gaugeMode = local_get_string(par, 'initialGaugeMode', 'legacy-max');
switch lower(gaugeMode)
    case {'legacy-max','max','max-zero'}
        % 旧版做法：用节点最大值规范 max(u)=0。
        [W, u] = src.normalize_gauge(W, u, par.eps, 'max');
    case {'phase-peak','subgrid-peak'}
        % v13 小 epsilon 选项：用三点二次插值峰值规范 u*=0。
        % 当峰位落在两个 theta 网格点之间时，这比 nodal max 更稳。
        op0 = src.build_operators_1d(grid);
        peak0 = src.phase_peak_info_1d(u, op0);
        shift0 = peak0.uStar;
        fac0 = exp(max(min(shift0 / par.eps, 300), -300));
        W = W * fac0;
        u = u - shift0;
    case {'none','off'}
        % 不做 gauge。仅用于排查，不建议正式实验使用。
    otherwise
        error('Unknown initialGaugeMode "%s".', gaugeMode);
end

%=========================================================================
% 4. 可选 well-prepared mass 缩放
%=========================================================================
if local_get_logical(par, 'prepareInitialMass', false)
    % 只按 x 缩放 W，使初始 rho 接近指定目标；相位形状和 trait 峰不改变。
    op = src.build_operators_1d(grid);
    rhoMode0 = local_get_string(par, 'rhoReconstruction', 'direct-log');
    [rhoCurrent, ~] = src.reconstruct_rho_1d(W, u, par.eps, op, rhoMode0);
    profile = local_get_string(par, 'initialRhoProfile', 'scaledK');
    scale = local_get_num(par, 'initialRhoScale', 0.5);
    switch lower(profile)
        case {'scaledk','scaled-k','k','carrying'}
            rhoTarget = max(scale * K(:), 1e-12);
        case {'constant','ones','one'}
            rhoTarget = scale * ones(size(K(:)));
        case {'current','none'}
            rhoTarget = rhoCurrent(:);
        otherwise
            error('Unknown initialRhoProfile "%s".', profile);
    end
    fac = rhoTarget(:) ./ max(rhoCurrent(:), realmin);
    W = bsxfun(@times, W, fac);
end
end

function val = local_get_string(s, name, defaultValue)
val = defaultValue;
if isstruct(s) && isfield(s, name) && ~isempty(s.(name))
    val = char(s.(name));
end
end

function val = local_get_num(s, name, defaultValue)
val = defaultValue;
if isstruct(s) && isfield(s, name) && ~isempty(s.(name)) && isnumeric(s.(name)) && isscalar(s.(name))
    val = double(s.(name));
end
end

function tf = local_get_logical(s, name, defaultValue)
tf = defaultValue;
if isstruct(s) && isfield(s, name) && ~isempty(s.(name))
    tf = logical(s.(name));
end
end
