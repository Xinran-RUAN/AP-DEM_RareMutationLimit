% RUN_MAIN_1D 普通一维主程序：只跑一组参数，不做成组数值测试。
%
% 合并版说明：
%   experimentPreset='legacy' 默认复现旧版本：flat 初值、旧 baseline 模型、
%   split 振幅、direct-log 重构、固定 dt、无自动小 epsilon 补丁。
%   若要尝试 v13 新补丁，把 experimentPreset 改为 'v13-small-eps',
%   'v13-projective' 或 'v13-implicit'。

root = fileparts(fileparts(mfilename('fullpath')));
addpath(root);
startup_AP_RML;

%=========================================================================
% 0. 选择运行模式和补丁预设
%=========================================================================
% runMode:
%   'quick'   : 日常调试；
%   'paper'   : 较接近正式数据，较慢；
%   'oldlike' : 接近旧代码粗网格，最快。
runMode = 'quick';

% experimentPreset:
%   'legacy'         : 旧版默认；
%   'v13-small-eps'  : WKB-IF + logistic-exact + laplace-hybrid + H gauge；
%   'v13-projective' : 在 small-eps 基础上启用 projective 时间 AP；
%   'v13-implicit'   : 在 small-eps 基础上启用 implicit-coupled 时间 AP。
experimentPreset = 'legacy';

%=========================================================================
% 1. 选择模型和数值参数
%=========================================================================
par = model.default_params_1d('baseline');
par = model.apply_patch_preset_1d(par, experimentPreset);

% 旧版常用 eps=1e-2；若尝试 v13 小 epsilon，可改成 1e-4 或 1e-6。
par.eps = 1e-2;

switch lower(runMode)
    case 'quick'
        par.Nx = 50;
        par.Ntheta = 32;
        par.T = 20;
        par.dt = 1e-3;
        par.tol = 1e-8;
        par.historyEveryTime = 1.0;
    case 'paper'
        par.Nx = 200;
        par.Ntheta = 128;
        par.T = 30;
        par.dt = 1e-3;
        par.tol = 1e-9;
        par.historyEveryTime = 0.5;
    case 'oldlike'
        par.Nx = 10;
        par.Ntheta = 50;
        par.T = 5;
        par.dt = 2e-3;
        par.tol = 1e-8;
        par.historyEveryTime = 1.0;
    otherwise
        error('Unknown runMode "%s".', runMode);
end

% 若 experimentPreset 是 v13-projective/v13-implicit，建议启用自适应 dt，
% 并把 dtMax 设为用户给定的宏步上限。
if any(strcmpi(experimentPreset, {'v13-projective','projective','v13-implicit','implicit'}))
    par.dtMax = par.dt;
end

%=========================================================================
% 2. 中间时刻数据存储
%=========================================================================
% storeSnapshots/saveIntermediate 控制完整快照；latest checkpoint 会覆盖保存
% 最近状态，history checkpoint 保存轻量历史。snapshotEveryTime=historyEveryTime
% 表示每个诊断时刻也保存完整 W,u,n,rho,H，便于中途停止后画图。
par.storeSnapshots = true;
par.saveIntermediate = true;
par.snapshotTimes = [];
par.snapshotEveryTime = par.historyEveryTime;
par.snapshotEverySteps = [];
par.saveLatestCheckpoint = true;
par.checkpointEveryTime = par.historyEveryTime;
par.checkpointEverySteps = [];
par.saveHistoryCheckpoint = true;
par.printIntermediateSaveMessage = false;

par.outdir = utils.output_dir(sprintf('main_%s_%s', runMode, experimentPreset));
par.verbose = true;
par.progressEveryPercent = 5;
par.progressEverySeconds = 10;

% 在线图像监测。paper 档默认关闭，避免拖慢长算例。
switch lower(runMode)
    case {'quick','oldlike'}
        par.livePlot = true;
        par.livePlotEveryTime = 0.5;
    otherwise
        par.livePlot = false;
        par.livePlotEveryTime = 2.0;
end
par.livePlotEverySteps = [];
par.livePlotSave = false;
par.livePlotPause = 0.0;

% 是否同时跑原始密度方程 direct solver。
runDirect = false;

fprintf('\n========== RUN_MAIN_1D: 单组参数主程序 ==========' );
fprintf('\nrunMode=%s, preset=%s, profile=%s, eps=%.4g, Nx=%d, Ntheta=%d, T=%.4g, dt=%.4g\n', ...
    runMode, experimentPreset, par.profile, par.eps, par.Nx, par.Ntheta, par.T, par.dt);
fprintf('amplitudeVariant=%s, rhoReconstruction=%s, reaction=%s, timeIntegrator=%s\n', ...
    par.amplitudeVariant, par.rhoReconstruction, par.reactionDiscretization, par.timeIntegrator);
fprintf('预计最多步数: %d；WKB 未知量规模约: %d x %d = %d\n', ...
    ceil(par.T/par.dt), par.Nx+1, par.Ntheta, (par.Nx+1)*par.Ntheta);
fprintf('outdir=%s\n', par.outdir);
fprintf('livePlot=%d, livePlotEveryTime=%.4g\n', par.livePlot, par.livePlotEveryTime);

%=========================================================================
% 3. 运行 WKB 求解器
%=========================================================================
wkb = src.run_wkb_1d(par);

%=========================================================================
% 4. 可选：运行原始密度方程直接求解器
%=========================================================================
if runDirect
    direct = src.run_direct_1d(par); %#ok<SNASGU>
else
    direct = []; %#ok<NASGU>
end

%=========================================================================
% 5. 保存本次单组运行摘要
%=========================================================================
summary = struct();
summary.runMode = runMode;
summary.experimentPreset = experimentPreset;
summary.profile = par.profile;
summary.modelVariant = par.modelVariant;
summary.eps = par.eps;
summary.Nx = par.Nx;
summary.Ntheta = par.Ntheta;
summary.T = par.T;
summary.dt = par.dt;
summary.timeIntegrator = par.timeIntegrator;
summary.amplitudeVariant = par.amplitudeVariant;
summary.reactionDiscretization = par.reactionDiscretization;
summary.residualMode = par.residualMode;
summary.rhoReconstruction = par.rhoReconstruction;
summary.hamiltonianGauge = par.hamiltonianGauge;
summary.initialPhaseMode = par.initialPhaseMode;
summary.prepareInitialMass = par.prepareInitialMass;
summary.storeSnapshots = par.storeSnapshots;
summary.snapshotEveryTime = par.snapshotEveryTime;
summary.saveLatestCheckpoint = par.saveLatestCheckpoint;
summary.checkpointEveryTime = par.checkpointEveryTime;
summary.theta_m = par.theta_m;
summary.theta_wkb = wkb.diagnostics.theta_wkb;
summary.err_wkb_to_m = wkb.diagnostics.err_wkb_to_m;
summary.sigma_theta = wkb.diagnostics.sigma_theta;
summary.rho_max = wkb.diagnostics.rho_max;
summary.gammaR = wkb.diagnostics.gammaR;
summary.residual = wkb.residual;
summary.steps = wkb.step;

utils.ensure_dir(par.outdir);
save(fullfile(par.outdir, 'summary_main_1d.mat'), 'summary', 'wkb', 'direct');

disp('RUN_MAIN_1D 摘要:');
disp(summary);
fprintf('RUN_MAIN_1D 完成。结果目录: %s\n', par.outdir);
