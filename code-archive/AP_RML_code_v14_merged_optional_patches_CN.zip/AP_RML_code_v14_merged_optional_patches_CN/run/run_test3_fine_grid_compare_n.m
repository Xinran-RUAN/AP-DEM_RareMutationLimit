% RUN_TEST3_FINE_GRID_COMPARE_N
% 数值实验 3：在较细 theta 网格上比较 direct n 与 WKB 重构 n。
%
% 合并版修正：
%   1. 恢复旧版“保存多个中间时刻”的设计；
%   2. 修正旧副本中 wkb = src.run_wkb_1d(par) 被注释导致后续变量不存在的问题；
%   3. WKB 和 direct 的 final/snapshot 文件名分开，避免 direct 覆盖 WKB；
%   4. 后处理 P(theta) 时强调正确顺序：W,u -> 重构 n -> 对 x 积分。

root = fileparts(fileparts(mfilename('fullpath')));
addpath(root);
startup_AP_RML;

%% ========== 参数设置 ==========
quickMode = false;   % 保持旧版默认；调试时可改 true

par = model.default_params_1d('baseline');
par = model.apply_patch_preset_1d(par, 'legacy');
par.eps = 1e-4;

if quickMode
    par.Nx = 80;
    par.Ntheta = 128;
    par.T = 8;
    par.dt = 5e-3;
    par.tol = 1e-8;
    par.historyEveryTime = 1.0;
    snapshotTimes = 0:1:par.T;
    par.outdir = utils.output_dir('test3_compare_n_quick');
else
    par.Nx = 100;
    par.Ntheta = 60;
    par.T = 5;
    par.dt = 1e-4;
    par.tol = 1e-9;
    par.historyEveryTime = 0.5;
    snapshotTimes = [0, 1:10];
    par.outdir = utils.output_dir('test3_compare_n');
end

% 为了严格比较同一时刻，建议本测试不要按 residual 提前停。
par.stopByResidual = false;
par.verbose = true;
par.progressEveryPercent = 5;
par.progressEverySeconds = 20;

% 中间数据保存：snapshotTimes 中含 0，因此打开 saveInitialSnapshot。
par.storeSnapshots = true;
par.saveIntermediate = true;
par.snapshotTimes = unique(snapshotTimes(:).');
par.saveInitialSnapshot = any(abs(par.snapshotTimes) < 1e-14);
par.snapshotEveryTime = Inf;       % 只保存指定时刻，避免正式实验数据过大
par.snapshotEverySteps = [];
par.saveLatestCheckpoint = true;
par.checkpointEveryTime = par.historyEveryTime;
par.checkpointEverySteps = [];
par.saveHistoryCheckpoint = true;
par.printIntermediateSaveMessage = true;

utils.ensure_dir(par.outdir);

fprintf('\n========== TEST 3: fine-grid comparison of n ==========' );
fprintf('\nquickMode=%d, eps=%.4g, Nx=%d, Ntheta=%d, T=%.4g, dt=%.4g\n', ...
    quickMode, par.eps, par.Nx, par.Ntheta, par.T, par.dt);
fprintf('预计最多步数: %d；未知量规模约: %d\n', ceil(par.T/par.dt), (par.Nx+1)*par.Ntheta);
fprintf('计划保存时刻: '); fprintf('%.4g ', par.snapshotTimes); fprintf('\n');
fprintf('[TEST 3] 先运行 WKB，然后运行 direct solver。\n');

%% ========== 运行 WKB 与 direct solver ==========
wkb = src.run_wkb_1d(par);
direct = src.run_direct_1d(par);

%% ========== 终止时刻误差 ==========
wx = utils.trapz_weights(wkb.op.nx, wkb.op.dx);
errL1 = wkb.op.dtheta * sum(wx.' * abs(wkb.n - direct.n));
refL1 = wkb.op.dtheta * sum(wx.' * abs(direct.n));
errL2 = sqrt(wkb.op.dtheta * sum(wx.' * (wkb.n - direct.n).^2));
refL2 = sqrt(wkb.op.dtheta * sum(wx.' * direct.n.^2));

summary = struct();
summary.quickMode = quickMode;
summary.eps = par.eps;
summary.Nx = par.Nx;
summary.Ntheta = par.Ntheta;
summary.T = par.T;
summary.dt = par.dt;
summary.snapshotTimes = par.snapshotTimes;
summary.relL1 = errL1 / max(refL1, realmin);
summary.relL2 = errL2 / max(refL2, realmin);
summary.theta_wkb = get_optional_field(wkb.diagnostics, 'theta_wkb', NaN);
summary.theta_direct = get_optional_field(direct.diagnostics, 'theta_direct', NaN);
summary.wkb_steps = wkb.step;
summary.direct_steps = direct.step;
disp(summary);

%% ========== 整理并保存多个时刻的数据 ==========
combinedDir = fullfile(par.outdir, 'snapshots_compare');
utils.ensure_dir(combinedDir);

tag = utils.build_tag(par);
wkbSnaps = load_solver_snapshots(par.outdir, tag, 'wkb', wkb);
directSnaps = load_solver_snapshots(par.outdir, tag, 'direct', direct);

if isempty(wkbSnaps)
    wkbSnaps = final_snapshot_from_solution(wkb, 'wkb');
end
if isempty(directSnaps)
    directSnaps = final_snapshot_from_solution(direct, 'direct');
end

tW = [wkbSnaps.t];
tD = [directSnaps.t];
numSnaps = numel(wkbSnaps);
snapshots = struct([]);

for m = 1:numSnaps
    tw = tW(m);
    [~, id] = min(abs(tD - tw));

    nd = directSnaps(id).n;
    W = get_optional_field(wkbSnaps(m), 'W', []);
    u = get_optional_field(wkbSnaps(m), 'u', []);
    nw = get_optional_field(wkbSnaps(m), 'n', []);
    if isempty(nw)
        if isempty(W) || isempty(u)
            error('WKB snapshot 中既没有 n，也没有完整 W,u，无法重构 n_wkb。');
        end
        nw = reconstruct_wkb_density(W, u, par.eps);
    end

    [relL1_m, relL2_m] = relative_errors(nw, nd, wkb.op);
    theta = wkb.op.theta(:).';
    theta_direct_m = peak_trait(theta, nd, wx, wkb.op.dtheta);
    theta_wkb_m = peak_trait(theta, nw, wx, wkb.op.dtheta);

    one = struct();
    one.t = tw;
    one.t_direct = tD(id);
    one.eps = par.eps;
    one.x = wkb.op.x;
    one.theta = theta;
    one.n_direct = nd;
    one.W_wkb = W;
    one.u_wkb = u;
    one.n_wkb = nw;
    one.relL1 = relL1_m;
    one.relL2 = relL2_m;
    one.theta_direct = theta_direct_m;
    one.theta_wkb = theta_wkb_m;

    if isempty(snapshots)
        snapshots = one;
    else
        snapshots(m) = one; %#ok<SAGROW>
    end

    snapFile = fullfile(combinedDir, sprintf('test3_snapshot_%03d_t%.6g.mat', m, tw));
    save(snapFile, 'one', '-v7.3');
    fprintf('[snapshot %02d/%02d] t=%.6g, direct t=%.6g, relL1=%.3e, relL2=%.3e\n', ...
        m, numSnaps, tw, tD(id), relL1_m, relL2_m);
end

%% ========== 保存总结果 ==========
save(fullfile(par.outdir, 'summary_compare_n.mat'), 'summary', 'par', 'wkb', 'direct', '-v7.3');
save(fullfile(par.outdir, 'snapshots_compare_n.mat'), 'snapshots', 'summary', 'par', '-v7.3');

fprintf('\nTEST 3 完成。\n');
fprintf('summary 保存到: %s\n', fullfile(par.outdir, 'summary_compare_n.mat'));
fprintf('中间对齐快照保存到: %s\n', combinedDir);

%% ========================================================================
%% 局部函数
%% ========================================================================
function snaps = load_solver_snapshots(outdir, tag, solverName, fallbackSolution)
    snapshotDir = fullfile(outdir, 'snapshots');
    snaps = struct([]);
    if ~exist(snapshotDir, 'dir')
        return;
    end
    switch lower(solverName)
        case 'wkb'
            pat = sprintf('%s_step*.mat', tag);
        case 'direct'
            pat = sprintf('%s_direct_step*.mat', tag);
        otherwise
            error('Unknown solverName "%s".', solverName);
    end
    files = dir(fullfile(snapshotDir, pat));
    if isempty(files)
        return;
    end
    [~, idx] = sort({files.name});
    files = files(idx);
    for q = 1:numel(files)
        S = load(fullfile(snapshotDir, files(q).name));
        one = struct();
        one.t = get_optional_field(S, 't', NaN);
        one.step = get_optional_field(S, 'step', NaN);
        switch lower(solverName)
            case 'wkb'
                one.W = get_optional_field(S, 'W', fallbackSolution.W);
                one.u = get_optional_field(S, 'u', fallbackSolution.u);
                one.n = get_optional_field(S, 'n', []);
                one.rho = get_optional_field(S, 'rho', []);
            case 'direct'
                one.n = get_optional_field(S, 'n', fallbackSolution.n);
                one.rho = get_optional_field(S, 'rho', []);
        end
        if isempty(snaps)
            snaps = one;
        else
            snaps(end+1) = one; %#ok<AGROW>
        end
    end
end

function snap = final_snapshot_from_solution(sol, type)
    snap = struct();
    snap.t = sol.t;
    snap.step = sol.step;
    switch lower(type)
        case 'wkb'
            snap.W = sol.W;
            snap.u = sol.u;
            snap.n = sol.n;
            snap.rho = sol.rho;
        case 'direct'
            snap.n = sol.n;
            snap.rho = sol.rho;
    end
end

function n = reconstruct_wkb_density(W, u, epsVal)
    if isvector(u)
        U = repmat(u(:).', size(W,1), 1);
    else
        U = u;
    end
    arg = U / epsVal;
    arg = min(max(arg, -745), 700);
    n = W .* exp(arg);
    n(~isfinite(n)) = 0;
end

function [relL1, relL2] = relative_errors(a, b, op)
    wx = utils.trapz_weights(op.nx, op.dx);
    relL1 = op.dtheta * sum(wx.' * abs(a-b)) / max(op.dtheta * sum(wx.' * abs(b)), realmin);
    relL2 = sqrt(op.dtheta * sum(wx.' * (a-b).^2)) / max(sqrt(op.dtheta * sum(wx.' * b.^2)), realmin);
end

function th = peak_trait(theta, n, wx, dtheta)
    P = wx.' * n;
    [~, id] = max(P);
    th = theta(id);
end

function val = get_optional_field(S, name, defaultVal)
    if isstruct(S) && isfield(S, name) && ~isempty(S.(name))
        val = S.(name);
    else
        val = defaultVal;
    end
end
