% RUN_TEST2_LONG_TIME_CONCENTRATION
% 数值实验 2：长时间演化后，检查解是否在 theta 方向形成集中。
%
% 默认 quickMode=true 先快速看是否有聚集趋势；正式长时间图再改为 false。
root = fileparts(fileparts(mfilename('fullpath')));
addpath(root);
startup_AP_RML;

quickMode = false;
par = model.default_params_1d('baseline');
par.eps = 1e-4;  
if quickMode
    par.Nx = 40;
    par.Ntheta = 32;
    par.T = 20;
    par.dt = 1e-5;
    par.tol = 1e-8;
    par.snapshotTimes = [1, 5, 10, 20];
    par.historyEveryTime = 1.0;
    par.outdir = utils.output_dir('test2_long_time_quick');
else
    par.Nx = 200; 
    par.Ntheta = 128;
    par.T = 100;
    par.dt = 1e-4;
    par.tol = 1e-10;

    % 加上 0，方便后处理选取初值
    par.snapshotTimes = [0, linspace(0.1, 10, 100), 11:1:30];
    par.historyEveryTime = 0.1; 

    % 开启初值快照保存
    par.saveInitialSnapshot = true;

    par.outdir = utils.output_dir('test2_long_time_eps00001');
end
par.progressEveryPercent = 5;


fprintf('\n========== TEST 2: long-time concentration ==========' );
fprintf('\nquickMode=%d, eps=%.4g, Nx=%d, Ntheta=%d, T=%.4g, dt=%.4g\n', ...
    quickMode, par.eps, par.Nx, par.Ntheta, par.T, par.dt);
result = src.run_wkb_1d(par);
disp(result.diagnostics);
fprintf('TEST 2 完成。输出目录: %s\n', par.outdir);
