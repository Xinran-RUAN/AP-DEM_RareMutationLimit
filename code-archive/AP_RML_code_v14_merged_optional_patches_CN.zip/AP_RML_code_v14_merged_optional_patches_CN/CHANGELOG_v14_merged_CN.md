# v14 合并说明与检查记录

## 对照结论

- 旧版 `liveplot_副本` 中对 WKB trait marginal 的画图思路是正确的：分别插值 `W` 和 `u`，再重构 `n=W exp(u/eps)`，最后对 x 积分得到 `P(theta)`。
- v13 主要新增了小 epsilon 稳健化、time-AP/projective/implicit-coupled 实验路径、checkpoint/中间保存等补丁。
- 合并版以 v13 代码结构为底座，但默认参数恢复旧版行为；v13 补丁统一通过 `model.apply_patch_preset_1d` 或显式字段启用。

## 主要改动

1. 新增 `+model/apply_patch_preset_1d.m`：集中管理 `legacy`、`v13-small-eps`、`v13-projective`、`v13-implicit`。
2. 重写 `+model/default_params_1d.m`：默认旧版 flat 初值、旧版 `K0-K1*cos(2*pi*x)`、旧版 split/direct-log/legacy residual。
3. 重写 `+model/initial_wkb_1d.m`：支持 flat 与 peaked 初值，默认 flat；v13 well-prepared mass 改为可选。
4. 修改 `+src/run_wkb_1d.m`：
   - 小 epsilon 自动补丁默认关闭；
   - `density-compatible` 恢复旧语义；
   - 支持 `t=0` 初始快照；
   - step retry 默认只在显式开启时使用。
5. 修改 `+src/run_wkb_timeap_1d.m`：time-AP 路径也支持 `t=0` 初始快照，且不静默改写 legacy 参数。
6. 修改 `+src/run_direct_1d.m`：direct final/snapshot/checkpoint 与 WKB 分开命名，防止覆盖。
7. 新增 `+src/reconstruct_trait_marginal_from_wkb_1d.m`：统一实现正确的 WKB `P(theta)` 后处理。
8. 修改 `+src/compute_diagnostics_1d.m`：默认旧版节点峰；同时记录亚网格峰。
9. 修复 `run/run_test3_fine_grid_compare_n.m` 中 WKB 变量未生成的旧 bug，并补齐中间快照整理。
10. 保留旧版 post 绘图脚本，并修正 `plot_test3_trait_marginal.m` 中对细化曲线的处理，避免直接插值 WKB `P`。

## 检查到的旧版/新版风险

- direct 与 WKB 输出同名覆盖：已修复。
- v13 对小 epsilon 参数的隐式自动切换可能导致旧实验不再可复现：已改为显式 preset。
- `snapshotTimes` 包含 0 时 v13 不保存初值：已修复。
- `density-compatible` 语义变化：已恢复旧语义，IF 版本必须显式选择。
- 旧版部分绘图脚本含本机绝对路径：已改为项目相对路径。

## 运行验证说明

当前打包环境没有 MATLAB/Octave 可执行程序，因此未能进行完整数值运行；已完成文件级对比、关键路径静态检查和命名/保存逻辑检查。建议在 MATLAB 中先运行：

```matlab
startup_AP_RML
run/run_smoke_test_1d
run/run_main_1d
```

然后再运行较重的 test2/test3/test3b。
