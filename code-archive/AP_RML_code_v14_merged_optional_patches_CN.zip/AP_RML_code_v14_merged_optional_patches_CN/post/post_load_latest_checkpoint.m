% POST_LOAD_LATEST_CHECKPOINT
% 读取最近一次 WKB/time-AP 计算保存的 latest_checkpoint.mat。
%
% 用法：
%   1. 先运行 startup_AP_RML
%   2. 若刚运行过 run_main_1d，则可以直接运行本脚本；
%   3. 若需要手动指定目录，请修改下面的 outdir。
%
% 说明：
%   latest_checkpoint.mat 是覆盖保存的最近状态。即使主程序没有跑到 T，
%   只要已经经过一次 checkpoint 保存，就可以用它检查中间结果。

root = fileparts(fileparts(mfilename('fullpath')));
addpath(root);
startup_AP_RML;

% 默认读取 run_main_1d 的 legacy quick 输出目录。
outdir = utils.output_dir('main_quick_legacy');
checkpointFile = fullfile(outdir, 'latest_checkpoint.mat');

if exist(checkpointFile, 'file') ~= 2
    error('没有找到 latest_checkpoint.mat：%s\n请确认 par.outdir 或手动修改本脚本中的 outdir。', checkpointFile);
end

S = load(checkpointFile);

fprintf('\n========== latest checkpoint ==========' );
fprintf('\n文件: %s\n', checkpointFile);
fprintf('t = %.8g, step = %d, residual = %.6e\n', S.t, S.step, S.residual);

if isfield(S, 'diagnostics') && isstruct(S.diagnostics)
    dg = S.diagnostics;
    if isfield(dg, 'theta_wkb')
        fprintf('thetaWKB = %.8g\n', dg.theta_wkb);
    end
    if isfield(dg, 'err_wkb_to_m')
        fprintf('err_wkb_to_m = %.6e\n', dg.err_wkb_to_m);
    end
    if isfield(dg, 'rho_max')
        fprintf('rho_max = %.6e\n', dg.rho_max);
    end
    if isfield(dg, 'gammaR')
        fprintf('gammaR = %.6e\n', dg.gammaR);
    end
end

% 简单画 history 中的 residual 和 thetaWKB。
if isfield(S, 'history') && isstruct(S.history) && isfield(S.history, 't')
    h = S.history;
    figure;
    tiledlayout(2,1);

    nexttile;
    if isfield(h, 'residual')
        semilogy(h.t, h.residual, '-o');
        xlabel('t'); ylabel('residual'); grid on;
        title('Residual history');
    end

    nexttile;
    if isfield(h, 'theta_wkb')
        plot(h.t, h.theta_wkb, '-o'); hold on;
        if isfield(S, 'par') && isfield(S.par, 'theta_m')
            yline(S.par.theta_m, '--');
            legend('thetaWKB', 'theta_m', 'Location', 'best');
        end
        xlabel('t'); ylabel('\theta_{WKB}'); grid on;
        title('Selected trait history');
    end
end
