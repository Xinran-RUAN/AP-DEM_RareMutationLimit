% POST_TEST3_COMPARE_N_RECONSTRUCTION
% 读取 test3_compare_n 的终止结果，并用正确的 W,u 插值顺序画 P(theta)。
%
% 关键点：WKB 的 trait marginal 不应先在粗网格上得到 P_k 再插值；
% 应先分别插值 W 和 u，然后在目标 theta 网格上重构 n，再对 x 积分。

root = fileparts(fileparts(mfilename('fullpath')));
addpath(root);
startup_AP_RML;

outdir = utils.output_dir('test3_compare_n');
S = load(fullfile(outdir,'summary_compare_n.mat'));
disp(S.summary);

wkb = S.wkb;
direct = S.direct;

% WKB：正确顺序 W,u -> 插值 -> n -> P。
thetaFine = linspace(0,1,513).';
thetaFine(end) = [];
[P_wkb, ~, ~, ~, thetaFine] = src.reconstruct_trait_marginal_from_wkb_1d( ...
    wkb.W, wkb.u, wkb.op, wkb.par.eps, thetaFine, 'spline');

% Direct：direct.n 本身就是密度，若要画到细 theta 网格，只插值密度 n，
% 再对 x 积分；不要把粗 P 直接插值。
nDirFine = local_interp_density_theta(direct.n, direct.op.theta(:), thetaFine, 'spline');
wx = utils.trapz_weights(direct.op.nx, direct.op.dx);
P_dir = wx.' * nDirFine;
P_dir = real(P_dir(:));

figure;
plot(thetaFine, P_wkb, 'LineWidth', 1.5); hold on;
plot(thetaFine, P_dir, '--', 'LineWidth', 1.5);
xlabel('\theta'); ylabel('P(\theta)'); grid on;
legend('WKB: interpolate W,u then reconstruct', 'direct: interpolate n then integrate', 'Location','best');
title('Trait marginal comparison with correct reconstruction order');

function nFine = local_interp_density_theta(n, theta, thetaFine, method)
if nargin < 4 || isempty(method), method = 'spline'; end
nFine = zeros(size(n,1), numel(thetaFine));
for j = 1:size(n,1)
    nFine(j,:) = local_periodic_interp(theta, n(j,:).', thetaFine, 1.0, method).';
end
nFine(~isfinite(nFine)) = 0;
nFine = max(real(nFine), 0);
end

function fq = local_periodic_interp(theta, f, thetaq, period, method)
theta = theta(:); f = f(:); thetaq = mod(thetaq(:), period);
[theta, idx] = sort(mod(theta, period)); f = f(idx);
thetaExt = [theta; theta(1)+period];
fExt = [f; f(1)];
try
    fq = interp1(thetaExt, fExt, thetaq, method);
catch
    fq = interp1(thetaExt, fExt, thetaq, 'linear');
end
end
