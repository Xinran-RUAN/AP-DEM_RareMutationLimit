%% plot_test3_heatmap_n.m
% Test 3: x-theta-n 热图
%
% 左图：direct solver 得到的密度 n_dir
% 右图：WKB 重构密度 n_WKB = W * exp(u/eps)
%
% 本脚本固定一个时刻 targetTime，
% 自动寻找最接近该时刻的 WKB/direct snapshot 文件。
%
% 说明：
%   1. 不重新求解，只做后处理画图；
%   2. WKB 图中 n_WKB 由 W 和 u 重构；
%   3. theta 方向可用 WENO5 加密后再画图；
%   4. direct 图也可以只为画图做 WENO 后处理，使热图更光滑。

clear; clc; close all;

%% ========== 用户需要检查的部分 ==========

% 固定命名。按实际参数修改这一行即可。
caseName = 'baseline_eps0.001_Nx100_K128_dt0.0001_split_direct-log';

% 固定要画的时刻。这里只需要改这个。
targetTime = 5;

% 如果 mat 文件里面没有 eps/epsilon/par.eps 变量，就用这里的 epsVal
epsVal = 1e-3;

% theta 是 1-periodic
thetaPeriod = 1.0;

% theta 方向画图加密倍数。
% 1 表示不加密；4 或 8 会更光滑。
thetaRefine = 4;

% direct 图是否也做 WENO 后处理，仅用于画图。
% 如果想看完全原始离散热图，改成 false。
smoothDirectForPlot = true;

% 是否画 log10(n)。如果 n 很尖，建议改成 true。
plotLog10 = false;

% 是否保存图片
saveFig = true;

%% ========== 自动定位项目根目录 ==========

thisFile = mfilename('fullpath');

if isempty(thisFile)
    thisDir = pwd;
else
    thisDir = fileparts(thisFile);
end

rootCandidates = { ...
    pwd, ...
    thisDir, ...
    fileparts(thisDir), ...
    fileparts(fileparts(thisDir)) ...
};

root = '';

for ii = 1:numel(rootCandidates)
    cand = rootCandidates{ii};

    if isempty(cand)
        continue;
    end

    if isfile(fullfile(cand, 'startup_AP_RML.m')) && ...
            isfolder(fullfile(cand, 'data'))
        root = cand;
        break;
    end
end

if isempty(root)
    error('无法自动定位项目根目录。请确认 startup_AP_RML.m 和 data 文件夹在同一级目录。');
end

dataDir = fullfile(root, 'data', 'test3_compare_n');

%% ========== 自动寻找 WKB 和 direct 文件 ==========

[fileWKB, tWKB] = find_snapshot_file(dataDir, caseName, targetTime, false);
[fileDIR, tDIR] = find_snapshot_file(dataDir, caseName, targetTime, true);

fprintf('\n========== Test 3 heatmap ==========\n');
fprintf('项目根目录: %s\n', root);
fprintf('数据目录:   %s\n', dataDir);
fprintf('目标时刻:   %.8g\n', targetTime);
fprintf('WKB 时刻:   %.8g\n', tWKB);
fprintf('direct 时刻:%.8g\n', tDIR);
fprintf('WKB 文件:   %s\n', fileWKB);
fprintf('direct 文件:%s\n', fileDIR);

assert(isfile(fileWKB), '找不到 WKB 文件：%s', fileWKB);
assert(isfile(fileDIR), '找不到 direct 文件：%s', fileDIR);

%% ========== 读入数据 ==========

Swkb = load(fileWKB);
Sdir = load(fileDIR);

%% ========== 从 direct 文件中读取 x, theta, n_dir ==========

xDir = get_first_var(Sdir, ...
    {'x','xx','xgrid','x_grid','xGrid','X','x_nodes','gridx'});

thetaDir = get_first_var(Sdir, ...
    {'theta','th','theta_grid','thetaGrid','Theta','th_grid','gridtheta'});

nDirRaw = get_first_var(Sdir, ...
    {'n_direct','ndir','nDirect','n_direct','n','ne','N','density','n_final','n_end'});

xDir = grid_vector(xDir, 'x');
thetaDir = grid_vector(thetaDir, 'theta');

NxDir = numel(xDir);
NthDir = numel(thetaDir);

nDir = to_xt_matrix(nDirRaw, NxDir, NthDir, 'n_dir');

%% ========== 从 WKB 文件中读取 x, theta, W, u, eps ==========

xW = get_first_var(Swkb, ...
    {'x','xx','xgrid','x_grid','xGrid','X','x_nodes','gridx'}, ...
    true, xDir);

thetaW = get_first_var(Swkb, ...
    {'theta','th','theta_grid','thetaGrid','Theta','th_grid','gridtheta'}, ...
    true, thetaDir);

Wraw = get_first_var(Swkb, ...
    {'W_wkb','W','w','W_final','w_final','W_end','w_end','amp','amplitude','A'});

uraw = get_first_var(Swkb, ...
    {'u_wkb','u','U','u_final','U_final','u_end','phase','phi'});

epsRead = get_first_var(Swkb, ...
    {'eps','epsilon','vareps','epsVal'}, ...
    true, []);

if isempty(epsRead)
    epsRead = get_first_var(Swkb, {'par'}, true, []);
    if isstruct(epsRead) && isfield(epsRead, 'eps')
        epsVal = epsRead.eps;
    end
else
    epsVal = double(epsRead);
    epsVal = epsVal(end);
end

xW = grid_vector(xW, 'x');
thetaW = grid_vector(thetaW, 'theta');

NxW = numel(xW);
NthW = numel(thetaW);

W = to_xt_matrix(Wraw, NxW, NthW, 'W');
u = to_u_array(uraw, NxW, NthW, 'u');

%% ========== 先把 W, u 放到 direct 的 x 网格上 ==========

W_x = interp_x_if_needed(W, xW, xDir);

if isvector(u)
    u_x = u(:).';
else
    u_x = interp_x_if_needed(u, xW, xDir);
end

%% ========== 在 direct 原始 theta 网格上计算误差 ==========

% 为了计算误差，先把 WKB 的 W,u 放到 direct 的原始 theta 网格上。
W_on_dir_theta = interp_theta_matrix_weno(W_x, thetaW, thetaDir, thetaPeriod);

if isvector(u_x)
    u_on_dir_theta = weno5_periodic_interp(thetaW, u_x(:), thetaDir, thetaPeriod).';
else
    u_on_dir_theta = interp_theta_matrix_weno(u_x, thetaW, thetaDir, thetaPeriod);
end

if isvector(u_on_dir_theta)
    U_on_dir_theta = repmat(u_on_dir_theta(:).', NxDir, 1);
else
    U_on_dir_theta = u_on_dir_theta;
end

argRaw = U_on_dir_theta / epsVal;
argRaw = min(max(argRaw, -745), 700);

nWKB_raw = W_on_dir_theta .* exp(argRaw);

% 只截断极小负值
tolNeg = 1e-13 * max(1, max(abs(nWKB_raw(:))));
nWKB_raw(nWKB_raw < 0 & abs(nWKB_raw) < tolNeg) = 0;

e1 = sum(abs(nWKB_raw(:) - nDir(:))) / max(sum(abs(nDir(:))), realmin);
e2 = norm(nWKB_raw(:) - nDir(:)) / max(norm(nDir(:)), realmin);

fprintf('\nTest 3 heatmap data:\n');
fprintf('  eps = %.6g\n', epsVal);
fprintf('  direct grid: Nx = %d, Ntheta = %d\n', NxDir, NthDir);
fprintf('  WKB grid:    Nx = %d, Ntheta = %d\n', NxW, NthW);
fprintf('  relative e1 = %.6e\n', e1);
fprintf('  relative e2 = %.6e\n\n', e2);

%% ========== theta 方向 WENO 后处理，用于画图 ==========

if thetaRefine > 1
    NthetaPlot = thetaRefine * NthDir;
    thetaPlot = linspace(thetaDir(1), thetaDir(1) + thetaPeriod, NthetaPlot + 1).';
    thetaPlot(end) = [];
else
    thetaPlot = thetaDir;
end

% direct 热图
if smoothDirectForPlot || thetaRefine > 1
    nDirPlot = interp_theta_matrix_weno(nDir, thetaDir, thetaPlot, thetaPeriod);
else
    thetaPlot = thetaDir;
    nDirPlot = nDir;
end

% WKB 热图。这里对 W 和 u 分别做 WENO，然后重构 n。
WPlot = interp_theta_matrix_weno(W_x, thetaW, thetaPlot, thetaPeriod);

if isvector(u_x)
    uPlot = weno5_periodic_interp(thetaW, u_x(:), thetaPlot, thetaPeriod).';
    UPlot = repmat(uPlot(:).', NxDir, 1);
else
    UPlot = interp_theta_matrix_weno(u_x, thetaW, thetaPlot, thetaPeriod);
end

arg = UPlot / epsVal;
arg = min(max(arg, -745), 700);

nWKBPlot = WPlot .* exp(arg);

% 画图用，截断 WENO 后处理产生的负值
nDirPlot(nDirPlot < 0) = 0;
nWKBPlot(nWKBPlot < 0) = 0;

%% ========== 画热图，美化版 ==========

if plotLog10
    tiny = 1e-300;
    Zdir = log10(max(nDirPlot, tiny));
    Zwkb = log10(max(nWKBPlot, tiny));
    cbarText = '$\log_{10} n$';
else
    Zdir = nDirPlot;
    Zwkb = nWKBPlot;
    cbarText = '$n$';
end

% 统一色标。密度非负时从 0 开始更清楚。
if plotLog10
    clim_common = [min([Zdir(:); Zwkb(:)]), max([Zdir(:); Zwkb(:)])];
else
    clim_common = [0, max([Zdir(:); Zwkb(:)])];
end

clim_common= [0, 12];

% 论文图字体参数
fontName = 'Times New Roman';
axisFS   = 13;
labelFS  = 15;
titleFS  = 15;
mainFS   = 16;
cbFS     = 13;

fig = figure('Color', 'w', ...
    'Units', 'centimeters', ...
    'Position', [3, 3, 32, 12]);

tl = tiledlayout(1, 2, ...
    'Padding', 'compact', ...
    'TileSpacing', 'compact');

% ------------------ 左图：direct ------------------
ax1 = nexttile;
imagesc(ax1, xDir, thetaPlot, Zdir.');
axis(ax1, 'xy');
axis(ax1, 'tight');
pbaspect(ax1, [1.2 1 1]);

xlabel(ax1, '$x$', ...
    'Interpreter', 'latex', ...
    'FontSize', labelFS);

ylabel(ax1, '$\theta$', ...
    'Interpreter', 'latex', ...
    'FontSize', labelFS);

title(ax1, 'Direct density $n^{\rm dir}$', ...
    'Interpreter', 'latex', ...
    'FontSize', titleFS, ...
    'FontWeight', 'normal');

set(ax1, ...
    'FontName', fontName, ...
    'FontSize', axisFS, ...
    'LineWidth', 1.0, ...
    'TickLabelInterpreter', 'latex', ...
    'Box', 'on', ...
    'Layer', 'top', ...
    'XTick', 0:0.2:1, ...
    'YTick', 0:0.2:1);

xlim(ax1, [min(xDir), max(xDir)]);
ylim(ax1, [thetaPlot(1), thetaPlot(1) + thetaPeriod]);
caxis(ax1, clim_common);

% ------------------ 右图：WKB ------------------
ax2 = nexttile;
imagesc(ax2, xDir, thetaPlot, Zwkb.');
axis(ax2, 'xy');
axis(ax2, 'tight');
pbaspect(ax2, [1.2 1 1]);

xlabel(ax2, '$x$', ...
    'Interpreter', 'latex', ...
    'FontSize', labelFS);

ylabel(ax2, '$\theta$', ...
    'Interpreter', 'latex', ...
    'FontSize', labelFS);

title(ax2, 'WKB reconstruction $W\exp(u/\varepsilon)$', ...
    'Interpreter', 'latex', ...
    'FontSize', titleFS, ...
    'FontWeight', 'normal');

set(ax2, ...
    'FontName', fontName, ...
    'FontSize', axisFS, ...
    'LineWidth', 1.0, ...
    'TickLabelInterpreter', 'latex', ...
    'Box', 'on', ...
    'Layer', 'top', ...
    'XTick', 0:0.2:1, ...
    'YTick', 0:0.2:1);

xlim(ax2, [min(xDir), max(xDir)]);
ylim(ax2, [thetaPlot(1), thetaPlot(1) + thetaPeriod]);
caxis(ax2, clim_common);

% 统一 colormap 和一个 colorbar
colormap(fig, parula);

cb = colorbar(ax2, 'eastoutside');
cb.Label.String = cbarText;
cb.Label.Interpreter = 'latex';
cb.Label.FontSize = labelFS;
cb.TickLabelInterpreter = 'latex';
cb.FontSize = cbFS;
cb.LineWidth = 1.0;

% % 总标题
% sgtitle(tl, sprintf('Test 3: direct density vs WKB reconstruction, $t=%.4g$, $\\varepsilon=%.1e$', ...
%     targetTime, epsVal), ...
%     'Interpreter', 'latex', ...
%     'FontSize', mainFS, ...
%     'FontWeight', 'normal');

% 让两个子图色标完全一致
caxis(ax1, clim_common);
caxis(ax2, clim_common);

%% ========== 保存图片 ==========

if saveFig
    outDir = fullfile(dataDir, 'figures');
    if ~exist(outDir, 'dir')
        mkdir(outDir);
    end

    if plotLog10
        outName = sprintf('test3_heatmap_log10n_t%.6g_eps%.3g.png', targetTime, epsVal);
    else
        outName = sprintf('test3_heatmap_n_t%.6g_eps%.3g.png', targetTime, epsVal);
    end

    outFile = fullfile(outDir, outName);

    if exist('exportgraphics', 'file')
        exportgraphics(gcf, outFile, 'Resolution', 300);
    else
        print(gcf, outFile, '-dpng', '-r300');
    end

    fprintf('图片已保存：%s\n', outFile);
end

%% ========================================================================
%% 本脚本用到的局部函数
%% ========================================================================

function [fileName, selectedTime] = find_snapshot_file(dataDir, caseName, targetTime, isDirect)
% 自动寻找最接近 targetTime 的 snapshot 文件。
%
% isDirect = false:
%   baseline_..._t5.mat 或 baseline_..._t5.0001.mat
%
% isDirect = true:
%   baseline_..._direct_t5.mat 或 baseline_..._direct_t5.0001.mat

    if isDirect
        pattern = fullfile(dataDir, [caseName '_direct_t*.mat']);
    else
        pattern = fullfile(dataDir, [caseName '_t*.mat']);
    end

    files = dir(pattern);

    if isempty(files)
        if isDirect
            error('没有找到 direct 中间时刻文件：%s', pattern);
        else
            error('没有找到 WKB 中间时刻文件：%s', pattern);
        end
    end

    times = NaN(numel(files), 1);

    for i = 1:numel(files)
        name = files(i).name;

        if isDirect
            token = regexp(name, '_direct_t([0-9eE+\-.]+)\.mat$', 'tokens', 'once');
        else
            token = regexp(name, '_t([0-9eE+\-.]+)\.mat$', 'tokens', 'once');
        end

        if ~isempty(token)
            times(i) = str2double(token{1});
        end
    end

    good = isfinite(times);

    if ~any(good)
        error('找到文件，但无法从文件名解析时间：%s', pattern);
    end

    files = files(good);
    times = times(good);

    [~, id] = min(abs(times - targetTime));

    selectedTime = times(id);
    fileName = fullfile(dataDir, files(id).name);

    fprintf('目标时刻 %.8g，选中文件时刻 %.8g: %s\n', ...
        targetTime, selectedTime, fileName);
end

function val = get_first_var(S, names, optional, defaultVal)
% 在 mat 结构里面按候选变量名寻找变量。
% 支持递归寻找 struct 内部字段，比如 par.eps, op.x, one.n 等。

    if nargin < 3
        optional = false;
    end
    if nargin < 4
        defaultVal = [];
    end

    [found, val] = search_struct_recursive(S, names);

    if ~found
        if optional
            val = defaultVal;
        else
            error('找不到变量。候选名为：%s', strjoin(names, ', '));
        end
    end
end

function [found, val] = search_struct_recursive(S, names)
    found = false;
    val = [];

    if ~isstruct(S)
        return;
    end

    % 先在当前层找
    for k = 1:numel(names)
        nm = names{k};
        if isfield(S, nm)
            found = true;
            val = S.(nm);
            return;
        end
    end

    % 再递归进入子结构
    fns = fieldnames(S);

    for i = 1:numel(fns)
        obj = S.(fns{i});

        if isstruct(obj)
            [found, val] = search_struct_recursive(obj, names);
            if found
                return;
            end
        end
    end
end

function v = grid_vector(vRaw, whichGrid)
% 把 x/theta 网格整理成列向量。
% 如果输入是 meshgrid 形式的矩阵，则自动抽取变化的那一行/列。

    vRaw = double(squeeze(vRaw));

    if isvector(vRaw)
        v = vRaw(:);
        return;
    end

    if ndims(vRaw) ~= 2
        error('%s 网格不是向量或二维矩阵。', whichGrid);
    end

    col1 = vRaw(:, 1);
    row1 = vRaw(1, :);

    if numel(unique(col1)) > 1
        v = col1(:);
    elseif numel(unique(row1)) > 1
        v = row1(:);
    else
        v = unique(vRaw(:), 'stable');
        v = v(:);
    end
end

function A = to_xt_matrix(Araw, Nx, Ntheta, varName)
% 把变量整理成 Nx x Ntheta 的矩阵。
% 支持：
%   Nx x Ntheta
%   Ntheta x Nx
%   Nx x Ntheta x Nt
%   Ntheta x Nx x Nt
%   reshape 后长度为 Nx*Ntheta 的向量

    Araw = double(squeeze(Araw));

    if isvector(Araw)
        if numel(Araw) ~= Nx * Ntheta
            error('%s 是向量，但长度不是 Nx*Ntheta。', varName);
        end
        A = reshape(Araw, Nx, Ntheta);
        return;
    end

    if ndims(Araw) == 2
        if isequal(size(Araw), [Nx, Ntheta])
            A = Araw;
            return;
        elseif isequal(size(Araw), [Ntheta, Nx])
            A = Araw.';
            return;
        elseif numel(Araw) == Nx * Ntheta
            A = reshape(Araw, Nx, Ntheta);
            return;
        else
            error('%s 尺寸不匹配。size = [%s], 期望 Nx x Ntheta = %d x %d。', ...
                varName, num2str(size(Araw)), Nx, Ntheta);
        end
    end

    % 多维数组：寻找 Nx 和 Ntheta 对应的维度，其余维度取最后一帧
    sz = size(Araw);
    dimsX = find(sz == Nx);
    dimsT = find(sz == Ntheta);

    for ix = 1:numel(dimsX)
        for it = 1:numel(dimsT)
            dx = dimsX(ix);
            dt = dimsT(it);

            if dx == dt
                continue;
            end

            perm = [dx, dt, setdiff(1:ndims(Araw), [dx, dt])];
            Ap = permute(Araw, perm);

            idx = repmat({':'}, 1, ndims(Ap));
            for d = 3:ndims(Ap)
                idx{d} = size(Ap, d);
            end

            A = squeeze(Ap(idx{:}));

            if isequal(size(A), [Nx, Ntheta])
                return;
            end
        end
    end

    error('%s 无法整理成 Nx x Ntheta。size = [%s]', varName, num2str(size(Araw)));
end

function u = to_u_array(uraw, Nx, Ntheta, varName)
% 把 u 整理成：
%   1 x Ntheta，或者
%   Nx x Ntheta。

    uraw = double(squeeze(uraw));

    if isvector(uraw)
        if numel(uraw) ~= Ntheta
            error('%s 是向量，但长度不是 Ntheta。', varName);
        end
        u = uraw(:).';
        return;
    end

    if ndims(uraw) == 2
        sz = size(uraw);

        if isequal(sz, [Nx, Ntheta])
            u = uraw;
            return;
        elseif isequal(sz, [Ntheta, Nx])
            u = uraw.';
            return;
        elseif sz(1) == Ntheta
            % 例如 Ntheta x Nt，取最后一帧
            u = uraw(:, end).';
            return;
        elseif sz(2) == Ntheta
            % 例如 Nt x Ntheta，取最后一帧
            u = uraw(end, :);
            return;
        end
    end

    % 如果是更高维，尝试按 Nx x Ntheta 处理
    try
        u = to_xt_matrix(uraw, Nx, Ntheta, varName);
    catch
        error('%s 无法整理成 1 x Ntheta 或 Nx x Ntheta。', varName);
    end
end

function B = interp_x_if_needed(A, xOld, xNew)
% 如果 x 网格不同，把 A(x,theta) 插值到新的 x 网格。

    xOld = xOld(:);
    xNew = xNew(:);

    if numel(xOld) == numel(xNew) && max(abs(xOld - xNew)) < 1e-12
        B = A;
    else
        B = interp1(xOld, A, xNew, 'linear', 'extrap');
    end
end

function B = interp_theta_matrix_weno(A, thetaOld, thetaNew, period)
% 对矩阵 A(x,theta) 在 theta 方向做周期 WENO5 插值。
% 若 theta 网格相同，则直接返回 A。

    thetaOld = thetaOld(:);
    thetaNew = thetaNew(:);

    if numel(thetaOld) == numel(thetaNew)
        tol = 1e-12 * max(1, max(abs([thetaOld; thetaNew])));
        if max(abs(thetaOld - thetaNew)) <= tol
            B = A;
            return;
        end
    end

    Nx = size(A, 1);
    Nnew = numel(thetaNew);

    B = zeros(Nx, Nnew);

    for j = 1:Nx
        B(j, :) = weno5_periodic_interp(thetaOld, A(j, :), thetaNew, period).';
    end
end

function fq = weno5_periodic_interp(theta, f, thetaq, period)
% 周期 WENO5 点值重构。
%
% 输入：
%   theta  : 原 theta 网格，通常在 [0,1) 上均匀分布
%   f      : 原网格上的函数值
%   thetaq : 目标 theta 网格
%   period : 周期长度，本问题中为 1

    theta = theta(:);
    f = f(:);
    thetaq = thetaq(:);

    if nargin < 4 || isempty(period)
        period = 1.0;
    end

    % 如果 theta 同时包含 0 和 1 两个周期重复点，去掉最后一个
    if numel(theta) > 2
        if abs((theta(end) - theta(1)) - period) < 1e-10 * max(1, period)
            theta = theta(1:end-1);
            f = f(1:end-1);
        end
    end

    N = numel(theta);

    if N ~= numel(f)
        error('theta 和 f 的长度不一致。');
    end

    % WENO5 至少需要 5 个点
    if N < 5
        thetaExt = [theta - period; theta; theta + period];
        fExt = [f; f; f];

        tq = mod(thetaq - theta(1), period) + theta(1);
        fq = interp1(thetaExt, fExt, tq, 'pchip');
        return;
    end

    a = theta(1);
    dtheta = period / N;

    fq = zeros(size(thetaq));

    scaleF = max(1, max(abs(f)));
    epsW = 1e-14 * scaleF^2 + 1e-30;

    for iq = 1:numel(thetaq)

        % 映射到周期区间，并以最近网格点为中心
        s = mod((thetaq(iq) - a) / dtheta, N);

        q = round(s);       % 最近网格点的 0-based index
        r = s - q;          % 局部坐标，约在 [-1/2, 1/2]
        q = mod(q, N);
        i = q + 1;          % MATLAB 1-based index

        fm2 = f(wrap_index(i - 2, N));
        fm1 = f(wrap_index(i - 1, N));
        f0  = f(wrap_index(i,     N));
        fp1 = f(wrap_index(i + 1, N));
        fp2 = f(wrap_index(i + 2, N));

        % 三个二次插值多项式在局部点 r 的值
        p0 = lagrange3_eval(r, -2, -1,  0, fm2, fm1, f0);
        p1 = lagrange3_eval(r, -1,  0,  1, fm1, f0,  fp1);
        p2 = lagrange3_eval(r,  0,  1,  2, f0,  fp1, fp2);

        % Jiang-Shu smoothness indicators
        beta0 = (13/12) * (fm2 - 2*fm1 + f0)^2 ...
              + (1/4)  * (fm2 - 4*fm1 + 3*f0)^2;

        beta1 = (13/12) * (fm1 - 2*f0 + fp1)^2 ...
              + (1/4)  * (fm1 - fp1)^2;

        beta2 = (13/12) * (f0 - 2*fp1 + fp2)^2 ...
              + (1/4)  * (3*f0 - 4*fp1 + fp2)^2;

        % 对应局部坐标 r 的五阶理想权重
        d0 = r^2/12 - r/4 + 1/6;
        d1 = 2/3 - r^2/6;
        d2 = r^2/12 + r/4 + 1/6;

        % 非线性 WENO 权重
        a0 = d0 / (epsW + beta0)^2;
        a1 = d1 / (epsW + beta1)^2;
        a2 = d2 / (epsW + beta2)^2;

        asum = a0 + a1 + a2;

        w0 = a0 / asum;
        w1 = a1 / asum;
        w2 = a2 / asum;

        fq(iq) = w0*p0 + w1*p1 + w2*p2;
    end
end

function id = wrap_index(id, N)
% 周期下标
    id = mod(id - 1, N) + 1;
end

function y = lagrange3_eval(x, x0, x1, x2, y0, y1, y2)
% 三点 Lagrange 插值

    L0 = (x - x1) * (x - x2) / ((x0 - x1) * (x0 - x2));
    L1 = (x - x0) * (x - x2) / ((x1 - x0) * (x1 - x2));
    L2 = (x - x0) * (x - x1) / ((x2 - x0) * (x2 - x1));

    y = L0*y0 + L1*y1 + L2*y2;
end