%% post_plot_test2_Ptheta_correct_reconstruct.m
% 画 Test 2/Test 3 中不同时刻的 trait 边缘分布 P(theta)
%
% 【本版关键修正】
% 如果文件中保存的是 W 和 u，则不再先在粗网格上计算 P_k 后再插值。
% 正确顺序是：
%   1. 先在 theta 方向重构 W(x,theta) 和 u(theta)；
%   2. 再在细 theta 网格上计算 n_WKB = W * exp(u/eps)；
%   3. 最后对 x 积分得到 P(theta) = int n_WKB(x,theta) dx。
%
% 这样才和 WKB ansatz
%   n = W exp(u/eps)
% 一致。特别是在 eps 很小时，不能把插值放在 exp 之后。
%
% 说明：
%   - 如果文件中已有 P，则直接画 P。
%   - 如果文件中有 n，则由 n 对 x 方向积分得到 P。
%   - 如果文件中有 W,u，则使用上面的正确 WKB 重构顺序得到 P。
%
% 建议：
%   - wkbReconMethod = 'spline'：更接近旧代码/PDF 中 cubic spline + trapz 的做法。
%   - wkbReconMethod = 'pchip' ：更保形，不容易过冲。
%   - wkbReconMethod = 'weno'  ：可用于对比，但 K 很小，例如 K=7 时不推荐用它做最终画图结论。

% clear; clc; close all;

%% 路径设置
root = fileparts(fileparts(mfilename('fullpath')));
addpath(root);

if exist(fullfile(root, 'startup_AP_RML.m'), 'file')
    startup_AP_RML;
end

try
    outdir = utils.output_dir('test2_long_time');
catch
    outdir = fullfile(root, 'data', 'test2_long_time');
end

if ~exist(outdir, 'dir')
    error('找不到数据文件夹：%s', outdir);
end

%% 用户可调参数

% 按你的文件名修改这一行。
% 例如：
%   baseline_eps0.001_Nx200_K128_dt0.001_split_direct-log
caseKey = 'baseline_eps0.001_Nx200_K128_dt0.001_split_direct-log';

% 想画的时刻
targetTimes = [0, 0.1, 0.2, 0.5, 10];

% 文件名时间允许误差。
% 例如文件可能是 t40.001.mat，所以给一点容差。
timeTol = 5e-2;

% 是否将 P(theta) 归一化为 int P(theta) dtheta = 1
normalizeP = true;

% 是否额外读取 final 文件
includeFinal = false;

% 理论选择 trait 的位置。
% 如果想画竖线，例如 theta_m = 0.35，就设为 0.35。
% 不想画就设为 []。
theta_m = 0.35;

% WKB 后处理重构方法。
% 注意：这是对 W,u 做重构，然后再计算 W exp(u/eps)。
% 推荐 'spline' 或 'pchip'。
wkbReconMethod = 'weno';     % 'spline', 'pchip', 'linear', 'weno'

% 对已经得到的 P 或由 n 得到的 P，是否再做画图后处理。
% 注意：这只用于画平滑曲线，不代表 WKB 密度重构。
% 可选：
%   'none'      不后处理，只连原始点
%   'spline'    周期 spline 插值 P
%   'pchip'     周期 pchip 插值 P
%   'linear'    周期线性插值 P
%   'weno'      对 P 做 WENO 后处理
%   'weno_log'  对 log(P) 做 WENO 后处理，保持正性
PPostprocessMethod = 'none';

% 每个 theta 网格区间细分多少个点
refineFactor = 16;

% 防止 log(0)，只在 PPostprocessMethod='weno_log' 时使用
pFloorRel = 1e-14;

% 是否同时画原始离散点
showRawPoints = false;

% 是否保存图片
saveFig = true;

%% 搜索快照文件
allFiles = dir(fullfile(outdir, '*.mat'));

if isempty(allFiles)
    error('文件夹 %s 中没有找到 .mat 文件。', outdir);
end

% 只保留当前算例对应文件，并排除 final 文件
names = {allFiles.name};
isCase = contains(names, caseKey);
isFinal = contains(names, '_final.mat');

snapFiles = allFiles(isCase & ~isFinal);

if isempty(snapFiles)
    error('没有找到匹配 caseKey 的时间快照文件。请检查 caseKey 是否正确。');
end

% 解析文件名中的时间
snapTimes = nan(numel(snapFiles), 1);
for i = 1:numel(snapFiles)
    snapTimes(i) = parse_time_from_name(snapFiles(i).name);
end

valid = ~isnan(snapTimes);
snapFiles = snapFiles(valid);
snapTimes = snapTimes(valid);

if isempty(snapFiles)
    error('找到了 .mat 文件，但无法从文件名解析时间。文件名应类似 *_t20.mat。');
end

% 按时间排序
[snapTimes, order] = sort(snapTimes);
snapFiles = snapFiles(order);

%% 根据目标时刻选择文件
selectedFiles = struct([]);
selectedTimes = [];

for q = 1:numel(targetTimes)
    tq = targetTimes(q);
    [dtmin, idx] = min(abs(snapTimes - tq));

    if dtmin <= timeTol
        selectedFiles = [selectedFiles; snapFiles(idx)]; %#ok<AGROW>
        selectedTimes = [selectedTimes; snapTimes(idx)]; %#ok<AGROW>
    else
        warning('没有找到 t = %.6g 附近的文件，最近的是 t = %.6g。', tq, snapTimes(idx));
    end
end

% 去重，避免同一个文件被重复选中
[~, ia] = unique({selectedFiles.name}, 'stable');
selectedFiles = selectedFiles(ia);
selectedTimes = selectedTimes(ia);

%% 是否加入 final 文件
if includeFinal
    finalFiles = allFiles(isCase & isFinal);
    if ~isempty(finalFiles)
        selectedFiles = [selectedFiles; finalFiles(end)];
        selectedTimes = [selectedTimes; NaN];
    else
        warning('没有找到 final 文件。');
    end
end

if isempty(selectedFiles)
    error('没有选中任何可画的文件。');
end

%% 读取并画图
figure('Color', 'w', 'Position', [100, 100, 760, 520]);
hold on; box on; grid on;

lineStyles = {'-', '--', ':', '-.', '-','--'};
markers = {'o', 's', '^', 'd', 'v', '>', '<'};

legText = cell(numel(selectedFiles), 1);

opts = struct();
opts.normalizeP = normalizeP;
opts.refineFactor = refineFactor;
opts.wkbReconMethod = wkbReconMethod;
opts.PPostprocessMethod = PPostprocessMethod;
opts.pFloorRel = pFloorRel;

for i = 1:numel(selectedFiles)
    fname = fullfile(selectedFiles(i).folder, selectedFiles(i).name);
    fprintf('读取文件：%s\n', selectedFiles(i).name);

    S = load(fname);

    [thetaRaw, PRaw, thetaPlot, PPlot, info] = extract_theta_curve_correct(S, selectedFiles(i).name, opts);

    ls = lineStyles{mod(i-1, numel(lineStyles)) + 1};
    mk = markers{mod(i-1, numel(markers)) + 1};

    nMarkers = 10;
    markerIndexPlot = round(linspace(1, numel(thetaPlot), min(nMarkers, numel(thetaPlot))));
    markerIndexPlot = unique(markerIndexPlot);

    hLine = plot(thetaPlot, PPlot, ...
        'LineStyle', ls, ...
        'Marker', mk, ...
        'MarkerIndices', markerIndexPlot, ...
        'LineWidth', 2.4, ...
        'MarkerSize', 8);

    % 可选：叠加原始离散点，用于检查后处理是否偏离原始数据
    if showRawPoints && ~isempty(thetaRaw) && ~isempty(PRaw)
        nRawMarkers = 12;
        markerIndexRaw = round(linspace(1, numel(thetaRaw), min(nRawMarkers, numel(thetaRaw))));
        markerIndexRaw = unique(markerIndexRaw);

        plot(thetaRaw(markerIndexRaw), PRaw(markerIndexRaw), ...
            'LineStyle', 'none', ...
            'Marker', mk, ...
            'MarkerSize', 6, ...
            'LineWidth', 1.2, ...
            'Color', hLine.Color, ...
            'HandleVisibility', 'off');
    end

    if isnan(selectedTimes(i))
        legText{i} = sprintf('final (%s)', info.source);
    else
        legText{i} = sprintf('$t=%.3g$', selectedTimes(i));
    end

    fprintf('  数据来源: %s\n', info.source);
    fprintf('  theta 原始点数: %d, 画图点数: %d\n', numel(thetaRaw), numel(thetaPlot));
end

%% 画 theta_m
if ~isempty(theta_m)
    yl = ylim;

    xline(theta_m, '--', ...
        'Color', [0.5 0.5 0.5], ...
        'LineWidth', 2.4, ...
        'HandleVisibility', 'off');

    text(theta_m + 0.01, yl(1) + 0.96*(yl(2)-yl(1)), ...
        sprintf('$\\theta_m=%.3g$', theta_m), ...
        'Interpreter', 'latex', ...
        'FontSize', 18, ...
        'Color', [0.2 0.2 0.2], ...
        'HorizontalAlignment', 'left', ...
        'VerticalAlignment', 'top', ...
        'Rotation', 0);
end

xlabel('$\theta$', 'Interpreter', 'latex', 'FontSize', 22);
ylabel('$P(\theta)$', 'Interpreter', 'latex', 'FontSize', 22);

legend(legText, 'Interpreter', 'latex', 'Location', 'Northeast', 'FontSize', 22);
set(gca, 'FontSize', 18, 'LineWidth', 1.2);

xlim([0, 1]);

%% 保存图片
figdir = fullfile(root, 'figures', 'test2_long_time');
if ~exist(figdir, 'dir')
    mkdir(figdir);
end

figbase = fullfile(figdir, sprintf('test2_Ptheta_long_time_%s', wkbReconMethod));

if saveFig
    try
        exportgraphics(gcf, [figbase, '.png'], 'Resolution', 300);
        exportgraphics(gcf, [figbase, '.pdf'], 'ContentType', 'vector');
    catch
        print(gcf, [figbase, '.png'], '-dpng', '-r300');
        print(gcf, [figbase, '.eps'], '-depsc');
    end

    fprintf('图片已保存到：\n%s\n', figdir);
end

%% ========================================================================
% 局部函数
% ========================================================================

function [thetaRaw, PRaw, thetaPlot, PPlot, info] = extract_theta_curve_correct(S, fname, opts)
% 从文件中提取或构造 P(theta)。
%
% 修正点：
%   如果文件中有 W,u，则优先使用正确 WKB 顺序：
%       先重构 W,u -> 再算 W exp(u/eps) -> 再对 x 积分。
%
% 返回：
%   thetaRaw, PRaw   原始网格上的 P，用于画原始点
%   thetaPlot, PPlot 后处理/重构后的曲线，用于画线
%   info.source      数据来源说明

    info = struct();
    info.source = '';

    theta = find_numeric_field(S, ...
        {'theta', 'theta_grid', 'thetaGrid', 'theta_k', 'thetaVec', 'th'});

    x = find_numeric_field(S, ...
        {'x', 'xgrid', 'x_grid', 'xGrid', 'xx'});

    epsVal = find_scalar_field(S, ...
        {'eps', 'epsilon', 'varepsilon', 'epsVal'});

    if isempty(epsVal)
        epsVal = parse_eps_from_name(fname);
    end

    K_from_name = parse_K_from_name(fname);

    % --------------------------------------------------------------------
    % 优先检查 W,u。
    % 对 WKB 数据，这是最正确的方式。
    % 注意这里故意不把 W0,u0 加进候选名，避免 direct 文件里的初值被误判成 WKB 解。
    % --------------------------------------------------------------------
    W = find_numeric_field(S, {'W', 'w', 'W_wkb', 'amp', 'amplitude', 'A'});
    u = find_numeric_field(S, {'u', 'U', 'u_wkb', 'phase', 'phi'});

    if ~isempty(W) && ~isempty(u) && ~isempty(epsVal)
        [thetaRaw, PRaw, thetaPlot, PPlot] = marginal_from_W_u_reconstruct_first( ...
            W, u, epsVal, theta, x, K_from_name, opts);
        info.source = sprintf('W,u -> %s reconstruction -> W exp(u/eps)', opts.wkbReconMethod);
        return;
    end

    % --------------------------------------------------------------------
    % 如果文件中已经有 P，则直接使用。
    % --------------------------------------------------------------------
    P = find_numeric_field(S, ...
        {'P', 'Pk', 'P_k', 'Ptheta', 'P_theta', ...
         'trait_marginal', 'traitMarginal', 'prob_theta'});

    if ~isempty(P)
        P = squeeze(P);

        if isempty(theta)
            K = numel(P);
            theta = (0:K-1)' / K;
        end

        thetaRaw = grid_vector(theta);
        PRaw = real(P(:));

        [thetaRaw, PRaw] = sort_theta_P(thetaRaw, PRaw);
        [thetaRaw, PRaw, thetaPlot, PPlot] = normalize_and_postprocess_P(thetaRaw, PRaw, opts);
        info.source = 'saved P';
        return;
    end

    % --------------------------------------------------------------------
    % 如果有 n，则对 x 积分得到 P。
    % --------------------------------------------------------------------
    n = find_numeric_field(S, ...
        {'n', 'density', 'rho_jk', 'rhoJK', 'n_jk', 'nJK', 'n_direct'});

    if ~isempty(n)
        n = squeeze(n);
        [thetaRaw, PRaw] = marginal_from_density(n, theta, x, K_from_name);

        [thetaRaw, PRaw] = sort_theta_P(thetaRaw, PRaw);
        [thetaRaw, PRaw, thetaPlot, PPlot] = normalize_and_postprocess_P(thetaRaw, PRaw, opts);
        info.source = 'n -> int_x n dx';
        return;
    end

    disp('当前 .mat 文件中的顶层变量为：');
    disp(fieldnames(S));

    error(['无法从文件 %s 中提取 P(theta)。请检查 .mat 文件中是否保存了 P、n，', ...
           '或者 W,u,eps。'], fname);
end

function [thetaRaw, PRaw, thetaFine, PFine] = marginal_from_W_u_reconstruct_first( ...
    Wraw, uraw, epsVal, theta, x, K_from_name, opts)
% 正确的 WKB trait marginal 重构：
%   1. 在 theta 上重构 W 和 u；
%   2. 计算 n = W exp(u/eps)；
%   3. 对 x 积分得到 P(theta)。

    period = 1.0;

    Wraw = double(squeeze(Wraw));
    uraw = double(squeeze(uraw));

    % 判断 theta 网格
    if ~isempty(theta)
        thetaRaw = grid_vector(theta);
        K = numel(thetaRaw);
    elseif ~isempty(K_from_name)
        K = K_from_name;
        thetaRaw = (0:K-1)' / K;
    elseif isvector(uraw)
        K = numel(uraw);
        thetaRaw = (0:K-1)' / K;
    else
        K = min(size(Wraw));
        thetaRaw = (0:K-1)' / K;
    end

    % 整理 W 的维度为 Nx x K
    [W, Nx] = to_xt_matrix_with_K(Wraw, K, x, 'W');

    % 整理 u 的维度为 1 x K 或 Nx x K
    u = to_u_array_with_K(uraw, Nx, K, 'u');

    % 如果 x 网格不存在，使用均匀权重；通常实际文件中会有 x。
    wx = integration_weights_x(x, Nx);

    % 原始粗网格 P，用于画原始点或检查
    if isvector(u)
        Uraw = repmat(u(:).', Nx, 1);
    else
        Uraw = u;
    end

    argRaw = Uraw / epsVal;
    argRaw = min(max(argRaw, -745), 700);

    nRaw = W .* exp(argRaw);
    PRaw = wx.' * nRaw;
    PRaw = real(PRaw(:));

    % 在 theta 方向细化
    Nfine = max(K, K * opts.refineFactor);
    thetaFine = linspace(thetaRaw(1), thetaRaw(1) + period, Nfine + 1).';
    thetaFine(end) = [];

    % 重构 W(x,theta)
    Wfine = zeros(Nx, numel(thetaFine));
    for j = 1:Nx
        Wfine(j, :) = periodic_interp(thetaRaw, W(j, :), thetaFine, period, opts.wkbReconMethod).';
    end

    % 重构 u(theta) 或 u(x,theta)
    if isvector(u)
        ufine = periodic_interp(thetaRaw, u(:), thetaFine, period, opts.wkbReconMethod).';
        Ufine = repmat(ufine(:).', Nx, 1);
    else
        Ufine = zeros(Nx, numel(thetaFine));
        for j = 1:Nx
            Ufine(j, :) = periodic_interp(thetaRaw, u(j, :), thetaFine, period, opts.wkbReconMethod).';
        end
    end

    % 插值可能产生极小负 W；密度中截断负值。
    Wfine(Wfine < 0) = 0;

    arg = Ufine / epsVal;
    arg = min(max(arg, -745), 700);

    nFine = Wfine .* exp(arg);

    PFine = wx.' * nFine;
    PFine = real(PFine(:));

    % 归一化。注意粗网格和细网格分别归一化，便于同一张图比较形状。
    if opts.normalizeP
        PRaw = normalize_periodic_density(thetaRaw, PRaw, period);
        PFine = normalize_periodic_density(thetaFine, PFine, period);
    end
end

function [theta, P] = marginal_from_density(n, theta, x, K_from_name)
% 由 n_{j,k} 对 x 方向积分得到 P(theta_k)

    n = double(squeeze(n));

    if ndims(n) ~= 2
        error('当前只支持二维密度数组 n_{j,k}。');
    end

    if ~isempty(theta)
        theta = grid_vector(theta);
        K = numel(theta);
    elseif ~isempty(K_from_name)
        K = K_from_name;
        theta = (0:K-1)' / K;
    else
        % 默认较小维度是 theta 方向
        K = min(size(n));
        theta = (0:K-1)' / K;
    end

    if size(n, 2) == K
        nmat = n;
    elseif size(n, 1) == K
        nmat = n.';
    else
        error('无法判断 n 的哪一维是 theta 方向。size(n)=[%s], K=%d。', num2str(size(n)), K);
    end

    Nx = size(nmat, 1);
    wx = integration_weights_x(x, Nx);

    P = wx.' * nmat;
    P = real(P(:));
end

function [thetaRaw, PRaw, thetaPlot, PPlot] = normalize_and_postprocess_P(thetaRaw, PRaw, opts)
% 对已经得到的 P(theta) 做归一化和可选的画图后处理。
% 注意：这不是 WKB 密度重构，只是对 P 曲线做可视化后处理。

    period = 1.0;

    if opts.normalizeP
        PRaw = normalize_periodic_density(thetaRaw, PRaw, period);
    end

    method = lower(opts.PPostprocessMethod);

    switch method
        case 'none'
            thetaPlot = thetaRaw;
            PPlot = PRaw;

        case {'spline', 'pchip', 'linear'}
            Nfine = max(numel(thetaRaw), opts.refineFactor*numel(thetaRaw));
            thetaPlot = linspace(thetaRaw(1), thetaRaw(1) + period, Nfine + 1).';
            thetaPlot(end) = [];

            PPlot = periodic_interp(thetaRaw, PRaw, thetaPlot, period, method);
            PPlot = max(real(PPlot(:)), 0);

            if opts.normalizeP
                PPlot = normalize_periodic_density(thetaPlot, PPlot, period);
            end

        case 'weno'
            [thetaPlot, PPlot] = weno5_postprocess_periodic( ...
                thetaRaw, PRaw, opts.refineFactor, false, opts.pFloorRel, opts.normalizeP);

        case 'weno_log'
            [thetaPlot, PPlot] = weno5_postprocess_periodic( ...
                thetaRaw, PRaw, opts.refineFactor, true, opts.pFloorRel, opts.normalizeP);

        otherwise
            error('未知 PPostprocessMethod=%s。', opts.PPostprocessMethod);
    end
end

function Pn = normalize_periodic_density(theta, P, period)
% 归一化，使 int P(theta)dtheta = 1。
% 假设 theta 是均匀周期网格，不含重复终点。

    if nargin < 3
        period = 1.0;
    end

    theta = theta(:);
    P = P(:);

    dtheta = period / numel(theta);
    mass = dtheta * sum(P);

    if mass > 0
        Pn = P / mass;
    else
        warning('P 的总量非正，跳过归一化。');
        Pn = P;
    end
end

function [theta, P] = sort_theta_P(theta, P)
    theta = theta(:);
    P = P(:);

    [theta, idx] = sort(theta);
    P = P(idx);
end

function [A, Nx] = to_xt_matrix_with_K(Araw, K, x, varName)
% 将 A 整理成 Nx x K。

    Araw = double(squeeze(Araw));

    if isvector(Araw)
        error('%s 应为二维矩阵，但当前是向量。', varName);
    end

    if ~isempty(x)
        NxExpected = numel(grid_vector(x));

        if isequal(size(Araw), [NxExpected, K])
            A = Araw;
        elseif isequal(size(Araw), [K, NxExpected])
            A = Araw.';
        else
            error('%s 尺寸不匹配。size=[%s], 期望 Nx x K = %d x %d。', ...
                varName, num2str(size(Araw)), NxExpected, K);
        end

        Nx = NxExpected;
        return;
    end

    if size(Araw, 2) == K
        A = Araw;
    elseif size(Araw, 1) == K
        A = Araw.';
    else
        error('%s 尺寸不匹配，无法根据 K=%d 判断 theta 维。size=[%s]。', ...
            varName, K, num2str(size(Araw)));
    end

    Nx = size(A, 1);
end

function u = to_u_array_with_K(uraw, Nx, K, varName)
% 将 u 整理成 1 x K 或 Nx x K。

    uraw = double(squeeze(uraw));

    if isvector(uraw)
        if numel(uraw) ~= K
            error('%s 是向量，但长度不是 K。numel=%d, K=%d。', varName, numel(uraw), K);
        end

        u = uraw(:).';
        return;
    end

    if isequal(size(uraw), [Nx, K])
        u = uraw;
    elseif isequal(size(uraw), [K, Nx])
        u = uraw.';
    elseif size(uraw, 1) == K
        % 例如 K x Nt，取最后一帧
        u = uraw(:, end).';
    elseif size(uraw, 2) == K
        % 例如 Nt x K，取最后一帧
        u = uraw(end, :);
    else
        error('%s 尺寸不匹配。size=[%s], 期望 1xK 或 Nx x K。', ...
            varName, num2str(size(uraw)));
    end
end

function wx = integration_weights_x(x, Nx)
% x 方向积分权重。
% 如果有 x 网格，用梯形权重；
% 如果没有 x 网格，则退化为简单求和权重。

    if ~isempty(x)
        x = grid_vector(x);

        if numel(x) ~= Nx
            warning('x 网格长度和数据 Nx 不一致，改用简单求和权重。');
            wx = ones(Nx, 1);
            return;
        end

        wx = trapz_weights_from_x(x);
    else
        wx = ones(Nx, 1);
    end
end

function fq = periodic_interp(theta, f, thetaq, period, method)
% 周期插值统一入口。
% method:
%   'spline', 'pchip', 'linear', 'weno'

    theta = theta(:);
    f = f(:);
    thetaq = thetaq(:);

    if nargin < 5 || isempty(method)
        method = 'spline';
    end

    method = lower(method);

    switch method
        case {'spline', 'pchip', 'linear'}
            fq = periodic_interp1(theta, f, thetaq, period, method);

        case 'weno'
            fq = weno5_periodic_interp(theta, f, thetaq, period);

        otherwise
            error('未知插值方法：%s。', method);
    end
end

function fq = periodic_interp1(theta, f, thetaq, period, method)
% 周期 interp1。
% 通过补上周期端点 f(1) 实现。

    theta = theta(:);
    f = f(:);
    thetaq = thetaq(:);

    % 如果 theta 已经含有重复周期端点，则去掉最后一个
    if numel(theta) > 2 && abs((theta(end) - theta(1)) - period) < 1e-12
        theta = theta(1:end-1);
        f = f(1:end-1);
    end

    thetaExt = [theta; theta(1) + period];
    fExt = [f; f(1)];

    tq = mod(thetaq - theta(1), period) + theta(1);

    fq = interp1(thetaExt, fExt, tq, method);
    fq = fq(:);
end

function t = parse_time_from_name(fname)
% 从文件名中解析时间，例如 *_t20.mat 或 *_t40.001.mat

    tok = regexp(fname, '_t([0-9]*\.?[0-9]+)\.mat$', 'tokens', 'once');
    if isempty(tok)
        t = NaN;
    else
        t = str2double(tok{1});
    end
end

function v = find_numeric_field(S, names)
% 在结构体中递归查找某些变量名，返回第一个数值变量。
% 忽略大小写。

    v = find_field_recursive(S, names, 5);

    if ~isempty(v)
        if isnumeric(v) || islogical(v)
            v = double(v);
        else
            v = [];
        end
    end
end

function v = find_scalar_field(S, names)
% 在结构体中递归查找标量变量

    v = find_numeric_field(S, names);

    if isempty(v) || ~isscalar(v)
        v = [];
    end
end

function v = find_field_recursive(S, names, depth)
% 递归查找字段名，忽略大小写

    v = [];

    if depth < 0 || ~isstruct(S)
        return;
    end

    f = fieldnames(S);

    % 先查当前层
    for i = 1:numel(f)
        if any(strcmpi(f{i}, names))
            v = S.(f{i});
            return;
        end
    end

    % 再查子结构
    for i = 1:numel(f)
        child = S.(f{i});
        if isstruct(child)
            v = find_field_recursive(child, names, depth - 1);
            if ~isempty(v)
                return;
            end
        end
    end
end

function K = parse_K_from_name(fname)
% 从文件名中解析 K，例如 *_K128_*

    tok = regexp(fname, 'K(\d+)', 'tokens', 'once');

    if isempty(tok)
        K = [];
    else
        K = str2double(tok{1});
    end
end

function epsVal = parse_eps_from_name(fname)
% 从文件名中解析 eps，例如 baseline_eps0.01_*

    tok = regexp(fname, 'eps([0-9]*\.?[0-9]+([eE][-+]?\d+)?)', 'tokens', 'once');

    if isempty(tok)
        epsVal = [];
    else
        epsVal = str2double(tok{1});
    end
end

function v = grid_vector(vRaw)
% 将网格整理成列向量。
% 如果是 meshgrid 矩阵，尝试取变化的行或列。

    vRaw = double(squeeze(vRaw));

    if isvector(vRaw)
        v = vRaw(:);
        return;
    end

    col1 = vRaw(:, 1);
    row1 = vRaw(1, :);

    if numel(unique(col1)) > 1
        v = col1(:);
    elseif numel(unique(row1)) > 1
        v = row1(:);
    else
        v = unique(vRaw(:), 'stable');
        v = v(:);
    end
end

function wx = trapz_weights_from_x(x)
% 根据 x 网格构造梯形积分权重。

    x = x(:);
    Nx = numel(x);

    if Nx < 2
        wx = 1;
        return;
    end

    wx = zeros(Nx, 1);

    wx(1) = 0.5 * (x(2) - x(1));
    wx(end) = 0.5 * (x(end) - x(end-1));

    for j = 2:Nx-1
        wx(j) = 0.5 * (x(j+1) - x(j-1));
    end
end

function dtheta = estimate_dtheta(theta)
% 估计均匀 theta 网格步长

    theta = theta(:);
    if numel(theta) <= 1
        dtheta = 1;
        return;
    end

    d = diff(sort(theta));
    d = d(d > 0);

    if isempty(d)
        dtheta = 1 / numel(theta);
    else
        dtheta = median(d);
    end
end

function [thetaFine, PFine] = weno5_postprocess_periodic(theta, P, refineFactor, wenoOnLog, pFloorRel, normalizeP)
% 对周期 theta 网格上的 P_k 做 WENO5 后处理，生成更密的画图点。
%
% 注意：
%   这个函数只用于已经得到的 P(theta) 的可视化。
%   它不应用来替代 WKB 的 W,u 重构。

    theta = theta(:);
    P = P(:);

    [theta, idx] = sort(theta);
    P = P(idx);

    K = numel(theta);

    if K < 5
        error('WENO5 至少需要 5 个 theta 网格点。');
    end

    h = median(diff(theta));
    L = K*h;

    if wenoOnLog
        pFloor = pFloorRel * max(P);
        if pFloor <= 0
            pFloor = pFloorRel;
        end

        q = log(max(P, pFloor));
        qFine = weno5_eval_periodic(theta, q, refineFactor);
        thetaFine = qFine(:,1);
        PFine = exp(qFine(:,2));
    else
        qFine = weno5_eval_periodic(theta, P, refineFactor);
        thetaFine = qFine(:,1);
        PFine = qFine(:,2);
        PFine = max(PFine, 0);
    end

    if normalizeP
        hf = h/refineFactor;

        if numel(PFine) > 1
            massFine = sum(PFine(1:end-1)) * hf;
        else
            massFine = sum(PFine) * hf;
        end

        if massFine > 0
            PFine = PFine / massFine;
        end
    end

    if abs(theta(1)) < 1e-12
        thetaFine(end) = theta(1) + L;
    end
end

function out = weno5_eval_periodic(theta, q, refineFactor)
% 在周期均匀网格上对 q(theta) 做 WENO5 加密插值。
% 输出 out(:,1) 为 thetaFine，out(:,2) 为 qFine。

    theta = theta(:);
    q = q(:);

    K = numel(theta);
    h = median(diff(theta));

    nFine = K*refineFactor + 1;
    thetaFine = zeros(nFine, 1);
    qFine = zeros(nFine, 1);

    cnt = 0;

    for i = 1:K
        for r = 0:refineFactor-1
            s = r/refineFactor;

            cnt = cnt + 1;
            thetaFine(cnt) = theta(i) + s*h;
            qFine(cnt) = weno5_local_value(q, i, s);
        end
    end

    cnt = cnt + 1;
    thetaFine(cnt) = theta(1) + K*h;
    qFine(cnt) = qFine(1);

    out = [thetaFine, qFine];
end

function fq = weno5_periodic_interp(theta, f, thetaq, period)
% 周期 WENO5 点值插值。
% 这里主要用于对 W,u 做后处理重构。
% K 很小时不建议作为最终图的默认方法；推荐 spline 或 pchip。

    theta = theta(:);
    f = f(:);
    thetaq = thetaq(:);

    if nargin < 4
        period = 1.0;
    end

    K = numel(theta);

    if K < 5
        fq = periodic_interp1(theta, f, thetaq, period, 'pchip');
        return;
    end

    h = period / K;
    fq = zeros(size(thetaq));

    for iq = 1:numel(thetaq)
        sGlobal = mod((thetaq(iq) - theta(1)) / h, K);
        i0 = floor(sGlobal) + 1;
        s = sGlobal - floor(sGlobal);

        if i0 > K
            i0 = 1;
        end

        fq(iq) = weno5_local_value(f, i0, s);
    end

    fq = fq(:);
end

function val = weno5_local_value(q, i, s)
% 在区间 [theta_i, theta_{i+1}] 内的局部坐标 s in [0,1]
% 使用三个二次模板做 WENO5 插值。
%
% 模板：
%   S0 = {i-2, i-1, i}
%   S1 = {i-1, i, i+1}
%   S2 = {i, i+1, i+2}

    K = numel(q);

    im2 = periodic_index(i-2, K);
    im1 = periodic_index(i-1, K);
    i0  = periodic_index(i,   K);
    ip1 = periodic_index(i+1, K);
    ip2 = periodic_index(i+2, K);

    qm2 = q(im2);
    qm1 = q(im1);
    q0  = q(i0);
    qp1 = q(ip1);
    qp2 = q(ip2);

    p0 = 0.5*s*(s+1)*qm2 ...
       - s*(s+2)*qm1 ...
       + 0.5*(s+1)*(s+2)*q0;

    p1 = 0.5*s*(s-1)*qm1 ...
       + (1-s^2)*q0 ...
       + 0.5*s*(s+1)*qp1;

    p2 = 0.5*(s-1)*(s-2)*q0 ...
       - s*(s-2)*qp1 ...
       + 0.5*s*(s-1)*qp2;

    beta0 = (13/12)*(qm2 - 2*qm1 + q0)^2 ...
          + (1/4)*(qm2 - 4*qm1 + 3*q0)^2;

    beta1 = (13/12)*(qm1 - 2*q0 + qp1)^2 ...
          + (1/4)*(qm1 - qp1)^2;

    beta2 = (13/12)*(q0 - 2*qp1 + qp2)^2 ...
          + (1/4)*(3*q0 - 4*qp1 + qp2)^2;

    d0 = s^2/12 - s/4 + 1/6;
    d1 = 2/3 - s^2/6;
    d2 = s^2/12 + s/4 + 1/6;

    epsW = 1e-12;
    powW = 2;

    a0 = d0 / (epsW + beta0)^powW;
    a1 = d1 / (epsW + beta1)^powW;
    a2 = d2 / (epsW + beta2)^powW;

    asum = a0 + a1 + a2;

    if asum <= 0 || ~isfinite(asum)
        w0 = d0;
        w1 = d1;
        w2 = d2;
    else
        w0 = a0 / asum;
        w1 = a1 / asum;
        w2 = a2 / asum;
    end

    val = w0*p0 + w1*p1 + w2*p2;
end

function idx = periodic_index(i, K)
% 将任意整数索引映射到 1,...,K。

    idx = mod(i-1, K) + 1;
end
