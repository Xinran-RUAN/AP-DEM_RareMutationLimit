%% post_plot_test2_Ptheta_eps_compare_final_correct_reconstruct.m
% 画 Test 2 中不同 epsilon 下终止时刻的 trait 边缘分布 P(theta)
%
% 重要修正：
%   对 WKB 结果，不能先在粗网格上计算 P_k 再对 P_k 做 WENO/spline。
%   正确顺序是：
%       1. 先在 theta 方向重构 W(x,theta) 和 u(theta)
%       2. 再计算 n_WKB(x,theta)=W(x,theta)*exp(u(theta)/eps)
%       3. 最后对 x 积分得到 P(theta)=int n_WKB(x,theta) dx
%
% 使用方法：
%   将本文件放在 post 文件夹下，然后直接运行。
%
% 说明：
%   1. 优先读取 *_final.mat；
%   2. 如果没有 *_final.mat，则读取该文件夹中时间最大的 *_t*.mat；
%   3. 如果文件中有 W 和 u，则优先按正确 WKB 顺序重构 P(theta)；
%   4. 如果没有 W,u，则退回到已保存的 P 或由 n 对 x 积分得到 P；
%   5. 不再对已经得到的 P_k 做默认 WENO 后处理。

clear; clc; close all;

%% ========== 路径设置 ==========

root = fileparts(fileparts(mfilename('fullpath')));
addpath(root);

if exist(fullfile(root, 'startup_AP_RML.m'), 'file')
    startup_AP_RML;
end

%% ========== 用户可调参数 ==========

% 不同 epsilon 对应的数据文件夹
cases = struct([]);

cases(1).eps    = 1e-2;
cases(1).folder = 'test2_long_time_homo_eps001';
cases(1).label  = '$\varepsilon=1.0\times 10^{-2}$';

cases(2).eps    = 2e-3;
cases(2).folder = 'test2_long_time_homo_eps0002';
cases(2).label  = '$\varepsilon=2.0\times 10^{-3}$';

cases(3).eps    = 1e-3;
cases(3).folder = 'test2_long_time_homo_eps0001';
cases(3).label  = '$\varepsilon=1.0\times 10^{-3}$';

cases(4).eps    = 2e-4;
cases(4).folder = 'test2_long_time_homo_eps00002';
cases(4).label  = '$\varepsilon=2.0\times 10^{-4}$';

cases(5).eps    = 1e-4;
cases(5).folder = 'test2_long_time_homo_eps00001';
cases(5).label  = '$\varepsilon=1.0\times 10^{-4}$';

% 是否归一化为 int_0^1 P(theta)dtheta = 1
% 为了比较不同 epsilon 下的集中形状，建议设为 true
normalizeP = true;

% 理论选择 trait 的位置
theta_m = 0.35;

% WKB 重构设置
%   'spline'：周期三次样条，接近旧代码和 PDF 中的 cubic spline interpolation
%   'pchip' ：保形插值，较少过冲
%   'weno'  ：WENO5 函数值重构。K 很小时不建议用于最终图
%   'linear': 线性插值
wkbReconMethod = 'spline';

% WKB 重构细化倍数。若原始 K=128，则细网格点数约为 128*refineFactor
refineFactor = 16;

% 如果文件中没有 W,u，而只有 P 或 n，是否对 P 做画图插值
%   'none'  : 不插值，只画原始点连线
%   'pchip' : 对 P 做周期 pchip 插值
%   'spline': 对 P 做周期 spline 插值
%   'weno'  : 对 P 做 WENO 后处理，不建议作为默认
fallbackPPostprocess = 'none';

% 是否同时画原始离散点
showRawPoints = false;

% 图像保存名称
figName = 'test2_Ptheta_eps_compare_final_correct_reconstruct';

%% ========== 读取并画图 ==========

figure('Color', 'w', 'Position', [100, 100, 760, 520]);
hold on; box on; grid on;

lineStyles = {'-', '--', '-.', ':', '-', '--', '-.'};
markers = {'o', 's', '^', 'd', 'v', '>', '<'};

legHandles = gobjects(0);
legText = {};

for i = 1:numel(cases)

    % 数据文件夹
    try
        outdir = utils.output_dir(cases(i).folder);
    catch
        outdir = fullfile(root, 'data', cases(i).folder);
    end

    if ~exist(outdir, 'dir')
        warning('找不到数据文件夹：%s，跳过该组。', outdir);
        continue;
    end

    % 选择终止时刻文件
    [fname, finalTime] = choose_terminal_file(outdir);

    if isempty(fname)
        warning('文件夹 %s 中没有找到可用的 .mat 文件，跳过该组。', outdir);
        continue;
    end

    fprintf('\n[case %d] epsilon = %.4g\n', i, cases(i).eps);
    fprintf('读取文件：%s\n', fname);

    S = load(fname);

    % 正确提取 P(theta)
    % 若有 W,u，则先重构 W,u，再计算 W*exp(u/eps)，最后积分。
    [thetaPlot, PPlot, thetaRaw, PRaw, info] = extract_theta_P_correct( ...
        S, fname, cases(i).eps, normalizeP, refineFactor, ...
        wkbReconMethod, fallbackPPostprocess);

    thetaPlot = thetaPlot(:);
    PPlot = PPlot(:);
    thetaRaw = thetaRaw(:);
    PRaw = PRaw(:);

    ls = lineStyles{mod(i-1, numel(lineStyles)) + 1};
    mk = markers{mod(i-1, numel(markers)) + 1};

    nMarkers = 10;
    markerIndexPlot = round(linspace(1, numel(thetaPlot), min(nMarkers, numel(thetaPlot))));
    markerIndexPlot = unique(markerIndexPlot);

    hLine = plot(thetaPlot, PPlot, ...
        'LineStyle', ls, ...
        'Marker', mk, ...
        'MarkerIndices', markerIndexPlot, ...
        'LineWidth', 2.4, ...
        'MarkerSize', 8);

    if showRawPoints && ~isempty(thetaRaw)
        nRawMarkers = min(12, numel(thetaRaw));
        markerIndexRaw = round(linspace(1, numel(thetaRaw), nRawMarkers));
        markerIndexRaw = unique(markerIndexRaw);

        plot(thetaRaw(markerIndexRaw), PRaw(markerIndexRaw), ...
            'LineStyle', 'none', ...
            'Marker', mk, ...
            'MarkerSize', 6, ...
            'LineWidth', 1.2, ...
            'Color', hLine.Color, ...
            'HandleVisibility', 'off');
    end

    legHandles(end+1) = hLine; %#ok<SAGROW>

    if isnan(finalTime)
        legText{end+1} = cases(i).label; %#ok<SAGROW>
    else
        legText{end+1} = sprintf('%s, $T=%.3g$', cases(i).label, finalTime); %#ok<SAGROW>
    end

    fprintf('提取方式：%s\n', info.mode);
    fprintf('theta points for plot = %d, max P = %.6g\n', numel(thetaPlot), max(PPlot));
end

%% ========== 标记 theta_m ==========

if ~isempty(theta_m)
    yl = ylim;

    xline(theta_m, '--', ...
        'Color', [0.5 0.5 0.5], ...
        'LineWidth', 2.2, ...
        'HandleVisibility', 'off');

    text(theta_m + 0.01, yl(1) + 0.96*(yl(2)-yl(1)), ...
        '$\theta_m=0.35$', ...
        'Interpreter', 'latex', ...
        'FontSize', 18, ...
        'Color', [0.2 0.2 0.2], ...
        'HorizontalAlignment', 'left', ...
        'VerticalAlignment', 'top', ...
        'Rotation', 0);
end

xlabel('$\theta$', 'Interpreter', 'latex', 'FontSize', 22);

if normalizeP
    ylabel('normalized $P(\theta)$', 'Interpreter', 'latex', 'FontSize', 22);
else
    ylabel('$P(\theta)$', 'Interpreter', 'latex', 'FontSize', 22);
end

xticks(0:0.2:1);

legend(legHandles, legText, ...
    'Interpreter', 'latex', ...
    'Location', 'northeast', ...
    'FontSize', 22);

set(gca, 'FontSize', 18, 'LineWidth', 1.2);

%% ========== 保存图片 ==========

figdir = fullfile(root, 'figures', 'test2_long_time');
if ~exist(figdir, 'dir')
    mkdir(figdir);
end

figbase = fullfile(figdir, figName);

try
    exportgraphics(gcf, [figbase, '.png'], 'Resolution', 300);
    exportgraphics(gcf, [figbase, '.pdf'], 'ContentType', 'vector');
catch
    print(gcf, [figbase, '.png'], '-dpng', '-r300');
    print(gcf, [figbase, '.eps'], '-depsc');
end

fprintf('\n图片已保存到：\n%s\n', figdir);

%% ========================================================================
%% 局部函数
%% ========================================================================

function [fname, finalTime] = choose_terminal_file(outdir)
% 选择终止时刻文件。
% 优先读取 *_final.mat；如果没有，则读取时间最大的 *_t*.mat。

    fname = '';
    finalTime = NaN;

    finalFiles = dir(fullfile(outdir, '*_final.mat'));

    if ~isempty(finalFiles)
        % 如果有多个 final 文件，选修改时间最新的
        [~, idx] = max([finalFiles.datenum]);
        fname = fullfile(finalFiles(idx).folder, finalFiles(idx).name);
        finalTime = NaN;
        return;
    end

    snapFiles = dir(fullfile(outdir, '*_t*.mat'));

    if isempty(snapFiles)
        return;
    end

    snapTimes = nan(numel(snapFiles), 1);

    for q = 1:numel(snapFiles)
        snapTimes(q) = parse_time_from_name(snapFiles(q).name);
    end

    valid = ~isnan(snapTimes);

    if ~any(valid)
        % 如果文件名无法解析时间，就选修改时间最新的
        [~, idx] = max([snapFiles.datenum]);
        fname = fullfile(snapFiles(idx).folder, snapFiles(idx).name);
        finalTime = NaN;
        return;
    end

    snapFiles = snapFiles(valid);
    snapTimes = snapTimes(valid);

    [finalTime, idx] = max(snapTimes);
    fname = fullfile(snapFiles(idx).folder, snapFiles(idx).name);
end

function t = parse_time_from_name(fname)
% 从文件名中解析时间，例如 *_t20.mat 或 *_t40.001.mat。

    tok = regexp(fname, '_t([0-9]*\.?[0-9]+)\.mat$', 'tokens', 'once');

    if isempty(tok)
        t = NaN;
    else
        t = str2double(tok{1});
    end
end

function [thetaPlot, PPlot, thetaRaw, PRaw, info] = extract_theta_P_correct( ...
    S, fname, epsDefault, normalizeP, refineFactor, wkbReconMethod, fallbackPPostprocess)
% 正确提取 P(theta)。
%
% 优先情况：
%   若存在 W 和 u，则先重构 W,u，再计算 W exp(u/eps)，最后对 x 积分。
%
% 退回情况：
%   若无 W,u，但有 P 或 n，则先得到粗网格 P，再根据 fallbackPPostprocess
%   决定是否只画原始点，或对 P 做插值。

    info = struct();
    info.mode = '';

    theta = find_numeric_field(S, ...
        {'theta', 'theta_grid', 'thetaGrid', 'theta_k', 'thetaVec'});

    x = find_numeric_field(S, ...
        {'x', 'x_grid', 'xGrid', 'x_nodes', 'xx', 'gridx'});

    epsVal = find_scalar_field(S, ...
        {'eps', 'epsilon', 'varepsilon', 'epsVal'});

    if isempty(epsVal)
        epsVal = parse_eps_from_name(fname);
    end

    if isempty(epsVal)
        epsVal = epsDefault;
    end

    % 优先查找 W,u
    W = find_numeric_field(S, {'W', 'w', 'W_wkb', 'amp', 'amplitude', 'A'});
    u = find_numeric_field(S, {'u', 'U', 'u_wkb', 'phase'});

    if ~isempty(W) && ~isempty(u)
        % 正确 WKB 重构
        [thetaPlot, PPlot, thetaRaw, PRaw] = P_from_W_u_reconstruct( ...
            W, u, epsVal, theta, x, refineFactor, wkbReconMethod, normalizeP);

        info.mode = sprintf('W,u -> reconstruct %s -> W exp(u/eps) -> int_x', wkbReconMethod);
        return;
    end

    % 若无 W,u，则尝试读取 P
    P = find_numeric_field(S, ...
        {'P', 'Pk', 'P_k', 'Ptheta', 'P_theta', ...
         'trait_marginal', 'traitMarginal', 'prob_theta'});

    if ~isempty(P)
        P = squeeze(P);
        P = P(:);

        if isempty(theta)
            theta = (0:numel(P)-1)' / numel(P);
        else
            theta = grid_vector(theta);
        end

        [thetaRaw, PRaw, thetaPlot, PPlot] = process_coarse_P( ...
            theta, P, normalizeP, refineFactor, fallbackPPostprocess);

        info.mode = sprintf('saved P -> %s postprocess', fallbackPPostprocess);
        return;
    end

    % 若无 P，则尝试由 n 得到 P
    n = find_numeric_field(S, {'n', 'density', 'rho_jk', 'rhoJK', 'n_jk', 'nJK'});

    if ~isempty(n)
        K_from_name = parse_K_from_name(fname);

        if isempty(theta)
            K = infer_K_from_density(n, K_from_name);
            theta = (0:K-1)' / K;
        else
            theta = grid_vector(theta);
        end

        if isempty(x)
            x = [];
        else
            x = grid_vector(x);
        end

        P = marginal_from_density(n, theta, x);

        [thetaRaw, PRaw, thetaPlot, PPlot] = process_coarse_P( ...
            theta, P, normalizeP, refineFactor, fallbackPPostprocess);

        info.mode = sprintf('n -> int_x -> %s postprocess', fallbackPPostprocess);
        return;
    end

    disp('当前 .mat 文件中的顶层变量为：');
    disp(fieldnames(S));

    error(['无法从文件 %s 中提取 P(theta)。请检查 .mat 文件中是否保存了 W,u,eps，', ...
           '或者 P，或者 n。'], fname);
end

function [thetaFine, PFine, thetaRaw, PRaw] = P_from_W_u_reconstruct( ...
    Wraw, uraw, epsVal, theta, x, refineFactor, method, normalizeP)
% 由 W,u 按正确顺序构造 P(theta)。
%
% 正确顺序：
%   W,u -> theta 细网格重构 -> W exp(u/eps) -> int_x。

    Wraw = double(squeeze(Wraw));
    uraw = double(squeeze(uraw));

    if isempty(theta)
        K_from_W = infer_theta_dim_from_W_u(Wraw, uraw);
        theta = (0:K_from_W-1)' / K_from_W;
    else
        theta = grid_vector(theta);
    end

    K = numel(theta);

    % W 整理为 Nx x K
    W = to_xt_matrix_by_K(Wraw, K, 'W');

    Nx = size(W, 1);

    % x 积分权重
    if isempty(x)
        wx = ones(Nx, 1);
    else
        x = grid_vector(x);
        if numel(x) == Nx
            wx = trapz_weights_from_x(x);
        else
            warning('x 网格长度与 W 的 x 维度不一致，退回到简单求和。');
            wx = ones(Nx, 1);
        end
    end

    % u 整理为 1 x K 或 Nx x K
    u = to_u_array_by_K(uraw, Nx, K, 'u');

    % 原始粗网格上的 P，仅用于检查或画原始点
    if isvector(u)
        Ucoarse = repmat(u(:).', Nx, 1);
    else
        Ucoarse = u;
    end

    argCoarse = Ucoarse / epsVal;
    if normalizeP
        argCoarse = argCoarse - max(argCoarse(:));
    end
    argCoarse = min(max(argCoarse, -745), 700);

    nCoarse = W .* exp(argCoarse);
    PRaw = wx.' * nCoarse;
    PRaw = PRaw(:);
    thetaRaw = theta(:);

    if normalizeP
        PRaw = normalize_periodic_density(thetaRaw, PRaw, 1.0);
    end

    % 细 theta 网格
    Nfine = max(K, K * refineFactor);
    thetaFine = linspace(theta(1), theta(1) + 1, Nfine + 1).';
    thetaFine(end) = [];

    % 重构 W
    Wfine = zeros(Nx, numel(thetaFine));

    for j = 1:Nx
        Wfine(j, :) = periodic_interp(theta, W(j, :), thetaFine, 1.0, method).';
    end

    % 重构 u
    if isvector(u)
        ufine = periodic_interp(theta, u(:), thetaFine, 1.0, method).';
        Ufine = repmat(ufine(:).', Nx, 1);
    else
        Ufine = zeros(Nx, numel(thetaFine));
        for j = 1:Nx
            Ufine(j, :) = periodic_interp(theta, u(j, :), thetaFine, 1.0, method).';
        end
    end

    % 插值可能产生极小负值，密度振幅应非负
    Wfine(Wfine < 0) = 0;

    arg = Ufine / epsVal;
    if normalizeP
        % 归一化比较形状时，可以整体平移，避免上溢
        arg = arg - max(arg(:));
    end
    arg = min(max(arg, -745), 700);

    nFine = Wfine .* exp(arg);

    PFine = wx.' * nFine;
    PFine = PFine(:);

    if normalizeP
        PFine = normalize_periodic_density(thetaFine, PFine, 1.0);
    end
end

function [thetaRaw, PRaw, thetaPlot, PPlot] = process_coarse_P( ...
    theta, P, normalizeP, refineFactor, method)
% 对已有粗网格 P 做可选画图后处理。
% 注意：这只是退回路径，不是首选 WKB 重构路径。

    thetaRaw = theta(:);
    PRaw = real(P(:));

    [thetaRaw, idx] = sort(thetaRaw);
    PRaw = PRaw(idx);

    if normalizeP
        PRaw = normalize_periodic_density(thetaRaw, PRaw, 1.0);
    end

    if strcmpi(method, 'none')
        thetaPlot = thetaRaw;
        PPlot = PRaw;
    else
        Nfine = max(numel(thetaRaw), refineFactor*numel(thetaRaw));
        thetaPlot = linspace(thetaRaw(1), thetaRaw(1) + 1, Nfine + 1).';
        thetaPlot(end) = [];

        PPlot = periodic_interp(thetaRaw, PRaw, thetaPlot, 1.0, method);
        PPlot = real(PPlot(:));
        PPlot(PPlot < 0) = 0;

        if normalizeP
            PPlot = normalize_periodic_density(thetaPlot, PPlot, 1.0);
        end
    end
end

function P = marginal_from_density(n, theta, x)
% 由 n_{j,k} 对 x 方向积分得到 P(theta)。

    n = double(squeeze(n));

    if ndims(n) ~= 2
        error('当前只支持二维密度数组 n_{j,k}。');
    end

    K = numel(theta);

    if size(n, 2) == K
        A = n;
    elseif size(n, 1) == K
        A = n.';
    else
        error('无法判断 n 的哪一维是 theta 方向。');
    end

    Nx = size(A, 1);

    if nargin >= 3 && ~isempty(x)
        x = grid_vector(x);
        if numel(x) == Nx
            wx = trapz_weights_from_x(x);
        else
            wx = ones(Nx, 1);
        end
    else
        wx = ones(Nx, 1);
    end

    P = wx.' * A;
    P = real(P(:));
end

function v = find_numeric_field(S, names)
% 在结构体中递归查找某些变量名，返回第一个数值变量。

    v = find_field_recursive(S, names, 6);

    if ~isempty(v)
        if isnumeric(v) || islogical(v)
            v = double(v);
        else
            v = [];
        end
    end
end

function v = find_scalar_field(S, names)
% 在结构体中递归查找标量变量。

    v = find_numeric_field(S, names);

    if isempty(v) || ~isscalar(v)
        v = [];
    end
end

function v = find_field_recursive(S, names, depth)
% 递归查找字段名，忽略大小写。

    v = [];

    if depth < 0 || ~isstruct(S)
        return;
    end

    f = fieldnames(S);

    % 先查当前层
    for i = 1:numel(f)
        if any(strcmpi(f{i}, names))
            v = S.(f{i});
            return;
        end
    end

    % 再查子结构
    for i = 1:numel(f)
        child = S.(f{i});

        if isstruct(child)
            v = find_field_recursive(child, names, depth - 1);

            if ~isempty(v)
                return;
            end
        end
    end
end

function K = parse_K_from_name(fname)
% 从文件名中解析 K，例如 *_K128_*。

    tok = regexp(fname, 'K(\d+)', 'tokens', 'once');

    if isempty(tok)
        K = [];
    else
        K = str2double(tok{1});
    end
end

function epsVal = parse_eps_from_name(fname)
% 从文件名中解析 eps，例如 baseline_eps0.01_*。

    tok = regexp(fname, 'eps([0-9]*\.?[0-9]+([eE][-+]?\d+)?)', 'tokens', 'once');

    if isempty(tok)
        epsVal = [];
    else
        epsVal = str2double(tok{1});
    end
end

function v = grid_vector(vRaw)
% 把 x/theta 网格整理成列向量。

    vRaw = double(squeeze(vRaw));

    if isvector(vRaw)
        v = vRaw(:);
        return;
    end

    if ndims(vRaw) ~= 2
        error('网格变量不是向量或二维矩阵。');
    end

    col1 = vRaw(:, 1);
    row1 = vRaw(1, :);

    if numel(unique(col1)) > 1
        v = col1(:);
    elseif numel(unique(row1)) > 1
        v = row1(:);
    else
        v = unique(vRaw(:), 'stable');
        v = v(:);
    end
end

function K = infer_theta_dim_from_W_u(W, u)
% 从 W,u 的尺寸猜测 theta 方向维度。

    W = squeeze(W);
    u = squeeze(u);

    if isvector(u)
        K = numel(u);
        return;
    end

    if ndims(W) == 2 && ndims(u) == 2 && isequal(size(W), size(u))
        K = min(size(W));
        return;
    end

    K = min(size(W));
end

function K = infer_K_from_density(n, K_from_name)
% 从 n 的尺寸或文件名中猜测 theta 点数。

    if ~isempty(K_from_name)
        K = K_from_name;
        return;
    end

    n = squeeze(n);

    if ndims(n) ~= 2
        error('无法从非二维 n 中推断 K。');
    end

    K = min(size(n));
end

function A = to_xt_matrix_by_K(Araw, K, varName)
% 将矩阵整理成 Nx x K，其中 K 是 theta 方向点数。

    Araw = double(squeeze(Araw));

    if ndims(Araw) ~= 2
        error('%s 不是二维数组，无法整理成 Nx x K。', varName);
    end

    if size(Araw, 2) == K
        A = Araw;
    elseif size(Araw, 1) == K
        A = Araw.';
    else
        error('%s 的尺寸与 K=%d 不匹配。size = [%s]', ...
            varName, K, num2str(size(Araw)));
    end
end

function u = to_u_array_by_K(uraw, Nx, K, varName)
% 将 u 整理成 1 x K 或 Nx x K。

    uraw = double(squeeze(uraw));

    if isvector(uraw)
        if numel(uraw) ~= K
            error('%s 是向量，但长度不是 K=%d。', varName, K);
        end

        u = uraw(:).';
        return;
    end

    if ndims(uraw) ~= 2
        error('%s 不是向量或二维数组。', varName);
    end

    if isequal(size(uraw), [Nx, K])
        u = uraw;
    elseif isequal(size(uraw), [K, Nx])
        u = uraw.';
    else
        error('%s 尺寸不匹配。size = [%s], 期望 1xK 或 Nx x K。', ...
            varName, num2str(size(uraw)));
    end
end

function wx = trapz_weights_from_x(x)
% 根据 x 网格构造梯形积分权重。

    x = x(:);
    Nx = numel(x);

    if Nx < 2
        wx = ones(Nx, 1);
        return;
    end

    wx = zeros(Nx, 1);

    wx(1) = 0.5 * (x(2) - x(1));
    wx(end) = 0.5 * (x(end) - x(end-1));

    for j = 2:Nx-1
        wx(j) = 0.5 * (x(j+1) - x(j-1));
    end
end

function Pn = normalize_periodic_density(theta, P, period)
% 归一化 P，使 int_0^period P(theta)dtheta = 1。

    if nargin < 3
        period = 1.0;
    end

    theta = theta(:);
    P = real(P(:));

    dtheta = period / numel(theta);
    mass = dtheta * sum(P);

    if mass > 0
        Pn = P / mass;
    else
        Pn = P;
    end
end

function fq = periodic_interp(theta, f, thetaq, period, method)
% 周期插值统一入口。
% method 可选：'spline', 'pchip', 'linear', 'weno'。

    theta = theta(:);
    f = f(:);
    thetaq = thetaq(:);

    if nargin < 5 || isempty(method)
        method = 'spline';
    end

    switch lower(method)
        case 'weno'
            fq = weno5_periodic_interp(theta, f, thetaq, period);

        case {'spline', 'pchip', 'linear'}
            fq = periodic_interp1(theta, f, thetaq, period, lower(method));

        case 'none'
            if numel(theta) ~= numel(thetaq) || max(abs(theta - thetaq)) > 1e-12
                error('method=none 时 thetaq 必须等于 theta。');
            end
            fq = f;

        otherwise
            error('未知插值方法：%s。可选 spline, pchip, linear, weno, none。', method);
    end
end

function fq = periodic_interp1(theta, f, thetaq, period, method)
% 周期 interp1。通过补上周期端点 f(1) 实现。

    theta = theta(:);
    f = f(:);
    thetaq = thetaq(:);

    if numel(theta) > 2 && abs((theta(end)-theta(1)) - period) < 1e-12
        theta = theta(1:end-1);
        f = f(1:end-1);
    end

    thetaExt = [theta; theta(1) + period];
    fExt = [f; f(1)];

    tq = mod(thetaq - theta(1), period) + theta(1);

    fq = interp1(thetaExt, fExt, tq, method);
end

function fq = weno5_periodic_interp(theta, f, thetaq, period)
% 周期 WENO5 函数值插值。
% 注意：K 很小时，WENO 后处理可能不如 spline/pchip 稳定。

    theta = theta(:);
    f = f(:);
    thetaq = thetaq(:);

    if nargin < 4
        period = 1.0;
    end

    N = numel(theta);

    if N < 5
        fq = periodic_interp1(theta, f, thetaq, period, 'pchip');
        return;
    end

    a = theta(1);
    dtheta = period / N;

    fq = zeros(size(thetaq));

    scaleF = max(1, max(abs(f)));
    epsW = 1e-14 * scaleF^2 + 1e-30;

    for iq = 1:numel(thetaq)
        s = mod((thetaq(iq) - a) / dtheta, N);

        q = round(s);
        r = s - q;

        q = mod(q, N);
        i = q + 1;

        fm2 = f(periodic_index(i - 2, N));
        fm1 = f(periodic_index(i - 1, N));
        f0  = f(periodic_index(i,     N));
        fp1 = f(periodic_index(i + 1, N));
        fp2 = f(periodic_index(i + 2, N));

        p0 = lagrange3_eval(r, -2, -1, 0, fm2, fm1, f0);
        p1 = lagrange3_eval(r, -1, 0, 1, fm1, f0, fp1);
        p2 = lagrange3_eval(r, 0, 1, 2, f0, fp1, fp2);

        beta0 = (13/12)*(fm2 - 2*fm1 + f0)^2 + ...
                (1/4)*(fm2 - 4*fm1 + 3*f0)^2;

        beta1 = (13/12)*(fm1 - 2*f0 + fp1)^2 + ...
                (1/4)*(fm1 - fp1)^2;

        beta2 = (13/12)*(f0 - 2*fp1 + fp2)^2 + ...
                (1/4)*(3*f0 - 4*fp1 + fp2)^2;

        d0 = r^2/12 - r/4 + 1/6;
        d1 = 2/3 - r^2/6;
        d2 = r^2/12 + r/4 + 1/6;

        a0 = d0 / (epsW + beta0)^2;
        a1 = d1 / (epsW + beta1)^2;
        a2 = d2 / (epsW + beta2)^2;

        asum = a0 + a1 + a2;

        fq(iq) = (a0*p0 + a1*p1 + a2*p2) / asum;
    end
end

function idx = periodic_index(i, K)
% 将任意整数索引映射到 1,...,K。

    idx = mod(i-1, K) + 1;
end

function y = lagrange3_eval(x, x0, x1, x2, y0, y1, y2)
% 三点 Lagrange 插值。

    L0 = (x - x1)*(x - x2)/((x0 - x1)*(x0 - x2));
    L1 = (x - x0)*(x - x2)/((x1 - x0)*(x1 - x2));
    L2 = (x - x0)*(x - x1)/((x2 - x0)*(x2 - x1));

    y = L0*y0 + L1*y1 + L2*y2;
end
