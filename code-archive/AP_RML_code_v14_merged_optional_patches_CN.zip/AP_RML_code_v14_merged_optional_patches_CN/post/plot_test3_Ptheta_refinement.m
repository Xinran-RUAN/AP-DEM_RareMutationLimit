%% plot_test3_Ptheta_refinement.m
% Test 3: direct trait marginal vs WKB reconstructed trait marginal
%
% 正确的 WKB 重构顺序：
%   1. 在 theta 方向重构 W(x,theta) 和 u(theta)
%   2. 在细 theta 网格上计算 n_WKB = W exp(u/eps)
%   3. 对 x 积分得到 P_WKB(theta) = int n_WKB(x,theta) dx
%
% direct 的公平重构顺序：
%   1. 读取 direct solver 得到的 n(x,theta_k)
%   2. 在 theta 方向重构 n(x,theta)
%   3. 对 x 积分得到 P_dir(theta) = int n_dir(x,theta) dx
%
% WKB 文件名：
%   baseline_..._t5.mat
%
% direct 文件名：
%   baseline_..._direct_t5.mat

clear; clc; close all;
root = fileparts(fileparts(mfilename('fullpath')));
addpath(root);
startup_AP_RML;

%% ========== 用户设置 ==========

epsVal = 1e-4;
Nx = 100;
dt = 1e-4;

K_wkb = 15;
K_direct_list = [15, 20, 30, 60];

targetTimes = [1, 2];

% 是否归一化 P(theta)
normalizeP = false;

% WKB 重构方法：
%   'spline' 更接近旧 PDF 中 cubic spline reconstruction
%   'pchip'  保形插值，不易过冲
%   'weno'   用 WENO5 重构 W,u，不建议在 K 很小时作为最终论文图
wkbReconMethod = 'weno';

% direct density n 的 theta 方向重构方法：
%   'none'   不重构，直接用原始离散点
%   'pchip'  保形插值，推荐用于 direct n
%   'spline' 更光滑，但可能在峰附近过冲
%   'weno'   对 n 做 WENO 后处理，不建议 K 很小时使用
directReconMethod = 'none';

% WKB 和 direct 画图细化倍数。
% K=20 时可以设大一些，例如 100 或 1000。
thetaRefine = 1000;

% 是否叠加 direct 原始离散点
showDirectRawPoints = true;

% 是否保存图片
saveFig = true;

% 手动指定目录
% 默认使用本项目 data 目录，避免旧脚本中的本机绝对路径失效。
dataDir = utils.output_dir('test3_compare_n_homo');
if ~exist(dataDir, 'dir')
    altDir = utils.output_dir('test3_compare_n');
    if exist(altDir, 'dir')
        dataDir = altDir;
    end
end

outDir = fullfile(dataDir, 'figures');
if ~exist(outDir, 'dir')
    mkdir(outDir);
end

%% ========== 画图设置 ==========

fontName = 'Times New Roman';
axisFS = 13;
labelFS = 15;
titleFS = 15;
legendFS = 12;
mainFS = 16;

fig = figure('Color', 'w', ...
    'Units', 'centimeters', ...
    'Position', [3, 3, 22, 8.5]);

tl = tiledlayout(1, 2, ...
    'Padding', 'compact', ...
    'TileSpacing', 'compact');

%% ========== 两个时刻分别画 ==========

for it = 1:numel(targetTimes)

    targetTime = targetTimes(it);

    ax = nexttile;
    hold(ax, 'on');
    box(ax, 'on');

    %% ----- WKB reference：先重构 W,u，再计算 W exp(u/eps) -----

    caseNameWKB = make_case_name(epsVal, Nx, K_wkb, dt);
    [fileWKB, tWKB] = find_snapshot_file(dataDir, caseNameWKB, targetTime, false, true);

    Swkb = load(fileWKB);
    Swkb = select_snapshot_struct(Swkb);

    [thetaWKBPlot, PWKBPlot] = compute_trait_marginal_from_wkb_reconstruct( ...
        Swkb, epsVal, thetaRefine, wkbReconMethod);

    if normalizeP
        PWKBPlot = normalize_periodic_density(thetaWKBPlot, PWKBPlot, 1.0);
    end

    plot(ax, thetaWKBPlot, PWKBPlot, 'k-', ...
        'LineWidth', 2.8, ...
        'DisplayName', sprintf('WKB, $K=%d$', K_wkb));

    %% ----- direct results：先重构 n，再对 x 积分 -----

    markerList = {'o','s','^','d','v','>'};
    lineList = {'--','-.',':','--','-.',':'};

    for ik = 1:numel(K_direct_list)

        Kd = K_direct_list(ik);
        caseNameDIR = make_case_name(epsVal, Nx, Kd, dt);

        [fileDIR, tDIR, foundDIR] = find_snapshot_file(dataDir, caseNameDIR, targetTime, true, false);

        if ~foundDIR
            fprintf('[skip] 没有找到 direct 文件：K=%d, t=%.6g\n', Kd, targetTime);
            continue;
        end

        Sdir = load(fileDIR);
        Sdir = select_snapshot_struct(Sdir);

        [thetaDirPlot, PdirPlot, thetaDirRaw, PdirRaw] = ...
            compute_trait_marginal_from_direct_reconstruct( ...
                Sdir, thetaRefine, directReconMethod);

        if normalizeP
            PdirPlot = normalize_periodic_density(thetaDirPlot, PdirPlot, 1.0);
            PdirRaw  = normalize_periodic_density(thetaDirRaw,  PdirRaw,  1.0);
        end

        mk = markerList{1 + mod(ik-1, numel(markerList))};
        ls = lineList{1 + mod(ik-1, numel(lineList))};

        % 画重构后的 direct P(theta)
        hDir = plot(ax, thetaDirPlot, PdirPlot, ls, ...
            'LineWidth', 2.2, ...
            'DisplayName', sprintf('Direct, $K=%d$', Kd));

        % 叠加 direct 原始离散点，说明 direct 原始网格点的位置
        if showDirectRawPoints
            plot(ax, thetaDirRaw, PdirRaw, mk, ...
                'LineStyle', 'none', ...
                'MarkerSize', 5.5, ...
                'LineWidth', 1.2, ...
                'Color', hDir.Color, ...
                'HandleVisibility', 'off');
        end

        fprintf('t = %.6g, direct K = %d, file time = %.6g\n', ...
            targetTime, Kd, tDIR);
    end

    %% ----- axis style -----

    xlabel(ax, '$\theta$', ...
        'Interpreter', 'latex', ...
        'FontSize', labelFS);

    if normalizeP
        ylabel(ax, 'normalized $P(\theta)$', ...
            'Interpreter', 'latex', ...
            'FontSize', labelFS);
    else
        ylabel(ax, '$P(\theta)$', ...
            'Interpreter', 'latex', ...
            'FontSize', labelFS);
    end

    title(ax, sprintf('$t=%.3g$', targetTime), ...
        'Interpreter', 'latex', ...
        'FontSize', titleFS, ...
        'FontWeight', 'normal');

    xlim(ax, [0, 1]);

    set(ax, ...
        'FontName', fontName, ...
        'FontSize', axisFS, ...
        'LineWidth', 1.0, ...
        'TickLabelInterpreter', 'latex', ...
        'Box', 'on', ...
        'XTick', 0:0.2:1, ...
        'Layer', 'top');

    legend(ax, 'Location', 'best', ...
        'Interpreter', 'latex', ...
        'FontSize', legendFS, ...
        'Box', 'off');

    fprintf('t = %.6g: WKB file time %.6g\n', targetTime, tWKB);
end

sgtitle(tl, sprintf('Trait marginal comparison, $\\varepsilon=%.1e$', epsVal), ...
    'Interpreter', 'latex', ...
    'FontSize', mainFS, ...
    'FontWeight', 'normal');

%% ========== 保存 ==========

if saveFig
    if normalizeP
        baseName = sprintf('test3_Ptheta_reconstruct_%s_directN_%s_normalized_eps%.3g', ...
            wkbReconMethod, directReconMethod, epsVal);
    else
        baseName = sprintf('test3_Ptheta_reconstruct_%s_directN_%s_eps%.3g', ...
            wkbReconMethod, directReconMethod, epsVal);
    end

    outPNG = fullfile(outDir, [baseName '.png']);
    outPDF = fullfile(outDir, [baseName '.pdf']);

    if exist('exportgraphics', 'file')
        exportgraphics(fig, outPNG, 'Resolution', 600);
        exportgraphics(fig, outPDF, 'ContentType', 'vector');
    else
        print(fig, outPNG, '-dpng', '-r600');
        print(fig, outPDF, '-dpdf', '-r600');
    end

    fprintf('PNG 已保存：%s\n', outPNG);
    fprintf('PDF 已保存：%s\n', outPDF);
end

%% ========================================================================
%% 局部函数
%% ========================================================================

function caseName = make_case_name(epsVal, Nx, K, dt)
    epsStr = num2str(epsVal, '%.15g');
    dtStr  = num2str(dt, '%.15g');

    caseName = sprintf('baseline_eps%s_Nx%d_K%d_dt%s_split_direct-log', ...
        epsStr, Nx, K, dtStr);
end

function [fileName, selectedTime, found] = find_snapshot_file(dataDir, caseName, targetTime, isDirectName, mustExist)

    if nargin < 5
        mustExist = true;
    end

    if isDirectName
        pattern = fullfile(dataDir, [caseName '_direct_t*.mat']);
        expr = '_direct_t([0-9eE+\-.]+)\.mat$';
    else
        pattern = fullfile(dataDir, [caseName '_t*.mat']);
        expr = '_t([0-9eE+\-.]+)\.mat$';
    end

    files = dir(pattern);

    if isempty(files)
        if mustExist
            error('没有找到文件：%s', pattern);
        else
            fileName = '';
            selectedTime = NaN;
            found = false;
            return;
        end
    end

    times = NaN(numel(files), 1);

    for i = 1:numel(files)
        token = regexp(files(i).name, expr, 'tokens', 'once');
        if ~isempty(token)
            times(i) = str2double(token{1});
        end
    end

    good = isfinite(times);
    files = files(good);
    times = times(good);

    if isempty(files)
        if mustExist
            error('找到文件，但无法解析时间：%s', pattern);
        else
            fileName = '';
            selectedTime = NaN;
            found = false;
            return;
        end
    end

    [~, id] = min(abs(times - targetTime));

    fileName = fullfile(dataDir, files(id).name);
    selectedTime = times(id);
    found = true;

    fprintf('目标时刻 %.6g，选中文件时刻 %.6g: %s\n', ...
        targetTime, selectedTime, fileName);
end

function [thetaFine, P, thetaRaw, PRaw] = compute_trait_marginal_from_direct_reconstruct(S, thetaRefine, reconMethod)
% 对 direct density n(x,theta) 做公平的 theta 方向重构：
%   1. 读取 direct n(x,theta_k)
%   2. 在 theta 方向把 n 重构到细网格
%   3. 对 x 积分得到 P_dir(theta)
%
% 输出：
%   thetaFine, P   为重构后的细网格 trait marginal
%   thetaRaw, PRaw 为原始网格 trait marginal，用来叠加离散点

    period = 1.0;

    x = get_first_var(S, {'x','op.x','grid.x','xx','xgrid','x_grid'});
    theta = get_first_var(S, {'theta','op.theta','grid.theta','th','theta_grid','thetaGrid'});
    nraw = get_first_var(S, {'n','n_direct','direct.n','one.n','density'});

    x = grid_vector(x);
    theta = grid_vector(theta);

    n = to_xt_matrix(nraw, numel(x), numel(theta), 'n');

    wx = trapz_weights_from_x(x);

    % 原始离散 P，用于画 raw markers
    thetaRaw = theta;
    PRaw = wx.' * n;
    PRaw = PRaw(:);

    % 若不重构，则直接返回原始 P
    if strcmpi(reconMethod, 'none')
        thetaFine = thetaRaw;
        P = PRaw;
        return;
    end

    % 细 theta 网格
    Nfine = max(numel(theta), thetaRefine * numel(theta));
    thetaFine = linspace(theta(1), theta(1) + period, Nfine + 1).';
    thetaFine(end) = [];

    % 先对 n(x,theta) 在 theta 方向重构，再对 x 积分
    nFine = zeros(numel(x), numel(thetaFine));

    for j = 1:numel(x)
        nFine(j, :) = periodic_interp(theta, n(j, :), thetaFine, period, reconMethod).';
    end

    % 插值可能产生极小负值，密度画图时截断
    nFine(nFine < 0) = 0;

    P = wx.' * nFine;
    P = P(:);
end

function [thetaFine, P] = compute_trait_marginal_from_wkb_reconstruct(S, epsVal, thetaRefine, reconMethod)
% 正确的 WKB 计算顺序：
%   W,u 先在 theta 方向重构到细网格
%   n_WKB = W_fine exp(u_fine/eps)
%   P(theta) = int_x n_WKB dx

    period = 1.0;

    x = get_first_var(S, {'x','op.x','grid.x','xx','xgrid','x_grid'});
    theta = get_first_var(S, {'theta','op.theta','grid.theta','th','theta_grid','thetaGrid'});

    x = grid_vector(x);
    theta = grid_vector(theta);

    Wraw = get_first_var(S, {'W','w','W_wkb','wkb.W','one.W','amplitude'}, true, []);
    uraw = get_first_var(S, {'u','U','u_wkb','wkb.u','one.u','phase'}, true, []);

    if isempty(Wraw) || isempty(uraw)
        warning('WKB 文件中没有找到 W,u。退回到 n 或 n_wkb 的粗网格后处理，这不是首选。');

        nWKB = get_first_var(S, {'n_wkb','nWKB','n'}, false, []);
        nWKB = to_xt_matrix(nWKB, numel(x), numel(theta), 'n_wkb');

        wx = trapz_weights_from_x(x);
        Pcoarse = wx.' * nWKB;
        Pcoarse = Pcoarse(:);

        thetaFine = linspace(theta(1), theta(1) + period, thetaRefine*numel(theta) + 1).';
        thetaFine(end) = [];

        P = periodic_interp(theta, Pcoarse, thetaFine, period, reconMethod);
        P = P(:);
        return;
    end

    W = to_xt_matrix(Wraw, numel(x), numel(theta), 'W');
    u = to_u_array(uraw, numel(x), numel(theta), 'u');

    Nfine = max(numel(theta), thetaRefine * numel(theta));
    thetaFine = linspace(theta(1), theta(1) + period, Nfine + 1).';
    thetaFine(end) = [];

    % 重构 W(x,theta)
    Wfine = zeros(numel(x), numel(thetaFine));
    for j = 1:numel(x)
        Wfine(j, :) = periodic_interp(theta, W(j, :), thetaFine, period, reconMethod).';
    end

    % 重构 u(theta) 或 u(x,theta)
    if isvector(u)
        ufine = periodic_interp(theta, u(:), thetaFine, period, reconMethod).';
        Ufine = repmat(ufine(:).', numel(x), 1);
    else
        Ufine = zeros(numel(x), numel(thetaFine));
        for j = 1:numel(x)
            Ufine(j, :) = periodic_interp(theta, u(j, :), thetaFine, period, reconMethod).';
        end
    end

    % spline/pchip/WENO 可能产生极小负值，密度重构时截断
    Wfine(Wfine < 0) = 0;

    arg = Ufine / epsVal;
    arg = min(max(arg, -745), 700);

    nWKBfine = Wfine .* exp(arg);

    wx = trapz_weights_from_x(x);
    P = wx.' * nWKBfine;
    P = P(:);
end

function Pn = normalize_periodic_density(theta, P, period)
    if nargin < 3
        period = 1.0;
    end

    dtheta = period / numel(theta);
    Pn = P / max(dtheta * sum(P), realmin);
end

function fq = periodic_interp(theta, f, thetaq, period, method)
% 周期插值统一入口。
% method 可选：'spline', 'pchip', 'linear', 'weno'

    theta = theta(:);
    f = f(:);
    thetaq = thetaq(:);

    if nargin < 5 || isempty(method)
        method = 'spline';
    end

    switch lower(method)
        case 'weno'
            fq = weno5_periodic_interp(theta, f, thetaq, period);

        case {'spline','pchip','linear'}
            fq = periodic_interp1(theta, f, thetaq, period, lower(method));

        otherwise
            error('未知重构方法：%s。可选 spline, pchip, linear, weno。', method);
    end
end

function fq = periodic_interp1(theta, f, thetaq, period, method)
% 周期 interp1。通过补上周期端点 f(1) 实现。

    theta = theta(:);
    f = f(:);
    thetaq = thetaq(:);

    if numel(theta) > 2 && abs((theta(end) - theta(1)) - period) < 1e-12
        theta = theta(1:end-1);
        f = f(1:end-1);
    end

    thetaExt = [theta; theta(1) + period];
    fExt = [f; f(1)];

    tq = mod(thetaq - theta(1), period) + theta(1);

    fq = interp1(thetaExt, fExt, tq, method);
end

function S = select_snapshot_struct(S0)
    S = S0;

    if isfield(S0, 'one')
        S = S0.one;
        return;
    end

    if isfield(S0, 'direct')
        S = S0.direct;
        return;
    end

    if isfield(S0, 'wkb')
        S = S0.wkb;
        return;
    end

    if isfield(S0, 'snapshots')
        if isempty(S0.snapshots)
            error('snapshots 为空。');
        end
        S = S0.snapshots(end);
        return;
    end
end

function val = get_first_var(S, names, optional, defaultVal)
    if nargin < 3
        optional = false;
    end

    if nargin < 4
        defaultVal = [];
    end

    [found, val] = search_struct_recursive(S, names);

    if ~found
        if optional
            val = defaultVal;
        else
            error('找不到变量。候选名为：%s', strjoin(names, ', '));
        end
    end
end

function [found, val] = search_struct_recursive(S, names)
    found = false;
    val = [];

    if ~isstruct(S)
        return;
    end

    for k = 1:numel(names)
        if isfield(S, names{k})
            found = true;
            val = S.(names{k});
            return;
        end
    end

    fns = fieldnames(S);

    for i = 1:numel(fns)
        obj = S.(fns{i});

        if isstruct(obj)
            [found, val] = search_struct_recursive(obj, names);

            if found
                return;
            end
        end
    end
end

function v = grid_vector(vRaw)
    vRaw = double(squeeze(vRaw));

    if isvector(vRaw)
        v = vRaw(:);
        return;
    end

    col1 = vRaw(:, 1);
    row1 = vRaw(1, :);

    if numel(unique(col1)) > 1
        v = col1(:);
    else
        v = row1(:);
    end
end

function A = to_xt_matrix(Araw, Nx, Ntheta, varName)
    Araw = double(squeeze(Araw));

    if isvector(Araw)
        if numel(Araw) ~= Nx * Ntheta
            error('%s 长度不是 Nx*Ntheta。', varName);
        end

        A = reshape(Araw, Nx, Ntheta);
        return;
    end

    if isequal(size(Araw), [Nx, Ntheta])
        A = Araw;
    elseif isequal(size(Araw), [Ntheta, Nx])
        A = Araw.';
    else
        error('%s 尺寸不匹配。size = [%s], 期望 %d x %d。', ...
            varName, num2str(size(Araw)), Nx, Ntheta);
    end
end

function u = to_u_array(uraw, Nx, Ntheta, varName)
    uraw = double(squeeze(uraw));

    if isvector(uraw)
        if numel(uraw) ~= Ntheta
            error('%s 长度不是 Ntheta。', varName);
        end

        u = uraw(:).';
        return;
    end

    if isequal(size(uraw), [Nx, Ntheta])
        u = uraw;
    elseif isequal(size(uraw), [Ntheta, Nx])
        u = uraw.';
    else
        error('%s 尺寸不匹配。', varName);
    end
end

function wx = trapz_weights_from_x(x)
    x = x(:);
    Nx = numel(x);

    wx = zeros(Nx, 1);

    wx(1) = 0.5 * (x(2) - x(1));
    wx(end) = 0.5 * (x(end) - x(end-1));

    for j = 2:Nx-1
        wx(j) = 0.5 * (x(j+1) - x(j-1));
    end
end

function fq = weno5_periodic_interp(theta, f, thetaq, period)
    theta = theta(:);
    f = f(:);
    thetaq = thetaq(:);

    if nargin < 4
        period = 1.0;
    end

    N = numel(theta);

    if N < 5
        thetaExt = [theta; theta(1) + period];
        fExt = [f; f(1)];

        tq = mod(thetaq - theta(1), period) + theta(1);
        fq = interp1(thetaExt, fExt, tq, 'pchip');
        return;
    end

    a = theta(1);
    dtheta = period / N;
    fq = zeros(size(thetaq));

    scaleF = max(1, max(abs(f)));
    epsW = 1e-14 * scaleF^2 + 1e-30;

    for iq = 1:numel(thetaq)
        s = mod((thetaq(iq) - a) / dtheta, N);

        q = round(s);
        r = s - q;

        q = mod(q, N);
        i = q + 1;

        fm2 = f(wrap_index(i - 2, N));
        fm1 = f(wrap_index(i - 1, N));
        f0  = f(wrap_index(i,     N));
        fp1 = f(wrap_index(i + 1, N));
        fp2 = f(wrap_index(i + 2, N));

        p0 = lagrange3_eval(r, -2, -1, 0, fm2, fm1, f0);
        p1 = lagrange3_eval(r, -1, 0, 1, fm1, f0, fp1);
        p2 = lagrange3_eval(r, 0, 1, 2, f0, fp1, fp2);

        beta0 = (13/12)*(fm2 - 2*fm1 + f0)^2 + ...
                (1/4)*(fm2 - 4*fm1 + 3*f0)^2;

        beta1 = (13/12)*(fm1 - 2*f0 + fp1)^2 + ...
                (1/4)*(fm1 - fp1)^2;

        beta2 = (13/12)*(f0 - 2*fp1 + fp2)^2 + ...
                (1/4)*(3*f0 - 4*fp1 + fp2)^2;

        d0 = r^2/12 - r/4 + 1/6;
        d1 = 2/3 - r^2/6;
        d2 = r^2/12 + r/4 + 1/6;

        a0 = d0 / (epsW + beta0)^2;
        a1 = d1 / (epsW + beta1)^2;
        a2 = d2 / (epsW + beta2)^2;

        asum = a0 + a1 + a2;

        fq(iq) = (a0*p0 + a1*p1 + a2*p2) / asum;
    end
end

function id = wrap_index(id, N)
    id = mod(id - 1, N) + 1;
end

function y = lagrange3_eval(x, x0, x1, x2, y0, y1, y2)
    L0 = (x - x1)*(x - x2)/((x0 - x1)*(x0 - x2));
    L1 = (x - x0)*(x - x2)/((x1 - x0)*(x1 - x2));
    L2 = (x - x0)*(x - x1)/((x2 - x0)*(x2 - x1));

    y = L0*y0 + L1*y1 + L2*y2;
end