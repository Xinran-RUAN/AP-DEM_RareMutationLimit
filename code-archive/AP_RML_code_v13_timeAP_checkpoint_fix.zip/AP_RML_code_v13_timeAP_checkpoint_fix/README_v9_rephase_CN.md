# v9 说明：WKB 框架内的 theta 方向再分解

本版仍然以 WKB 变量 `W` 和 `u` 为主未知量，不回到直接求解原始密度方程。

v8 在 `eps=1e-6` 时失败的直接原因是 `qW` 的 log 跨度不断变大。即使把时间步缩小到很小，`seedLogRange` 仍接近或超过阈值，说明问题已经不是单纯时间步长，而是振幅 `W` 在 theta 方向积累了指数尺度。

v9 增加函数：

```matlab
src.rebalance_wkb_theta_gauge_1d
```

它利用 WKB 分解的非唯一性：对任意只依赖 theta 的函数 `a(theta)`，变换

```matlab
u_new(theta)   = u(theta) + eps*a(theta) - C,
W_new(x,theta) = W(x,theta)*exp(-a(theta) + C/eps)
```

可以严格保持

```matlab
W_new.*exp(u_new/eps) = W.*exp(u/eps)
```

因此这不是解 `n` 的方程，而是在 WKB 框架内重新分配 phase 和 amplitude。默认取 `a(theta)` 为 `log(W)` 在 x 方向的 median，并做一次很弱的周期平滑。

推荐小 epsilon 设置：

```matlab
par.amplitudeVariant = 'wkb-if-split';
par.reactionDiscretization = 'logistic-exact';
par.rhoReconstruction = 'laplace-hybrid';
par.residualMode = 'wkb-steady';
par.thetaRephase = true;
par.thetaRephaseStatistic = 'median';
par.thetaRephaseSmoothPasses = 1;
par.adaptiveTimeStep = true;
par.adaptiveStrategy = 'phase-cfl';
par.adaptiveIfLogRange = true;
```

运行后重点查看输出中的：

- `seedRange`，表示 `qW` 的 log 跨度；
- `logWrange`，表示再分解后 `W` 的 log 范围；
- `rephaseA`，表示吸收到相位中的 theta 修正幅度；
- `peakGrid`，若小于 1，说明密度峰形小于一个 theta 网格，此时应主要看 WKB phase 的峰值位置。
