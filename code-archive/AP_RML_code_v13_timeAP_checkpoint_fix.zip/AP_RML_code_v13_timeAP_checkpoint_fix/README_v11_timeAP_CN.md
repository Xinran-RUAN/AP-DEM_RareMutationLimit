# v11 时间 AP 实验版说明

本版本在原 WKB 求解器基础上加入两个新的**时间积分器实验选项**，用于测试小 \(\varepsilon\) 下 `dt >> eps` 时的失稳是否主要来自时间方向的奇异松弛和 `H(rho(t))` 的冻结误差。

重要说明：本版本仍然在 WKB 框架内推进 `W` 和 `u`。程序中的 `rho` 只是由 `W,u` 重构后用于计算非局部项、有效 Hamiltonian 和诊断量；主方程没有改成直接求解原始密度 `n`。

## 1. 新增时间积分器选项

在 `run/run_main_1d.m` 或任意测试脚本中设置：

```matlab
par.timeIntegrator = 'frozen';            % 原来的 H^n 冻结时间推进
par.timeIntegrator = 'implicit-coupled';  % 方案 1：全隐式耦合 Picard
par.timeIntegrator = 'projective';        % 方案 3：projective / micro-macro
```

当 `timeIntegrator='frozen'` 时，程序走原来的 `src.run_wkb_1d` 主循环。

当 `timeIntegrator='implicit-coupled'` 或 `'projective'` 时，`src.run_wkb_1d` 会自动转入新增的

```matlab
src.run_wkb_timeap_1d
```

该函数实现两个实验版时间积分器。

## 2. 方案 1：全隐式耦合 Picard

设置：

```matlab
par.timeIntegrator = 'implicit-coupled';
par.implicitMaxIter = 12;
par.implicitTol = 1e-7;
par.implicitRelax = 0.6;
par.implicitFailureTol = 5e-2;
```

算法思想：在一个时间步内求近似固定点

```text
rho* = Reconstruction[W*,u*]
H*   = H(rho*)
(W*,u*) = Step(W^n,u^n; rho*,H*)
```

也就是说，相位方程和振幅方程中使用的 `H` 不再固定为旧时间层 `H^n`，而是通过 Picard 迭代趋向当前时间层 `H^{n+1}`。

这可以用来检验：小 \(\varepsilon\) 下的误差是否主要由

```text
int_{t_n}^{t_{n+1}} H(rho(t)) dt ≈ dt*H(rho^n)
```

这个冻结近似导致。

诊断量保存在 `wkb.history` 中：

```matlab
wkb.history.implicitIter
wkb.history.implicitRelChange
wkb.history.implicitConverged
```

进度输出中也会显示：

```text
impIt=... impRel=...
```

## 3. 方案 3：projective / micro-macro

设置：

```matlab
par.timeIntegrator = 'projective';
par.projectiveMicroSteps = 8;
par.projectiveMicroDtFactor = 0.25;
par.projectiveMode = 'u-only';
par.projectiveCorrectorSteps = 0;
```

算法思想：每个宏步 `dt` 内先做若干个小步

```text
dt_micro ≈ projectiveMicroDtFactor * eps / scale
```

用这些小步解析 \(O(\varepsilon)\) 的快松弛层，然后用最后两个 micro states 估计慢变量导数并外推。

默认 `projectiveMode='u-only'`：

- 只外推相位 `u` 的形状；
- `W` 保留在 micro-relaxed 状态；
- 这样比外推 `log(W)` 更稳健，因为小 \(\varepsilon\) 下 `W` 容易携带指数跨度。

若想测试更激进的版本，可以设：

```matlab
par.projectiveMode = 'u-logw';
```

这会同时外推 `log(W)`，但更容易出现指数病态，因此不是默认。

诊断量保存在：

```matlab
wkb.history.projectiveMicroStepsUsed
wkb.history.projectiveMicroDt
wkb.history.projectiveRemainingDt
wkb.history.projectiveModeCode
```

进度输出中也会显示：

```text
microN=... microDt=...
```

## 4. 主要新增文件

```matlab
+src/run_wkb_timeap_1d.m
+src/wkb_one_step_frozenH_1d.m
```

其中：

- `run_wkb_timeap_1d.m` 是实验版主循环；
- `wkb_one_step_frozenH_1d.m` 是公共的一步 WKB 算子，在给定 `rho,H` 的情况下推进 `W,u`，供全隐式 Picard 和 projective micro steps 调用。

## 5. 建议测试顺序

先测试中等小的 epsilon：

```matlab
par.eps = 1e-4;
par.dt = 1e-3;
par.timeIntegrator = 'implicit-coupled';
```

然后测试：

```matlab
par.timeIntegrator = 'projective';
```

最后再尝试：

```matlab
par.eps = 1e-6;
par.dt = 1e-3;
```

对 `eps=1e-6`，若 `Ntheta=64`，密度峰宽通常远小于 trait 网格，因此更应该关注

```matlab
theta_wkb
res_phase_steady
res_amplitude_steady
phaseCFL
peakWidthOverGrid
```

而不是 raw trait marginal 的峰形是否漂亮。

## 6. 重要限制

本版本是为了测试思路而实现的实验代码，并不等于已经证明了时间 AP。尤其是：

- `implicit-coupled` 是 Picard 迭代，不是完整 Newton；
- `projective` 的慢变量选择仍需数值验证；
- 若 `H(rho)` 在一个宏步内变化非常剧烈，仍可能需要缩小宏步；
- 如果 `peakWidthOverGrid < 1`，说明重构密度峰形已经低于 trait 网格解析能力。

这两个新方案的目的，是帮助判断未来真正 time-AP WKB 方法应如何设计，而不是替代正文中的 stationary fixed-grid AP 分析。
