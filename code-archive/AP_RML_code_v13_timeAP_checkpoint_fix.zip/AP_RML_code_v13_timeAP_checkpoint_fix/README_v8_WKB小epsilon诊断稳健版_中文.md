# AP_RML_code v8：WKB 小 epsilon 诊断稳健版

本版仍然坚持 WKB 框架：主求解变量是 `W` 和 `u`，没有把主程序改回直接求解原始密度方程。代码中出现的 `n=W.*exp(u/eps)` 只用于重构、诊断和作图。

## 为什么 v7 仍会在 eps=1e-6 爆掉？

根据运行日志，爆炸不是 WENO 插值缺失造成的。WENO 主要影响相位方程中一阶导数的高阶近似；真正导致爆炸的是小 `eps` 下的数值表示问题：

1. `u` 的常数 gauge 会漂移。如果 `u` 的亚网格峰值 `u_*` 变成正数，那么 Laplace 重构中的 `exp(u_*/eps)` 会迅速上溢。
2. WKB-IF 中的 `qW` 右端如果只看 `q` 的相对跨度还不够，还要看 `log(qW)` 的绝对大小和跨度。
3. 当 `dt/eps` 很大时，一步试探更新可能把 `rho` 或 `W` 推到双精度无法可靠表示的范围。此时不能继续推进，也不能把 residual 误判为 0，必须拒绝本步并缩小时间步重试。
4. `Ntheta=64, eps=1e-6` 时，密度峰宽远小于一个 trait 网格，所以 `thetaDIR` 和直接节点求和的密度峰形不可靠；WKB 方法应主要看相位峰位置，并使用 Laplace/亚网格重构来估计 `rho`。

## 主要修改

### 1. phase-peak gauge

新增 `src.phase_peak_info_1d`，用周期三点二次插值估计相位峰值。`wkb-if-split` 每步默认使用

```matlab
par.ifGaugeStrategy = 'phase-peak';
```

即把二次插值峰值规范为 0，而不是让 `u` 的常数项漂移。这能直接避免 `exp(u_*/eps)` 的上溢。

### 2. log-domain Laplace reconstruction

`src.reconstruct_laplace_1d` 改为在 log 变量中计算

```matlab
log rho = log Wstar + Ustar/eps + 0.5*log(2*pi*eps/abs(u_theta_theta_star))
```

并记录 `logrhoMax`、`numCappedHigh` 等诊断量。

### 3. qW 病态监测和拒步重试

`update_w_wkb_if_split_fd_1d` 现在记录

```matlab
seedLogMax
seedLogMin
seedLogRange
qLogAbsMax
reactionScaleMax
reactionScaleMin
```

若 `log(qW)` 尺度过大，会设置 `info.needsRetry=true`。`run_wkb_1d` 捕捉到该标志后会丢弃试探步，缩小 `dt` 后从原状态重试。

推荐参数：

```matlab
par.enableStepRetry = true;
par.maxStepRetries = 12;
par.retryDtFactor = 0.5;
par.ifSeedLogAbsMax = 120;
par.ifSeedLogRangeMax = 160;
```

### 4. 更详细中文诊断

运行结束后可执行：

```matlab
src.diagnose_wkb_history_1d(wkb.history, true)
```

它会指出 residual 主要来自相位方程、振幅方程、qW 指数尺度、rho 重构，还是 trait 网格对密度峰形欠解析。

## 推荐测试设置

```matlab
par.eps = 1e-6;
par.dt = 1e-3;              % 最大试探时间步，实际步长可能由拒步重试自动减小
par.Nx = 50;
par.Ntheta = 64;

par.amplitudeVariant = 'wkb-if-split';
par.ifMode = 'h-only';
par.ifGaugeStrategy = 'phase-peak';
par.reactionDiscretization = 'logistic-exact';
par.rhoReconstruction = 'laplace-hybrid';
par.residualMode = 'wkb-steady';

par.adaptiveTimeStep = true;
par.adaptiveStrategy = 'phase-cfl';
par.adaptiveIfLogRange = true;
par.enableStepRetry = true;
```

如果 `numRetries` 经常很大，说明给定的 `dt` 作为试探步太大；程序会尽量自动缩步，但正式计算建议根据诊断结果选择更合适的 `dt` 或更高的 `Ntheta`。
