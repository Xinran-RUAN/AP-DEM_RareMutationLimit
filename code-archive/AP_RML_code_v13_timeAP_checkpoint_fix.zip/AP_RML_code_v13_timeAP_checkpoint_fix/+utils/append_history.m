function history = append_history(history, t, residual, diag, resInfo, dtInfo)
%APPEND_HISTORY 将标量诊断量加入 history。
%   本版本通过 diag 统一接收小 epsilon 监测量，例如 qLogAbsMax、phaseCFL、
%   neighborJumpOverEps、矩阵 rcond 估计以及 WKB 稳态 residual 分量。

if nargin < 5 || isempty(resInfo), resInfo = struct(); end
if nargin < 6 || isempty(dtInfo), dtInfo = struct(); end
if isempty(history)
    history.t = [];
    history.dt = [];
    history.residual = [];
    history.residual_u = [];
    history.residual_n = [];
    history.residual_n_scaled = [];
    history.residual_W_legacy = [];
    history.res_phase_steady = [];
    history.res_amplitude_steady = [];
    history.res_density_steady = [];
    history.res_wkb_steady = [];
    history.lambdaR = [];
    history.lambdaH = [];
    history.rplusMax = [];
    history.HabsMax = [];
    history.phaseCFL = [];
    history.phaseSpeedMax = [];
    history.neighborJumpOverEps = [];
    history.peakWidthOverGrid = [];
    history.qLogAbsMax = [];
    history.qLogMin = [];
    history.qLogMax = [];
    history.qClipCount = [];
    history.qClipFraction = [];
    history.matrixRcondEst = [];
    history.matrixCondEst = [];
    history.logWRange = [];
    history.W_max = [];
    history.theta_wkb = [];
    history.theta_direct = [];
    history.err_wkb_to_m = [];
    history.err_direct_to_m = [];
    history.sigma_theta = [];
    history.Hmin = [];
    history.H_at_wkb = [];
    history.gammaR = [];
    history.rho_max = [];
    history.W_min = [];
    history.numRetries = [];
    history.seedLogMax = [];
    history.seedLogMin = [];
    history.seedLogRange = [];
    history.reactionScaleMax = [];
    history.reactionScaleMin = [];
    history.uPeakStar = [];
    history.uPeakInterpolationCorrection = [];
    history.rhoReconstructLogMax = [];
    history.rhoReconstructNumCappedHigh = [];
    history.implicitIter = [];
    history.implicitRelChange = [];
    history.implicitConverged = [];
    history.projectiveMicroStepsUsed = [];
    history.projectiveMicroDt = [];
    history.projectiveRemainingDt = [];
    history.projectiveModeCode = [];
end

history.t(end+1,1) = t;
history.residual(end+1,1) = residual;
history.dt(end+1,1) = get_field(dtInfo, 'dt', NaN);
history.residual_u(end+1,1) = get_field(resInfo, 'res_u', NaN);
history.residual_n(end+1,1) = get_field(resInfo, 'res_n', NaN);
history.residual_n_scaled(end+1,1) = get_field(resInfo, 'res_n_scaled', NaN);
history.residual_W_legacy(end+1,1) = get_field(resInfo, 'res_W_legacy', NaN);
history.res_phase_steady(end+1,1) = get_field(diag, 'res_phase_steady', NaN);
history.res_amplitude_steady(end+1,1) = get_field(diag, 'res_amplitude_steady', get_field(diag,'res_amp_w_steady',NaN));
history.res_density_steady(end+1,1) = get_field(diag, 'res_density_steady', NaN);
history.res_wkb_steady(end+1,1) = get_field(diag, 'res_wkb_steady', NaN);
history.lambdaR(end+1,1) = get_field(dtInfo, 'lambdaR', NaN);
history.lambdaH(end+1,1) = get_field(dtInfo, 'lambdaH', NaN);
history.rplusMax(end+1,1) = get_field(dtInfo, 'rplusMax', NaN);
history.HabsMax(end+1,1) = get_field(dtInfo, 'HabsMax', NaN);
history.phaseCFL(end+1,1) = get_field(diag, 'phaseCFL', get_field(dtInfo, 'phaseCFL', NaN));
history.phaseSpeedMax(end+1,1) = get_field(dtInfo, 'phaseSpeedMax', NaN);
history.neighborJumpOverEps(end+1,1) = get_field(diag, 'neighborJumpOverEps', get_field(dtInfo, 'neighborJumpOverEps', NaN));
history.peakWidthOverGrid(end+1,1) = get_field(diag, 'peakWidthOverGrid', get_field(dtInfo, 'peakWidthOverGrid', NaN));
history.qLogAbsMax(end+1,1) = get_field(diag, 'qLogAbsMax', NaN);
history.qLogMin(end+1,1) = get_field(diag, 'qLogMin', get_field(diag,'logQMin',NaN));
history.qLogMax(end+1,1) = get_field(diag, 'qLogMax', get_field(diag,'logQMax',NaN));
history.qClipCount(end+1,1) = get_field(diag, 'qClipCount', NaN);
history.qClipFraction(end+1,1) = get_field(diag, 'qClipFraction', NaN);
history.matrixRcondEst(end+1,1) = get_field(diag, 'matrixRcondEst', NaN);
history.matrixCondEst(end+1,1) = get_field(diag, 'matrixCondEst', NaN);
history.logWRange(end+1,1) = get_field(diag, 'logWRange', NaN);
history.W_max(end+1,1) = get_field(diag, 'W_max', get_field(diag,'WmaxAfter',NaN));
history.theta_wkb(end+1,1) = get_field(diag, 'theta_wkb', NaN);
history.theta_direct(end+1,1) = get_field(diag, 'theta_direct', NaN);
history.err_wkb_to_m(end+1,1) = get_field(diag, 'err_wkb_to_m', NaN);
history.err_direct_to_m(end+1,1) = get_field(diag, 'err_direct_to_m', NaN);
history.sigma_theta(end+1,1) = get_field(diag, 'sigma_theta', NaN);
history.Hmin(end+1,1) = get_field(diag, 'Hmin', NaN);
history.H_at_wkb(end+1,1) = get_field(diag, 'H_at_wkb', NaN);
history.gammaR(end+1,1) = get_field(diag, 'gammaR', NaN);
history.rho_max(end+1,1) = get_field(diag, 'rho_max', NaN);
history.W_min(end+1,1) = get_field(diag, 'W_min', NaN);
history.numRetries(end+1,1) = get_field(diag, 'numRetries', get_field(dtInfo,'numRetries',NaN));
history.seedLogMax(end+1,1) = get_field(diag, 'seedLogMax', NaN);
history.seedLogMin(end+1,1) = get_field(diag, 'seedLogMin', NaN);
history.seedLogRange(end+1,1) = get_field(diag, 'seedLogRange', NaN);
history.reactionScaleMax(end+1,1) = get_field(diag, 'reactionScaleMax', NaN);
history.reactionScaleMin(end+1,1) = get_field(diag, 'reactionScaleMin', NaN);
history.uPeakStar(end+1,1) = get_field(diag, 'uPeakStar', NaN);
history.uPeakInterpolationCorrection(end+1,1) = get_field(diag, 'uPeakInterpolationCorrection', NaN);
history.rhoReconstructLogMax(end+1,1) = get_field(diag, 'rhoReconstructLogMax', get_field(dtInfo,'rhoReconstructLogMaxOld',NaN));
history.rhoReconstructNumCappedHigh(end+1,1) = get_field(diag, 'rhoReconstructNumCappedHigh', NaN);
history.implicitIter(end+1,1) = get_field(diag, 'implicitIter', NaN);
history.implicitRelChange(end+1,1) = get_field(diag, 'implicitRelChange', NaN);
history.implicitConverged(end+1,1) = get_field(diag, 'implicitConverged', NaN);
history.projectiveMicroStepsUsed(end+1,1) = get_field(diag, 'projectiveMicroStepsUsed', NaN);
history.projectiveMicroDt(end+1,1) = get_field(diag, 'projectiveMicroDt', NaN);
history.projectiveRemainingDt(end+1,1) = get_field(diag, 'projectiveRemainingDt', NaN);
history.projectiveModeCode(end+1,1) = get_field(diag, 'projectiveModeCode', NaN);
end

function val = get_field(s, name, defaultValue)
val = defaultValue;
if isstruct(s) && isfield(s, name) && ~isempty(s.(name)) && isnumeric(s.(name)) && isscalar(s.(name))
    val = double(s.(name));
end
end
