function save_snapshot(outdir, tag, t, vars)
%SAVE_SNAPSHOT Save a solver snapshot struct.
outdir = utils.ensure_dir(outdir);
filename = fullfile(outdir, sprintf('%s_t%.6g.mat', tag, t));
save(filename, '-struct', 'vars');
end
