root = fileparts(fileparts(mfilename('fullpath')));
addpath(root);
startup_AP_RML;
outdir = utils.output_dir('test1_assumptions');
S = load(fullfile(outdir,'summary.mat'));
disp(S.T);
