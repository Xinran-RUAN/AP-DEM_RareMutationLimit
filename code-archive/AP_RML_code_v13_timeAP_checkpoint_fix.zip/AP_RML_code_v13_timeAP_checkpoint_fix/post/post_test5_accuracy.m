root = fileparts(fileparts(mfilename('fullpath')));
addpath(root);
startup_AP_RML;
outdir = utils.output_dir('test5_accuracy');
S = load(fullfile(outdir,'summary_accuracy.mat'));
disp(S.T);
figure; loglog(S.T.K, S.T.theta_error_to_ref, 'o-'); xlabel('K'); ylabel('trait error to reference');
