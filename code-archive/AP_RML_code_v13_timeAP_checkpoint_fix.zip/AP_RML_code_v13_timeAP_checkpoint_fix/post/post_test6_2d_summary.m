root = fileparts(fileparts(mfilename('fullpath')));
addpath(root);
startup_AP_RML(true);
summaryFile = fullfile(utils.output_dir('test6_2d'),'summary_2d.mat');
if exist(summaryFile,'file') ~= 2
    error('2D summary not found. Run run/run_test6_2d_legacy.m first.');
end
S = load(summaryFile);
disp(S.result2d.diagnostics);
