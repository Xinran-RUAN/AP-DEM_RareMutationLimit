root = fileparts(fileparts(mfilename('fullpath')));
addpath(root);
startup_AP_RML;
outdir = utils.output_dir('test4_coarse_AP');
S = load(fullfile(outdir,'summary.mat'));
disp(S.T);
figure; plot(S.T.K, S.T.err_wkb_to_m, 'o-', S.T.K, S.T.err_direct_to_m, 's--'); xlabel('K'); ylabel('trait error'); legend('WKB','direct');
