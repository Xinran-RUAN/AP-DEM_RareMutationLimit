function plot_trait_profiles(resultFile)
%PLOT_TRAIT_PROFILES Plot trait marginal P_k and phase u_k from a saved WKB result.
if nargin < 1
    [f,p] = uigetfile('*.mat');
    resultFile = fullfile(p,f);
end
S = load(resultFile);
if ~isfield(S,'n') || ~isfield(S,'u') || ~isfield(S,'grid')
    error('File must contain n, u, and grid.');
end
op = src.build_operators_1d(S.grid);
wx = utils.trapz_weights(op.nx, op.dx);
P = wx.' * S.n;
figure; plot(S.grid.theta, P, 'o-'); xlabel('\theta'); ylabel('P_k'); title('Trait marginal');
figure; plot(S.grid.theta, S.u, 'o-'); xlabel('\theta'); ylabel('u_k'); title('WKB phase');
end
