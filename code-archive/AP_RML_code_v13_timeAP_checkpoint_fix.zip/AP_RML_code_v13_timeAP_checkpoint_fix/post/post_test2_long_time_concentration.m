root = fileparts(fileparts(mfilename('fullpath')));
addpath(root);
startup_AP_RML;
outdir = utils.output_dir('test2_long_time');
files = dir(fullfile(outdir,'*_final.mat'));
if isempty(files), error('No final file found.'); end
S = load(fullfile(files(end).folder, files(end).name));
figure; plot(S.history.t, S.history.sigma_theta, 'o-'); xlabel('t'); ylabel('\sigma_\theta'); title('Concentration width');
figure; plot(S.history.t, S.history.err_wkb_to_m, 'o-'); xlabel('t'); ylabel('d_T(\theta_{WKB},\theta_m)'); title('Selected trait error');
