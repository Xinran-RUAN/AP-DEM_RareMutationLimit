# v7 WKB 小 epsilon 稳健版说明

这版仍然在 WKB 框架下推进未知量 `W` 和 `u`，没有把主求解器改成原始密度方程。针对 `eps=1e-6`、`dt=1e-3` 这类测试中出现的爆炸，主要修正了三个来源。

## 1. `direct-log` 在小 epsilon 粗 trait 网格下会误算 rho

当 `eps` 很小而 `Ntheta` 不够大时，`n=W*exp(u/eps)` 的峰宽可能远小于一个 trait 网格。此时用节点求和 `direct-log` 计算 `rho` 会严重依赖峰值是否落在网格点上，可能导致 `rho` 一会儿极大、一会儿接近 0，进而触发竞争项的巨大振荡。

新版默认使用

```matlab
par.rhoReconstruction = 'laplace-hybrid';
```

并且当 `eps <= 1e-4` 而用户仍设置 `direct-log` 时，`run_wkb_1d` 会自动切换到 `laplace-hybrid`。这是 WKB 相位曲率重构，不是求解 `n` 方程。

## 2. 旧 Patankar 正生产会导致 rho 一步放大 O(dt/eps)

旧写法中，若 `K-rho>0`，Patankar 右端含有

```matlab
eps + dt*(K-rho)_+
```

因此当 `dt/eps` 很大时，即使初始 `rho=O(1)`，也可能一步放大到 `O(dt/eps)`。这正是之前 `rhoMax` 从 O(1) 变成几百甚至随后爆炸的主要原因。

新版在 `wkb-if-split` 中默认使用

```matlab
par.reactionDiscretization = 'logistic-exact';
```

即对每个空间点的竞争反应

```text
eps*rho_t = (K-rho)*rho
```

使用精确 logistic 缩放，并把相同缩放乘到该 `x` 点所有 `theta` 的 `W` 上。这仍然是在更新 WKB 振幅 `W`，不是求解原始密度 PDE。

## 3. full IF 会把 |u_theta|^2/eps 放入指数

旧的 full integrating factor 使用

```matlab
q_k = exp((u_k^n-u_k^{n+1})/eps)
```

其中包含 Hamilton-Jacobi 梯度项。小 epsilon 下这会产生 `exp(|u_theta|^2*dt/eps)` 型放大。新版默认只对人工拆分中的 `H` 项做积分因子：

```matlab
par.ifMode = 'h-only';
```

即只使用

```matlab
q_k = exp(dt*H_k/eps)
```

用来抵消相位方程中的 `-H` 与振幅方程中的 `+H`。其余 HJ 梯度项仍由 WKB 振幅方程的 upwind 运输和曲率项处理。

## 4. 自适应时间步新增 IF 指数跨度限制

即使只对 `H` 作 IF，`max(H)-min(H)` 在 theta 方向的差异也会使 `W` 出现指数跨度。新版加入

```matlab
par.adaptiveIfLogRange = true;
par.ifLogRangeMax = 80;
```

限制

```text
(dt/eps)*(max(H)-min(H)) <= ifLogRangeMax.
```

这不是回到 `dt=O(eps)` 的旧源项限制，而是防止 WKB 振幅变量在双精度中出现不可表示的指数分离。若关闭该限制，`dt=1e-3, eps=1e-6` 仍可能因为 W 变量本身的指数跨度过大而不可靠。

## 5. 推荐测试参数

```matlab
par.eps = 1e-6;
par.dt = 1e-3;              % 最大时间步，实际步长可能由 IF log range 自动缩小
par.amplitudeVariant = 'wkb-if-split';
par.reactionDiscretization = 'logistic-exact';
par.rhoReconstruction = 'laplace-hybrid';
par.ifMode = 'h-only';
par.residualMode = 'wkb-steady';
par.adaptiveTimeStep = true;
par.adaptiveStrategy = 'phase-cfl';
par.adaptiveIfLogRange = true;
par.ifLogRangeMax = 80;
```

运行输出中新增 `ifLogR`，表示本步 IF 指数的 theta 相对跨度。若它长期接近 `80`，说明实际时间步是由 WKB 振幅可表示性限制的。

## 6. 失败保护

新版不会再把 NaN、Inf 或数值爆炸误判成 `res=0`。若检测到 `W/u/residual` 非有限或超过阈值，程序会给出中文警告并提前停止。
