function root = startup()
%STARTUP Add project root and run/post folders to path for scripts in run/.
root = fileparts(fileparts(mfilename('fullpath')));
addpath(root);
startup_AP_RML;
end
