% RUN_TEST1_ASSUMPTION_DIAGNOSTICS
% 数值实验 1：检查文章关键假设和诊断量，包括 rho 有界性、W 非负性、
% remainder 指标 gammaR 是否随 eps 变小仍保持可控。
%
% 默认 quickMode=true，用较小网格先看趋势；正式表格时改为 false。
root = fileparts(fileparts(mfilename('fullpath')));
addpath(root);
startup_AP_RML;

quickMode = true;
if quickMode
    epsList = [5e-2, 2e-2];
else
    epsList = [5e-2, 2e-2, 1e-2, 5e-3];
end
outdir = utils.output_dir('test1_assumptions');
if quickMode
    outdir = utils.output_dir('test1_assumptions_quick');
end
rows = struct([]);

fprintf('\n========== TEST 1: assumption diagnostics，共 %d 组 ==========' , numel(epsList));
fprintf('\nquickMode=%d\n', quickMode);
for i = 1:numel(epsList)
    par = model.default_params_1d('baseline');
    par.eps = epsList(i);
    if quickMode
        par.Nx = 80;
        par.Ntheta = 64;
        par.T = 10;
        par.dt = min(2e-3, 0.2*par.eps);
        par.tol = 1e-8;
        par.historyEveryTime = 1.0;
    else
        par.Nx = 200;
        par.Ntheta = 64;
        par.T = 50;
        par.dt = min(1e-3, 0.1*par.eps);
        par.tol = 1e-9;
        par.historyEveryTime = 0.5;
    end
    par.outdir = outdir;
    par.amplitudeVariant = 'split';
    par.progressEveryPercent = 10;  % 成组实验中每组少打一点，避免刷屏
    par.storeSnapshots = false;

    fprintf('\n[TEST 1] case %d/%d: eps=%.4g, Nx=%d, Ntheta=%d, T=%.4g, dt=%.4g\n', ...
        i, numel(epsList), par.eps, par.Nx, par.Ntheta, par.T, par.dt);
    result = src.run_wkb_1d(par);

    rows(i).eps = par.eps;
    rows(i).theta_wkb = result.diagnostics.theta_wkb;
    rows(i).err_wkb_to_m = result.diagnostics.err_wkb_to_m;
    rows(i).rho_max = result.diagnostics.rho_max;
    rows(i).W_min = result.diagnostics.W_min;
    rows(i).gammaR = result.diagnostics.gammaR;
    rows(i).residual = result.residual;
    rows(i).steps = result.step;
end
T = struct2table(rows);
disp(T);
utils.ensure_dir(outdir);
save(fullfile(outdir,'summary.mat'), 'T');
fprintf('TEST 1 完成。summary 保存到: %s\n', fullfile(outdir,'summary.mat'));
