% RUN_TEST3_FINE_GRID_COMPARE_N
% 数值实验 3：在较细 theta 网格上比较 direct n 与 WKB 重构 n。
%
% 速度提醒：
%   正式参数 Nx=200, Ntheta=256, T=30, dt=5e-4 会很慢，且还要同时跑
%   WKB 与 direct。默认先用 quickMode=true 调通流程；投稿/最终表格时再改成 false。
root = fileparts(fileparts(mfilename('fullpath')));
addpath(root);
startup_AP_RML;

quickMode = true;
par = model.default_params_1d('baseline');
par.eps = 1e-2;
if quickMode
    par.Nx = 80;
    par.Ntheta = 128;
    par.T = 8;
    par.dt = 1e-3;
    par.tol = 1e-8;
    par.historyEveryTime = 1.0;
    par.outdir = utils.output_dir('test3_compare_n_quick');
else
    par.Nx = 200;
    par.Ntheta = 256;
    par.T = 30;
    par.dt = 5e-4;
    par.tol = 1e-9;
    par.historyEveryTime = 0.5;
    par.outdir = utils.output_dir('test3_compare_n');
end
par.verbose = true;
par.progressEveryPercent = 5;
par.storeSnapshots = false;

fprintf('\n========== TEST 3: fine-grid comparison of n ==========' );
fprintf('\nquickMode=%d, eps=%.4g, Nx=%d, Ntheta=%d, T=%.4g, dt=%.4g\n', ...
    quickMode, par.eps, par.Nx, par.Ntheta, par.T, par.dt);
fprintf('预计最多步数: %d；未知量规模约: %d\n', ceil(par.T/par.dt), (par.Nx+1)*par.Ntheta);
fprintf('[TEST 3] 先运行 WKB，然后运行 direct solver。\n');
wkb = src.run_wkb_1d(par);
direct = src.run_direct_1d(par);

% 加权 L1/L2 误差：x 方向用梯形权重，theta 方向用周期均匀权重。
wx = utils.trapz_weights(wkb.op.nx, wkb.op.dx);
errL1 = wkb.op.dtheta * sum(wx.' * abs(wkb.n - direct.n));
refL1 = wkb.op.dtheta * sum(wx.' * abs(direct.n));
errL2 = sqrt(wkb.op.dtheta * sum(wx.' * (wkb.n - direct.n).^2));
refL2 = sqrt(wkb.op.dtheta * sum(wx.' * direct.n.^2));
summary = struct('quickMode',quickMode, ...
                 'relL1',errL1/max(refL1,realmin),'relL2',errL2/max(refL2,realmin), ...
                 'theta_wkb',wkb.diagnostics.theta_wkb, ...
                 'theta_direct',direct.diagnostics.theta_direct, ...
                 'wkb_steps',wkb.step,'direct_steps',direct.step);
disp(summary);
utils.ensure_dir(par.outdir);
save(fullfile(par.outdir,'summary_compare_n.mat'),'summary','wkb','direct');
fprintf('TEST 3 完成。summary 保存到: %s\n', fullfile(par.outdir,'summary_compare_n.mat'));
