% RUN_TIMEAP_COMPARE_1D 比较 v11 两个时间 AP 实验积分器。
%
% 用法：
%   startup_AP_RML
%   run_timeap_compare_1d
%
% 本脚本会分别运行：
%   1) implicit-coupled  全隐式耦合 Picard；
%   2) projective        micro-macro/projective。
%
% 注意：两个方法都仍然求解 WKB 变量 W 和 u，不直接求解原始密度 n。

root = fileparts(fileparts(mfilename('fullpath')));
addpath(root);
startup_AP_RML;

methods = {'implicit-coupled','projective'};
results = cell(size(methods));

for m = 1:numel(methods)
    par = model.default_params_1d('baseline');
    par.eps = 1e-4;          % 可改为 1e-6 做更强测试
    par.Nx = 50;
    par.Ntheta = 64;
    par.T = 5;               % 对比脚本先跑短时间，确认不会爆，再加到 100
    par.dt = 1e-3;
    par.tol = 1e-8;

    par.timeIntegrator = methods{m};
    par.amplitudeVariant = 'wkb-if-split';
    par.reactionDiscretization = 'logistic-exact';
    par.rhoReconstruction = 'laplace-hybrid';
    par.residualMode = 'wkb-steady';
    par.hamiltonianGauge = 'min';
    par.ifMode = 'h-only';
    par.thetaRephase = false;

    % 全隐式耦合参数。
    par.implicitMaxIter = 12;
    par.implicitTol = 1e-7;
    par.implicitRelax = 0.6;

    % projective 参数。
    par.projectiveMicroSteps = 8;
    par.projectiveMicroDtFactor = 0.25;
    par.projectiveMode = 'u-only';
    par.projectiveCorrectorSteps = 0;

    par.adaptiveTimeStep = true;
    par.adaptiveStrategy = 'phase-cfl';
    par.adaptiveIfLogRange = true;
    par.ifLogRangeMax = 80;
    par.dtMax = par.dt;

    par.prepareInitialMass = true;
    par.initialPhaseMode = 'peaked';
    par.initialRhoProfile = 'scaledK';
    par.initialRhoScale = 0.5;

    par.livePlot = false;
    par.verbose = true;
    par.historyEverySteps = 20;
    par.outdir = utils.output_dir(['timeap_compare_' methods{m}]);

    fprintf('\n========== 运行时间积分器: %s ==========\n', methods{m});
    results{m} = src.run_wkb_1d(par);
    src.diagnose_wkb_history_1d(results{m}.history, true);
end

utils.ensure_dir(utils.resolve_path('data'));
save(utils.resolve_path('data/timeap_compare_results.mat'), 'results', 'methods');
fprintf('\n比较完成，结果已保存到 data/timeap_compare_results.mat\n');
