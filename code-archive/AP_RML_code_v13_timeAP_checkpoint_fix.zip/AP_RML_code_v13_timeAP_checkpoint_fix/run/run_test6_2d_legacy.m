% RUN_TEST6_2D_LEGACY
% 数值实验 6：二维 FEM legacy 程序封装。二维部分仍保留旧实现，
% 这里主要负责路径、参数和结果保存。
root = fileparts(fileparts(mfilename('fullpath')));
addpath(root);
startup_AP_RML(true);

par2d = model.default_params_2d();
utils.ensure_dir(par2d.outdir);
fprintf('\n========== TEST 6: 2D legacy FEM wrapper ==========\n');
fprintf('输出目录: %s\n', par2d.outdir);

if exist('main_bio_2d_restructured','file') == 2
    fprintf('[TEST 6] 调用 main_bio_2d_restructured。二维 legacy 内部输出由原程序控制。\n');
    result2d = main_bio_2d_restructured(par2d); %#ok<NASGU>
    save(fullfile(par2d.outdir,'summary_2d.mat'),'result2d','par2d');
    fprintf('TEST 6 完成。summary 保存到: %s\n', fullfile(par2d.outdir,'summary_2d.mat'));
else
    warning('The 2D legacy wrapper main_bio_2d_restructured.m was not found. Check src_2d_legacy.');
end
