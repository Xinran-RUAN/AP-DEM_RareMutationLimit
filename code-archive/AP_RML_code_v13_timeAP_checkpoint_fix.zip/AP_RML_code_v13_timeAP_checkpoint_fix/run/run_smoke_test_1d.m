% RUN_SMOKE_TEST_1D 小规模冒烟测试：检查路径、求解器和保存是否正常。
root = fileparts(fileparts(mfilename('fullpath')));
addpath(root);
startup_AP_RML;

par = model.default_params_1d('baseline');
par.Nx = 20;
par.Ntheta = 16;
par.eps = 2e-2;
par.dt = 1e-3;
par.T = 5e-3;
par.maxSteps = 5;
par.tol = 0;
par.stopByResidual = false;
par.storeSnapshots = false;
par.verbose = true;
par.progressEverySteps = 1;
par.outdir = utils.output_dir('smoke_test');

fprintf('\n========== RUN_SMOKE_TEST_1D ==========\n');
wkb = src.run_wkb_1d(par);
direct = src.run_direct_1d(par);

fprintf('Smoke test finished. WKB theta = %.6f, direct theta = %.6f. Output: %s\n', ...
    wkb.diagnostics.theta_wkb, direct.diagnostics.theta_direct, par.outdir);
