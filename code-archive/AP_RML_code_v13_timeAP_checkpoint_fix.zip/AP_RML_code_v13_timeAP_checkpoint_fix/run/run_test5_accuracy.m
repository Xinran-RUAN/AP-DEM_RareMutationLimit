% RUN_TEST5_ACCURACY
% 数值实验 5：精度测试。先算一个细网格 WKB 参考解，再与较粗配置比较。
%
% 注意：精度测试天然较慢。默认 quickMode=true 只检查阶数/流程是否正常；
% 正式精度表格请把 quickMode=false。
root = fileparts(fileparts(mfilename('fullpath')));
addpath(root);
startup_AP_RML;

quickMode = true;
base = model.default_params_1d('baseline');
base.eps = 2e-2;
if quickMode
    base.T = 8;
    base.tol = 1e-8;
    base.outdir = utils.output_dir('test5_accuracy_quick');
    base.historyEveryTime = 1.0;
else
    base.T = 20;
    base.tol = 1e-10;
    base.outdir = utils.output_dir('test5_accuracy');
    base.historyEveryTime = 0.5;
end
base.progressEveryPercent = 10;
base.storeSnapshots = false;

fprintf('\n========== TEST 5: accuracy test ==========' );
fprintf('\nquickMode=%d\n', quickMode);
ref = base;
if quickMode
    ref.Nx = 120;
    ref.Ntheta = 128;
    ref.dt = 1e-3;
    configs = [40 32 2e-3; 80 64 1e-3];
else
    ref.Nx = 400;
    ref.Ntheta = 256;
    ref.dt = 2.5e-4;
    configs = [100 64 1e-3; 200 128 5e-4; 300 192 3.333333333e-4];
end
ref.verbose = true;
fprintf('[TEST 5] reference: Nx=%d, Ntheta=%d, dt=%.4g\n', ref.Nx, ref.Ntheta, ref.dt);
refResult = src.run_wkb_1d(ref);

rows = struct([]);
for i = 1:size(configs,1)
    par = base;
    par.Nx = configs(i,1);
    par.Ntheta = configs(i,2);
    par.dt = configs(i,3);
    par.verbose = true;
    fprintf('\n[TEST 5] case %d/%d: Nx=%d, Ntheta=%d, dt=%.4g\n', ...
        i, size(configs,1), par.Nx, par.Ntheta, par.dt);
    res = src.run_wkb_1d(par);
    rows(i).Nx = par.Nx;
    rows(i).K = par.Ntheta;
    rows(i).dt = par.dt;
    rows(i).theta_wkb = res.diagnostics.theta_wkb;
    rows(i).theta_error_to_ref = utils.periodic_distance(res.diagnostics.theta_wkb, refResult.diagnostics.theta_wkb);
    rows(i).theta_error_to_m = res.diagnostics.err_wkb_to_m;
    rows(i).sigma_theta = res.diagnostics.sigma_theta;
    rows(i).steps = res.step;
end
T = struct2table(rows);
disp(T);
utils.ensure_dir(base.outdir);
save(fullfile(base.outdir,'summary_accuracy.mat'),'T','refResult');
fprintf('TEST 5 完成。summary 保存到: %s\n', fullfile(base.outdir,'summary_accuracy.mat'));
