# v6：WKB 框架下的小 epsilon 稳健化代码说明

这一版的目标是：**仍然求解 WKB 变量 `W` 和 `u`，不把主求解器退回到原始密度 `n` 方程**；同时处理 `epsilon` 很小时出现的矩阵奇异、指数溢出和 residual 不易判断的问题。

## 1. 推荐主格式

默认主格式为

```matlab
par.amplitudeVariant = 'wkb-if-split';
par.reactionDiscretization = 'patankar';
par.residualMode = 'wkb-steady';
par.gaugeMode = 'auto';
par.ifGaugeBalance = true;
```

在 `run_wkb_1d.m` 中，旧脚本里常用的

```matlab
par.amplitudeVariant = 'density-compatible-if';
```

会被自动导向新版 `wkb-if-split`。这样做是为了避免小 `epsilon` 下构造

```matlab
exp((u_{k+1}-u_k)/epsilon)
```

这种相邻 trait 点指数比值矩阵。该矩阵是之前 `epsilon=1e-4` 时出现 `RCOND` 极小的主要来源。

## 2. 新的 WKB-IF split 振幅更新

新增核心文件：

```matlab
+src/update_w_wkb_if_split_fd_1d.m
```

该函数仍然组装并求解关于 `W^{n+1}` 的线性系统。它只把时间差分从

```matlab
eps*(W^{n+1}-W^n)/dt
```

改成

```matlab
eps*(W^{n+1}-q_k W^n)/dt,
q_k = exp((u_k^n-u_k^{n+1})/eps).
```

这个 `q_k` 是同一个 trait 节点上的时间积分因子，用来补偿 `n=W*exp(u/eps)` 的时间方向链式法则误差。它不是相邻点比值，所以不会产生旧 density-compatible 矩阵的奇异性。

为了保持稳态方程的零点，剩余零阶项仍采用 Patankar production-destruction 处理，而不是直接把主格式改成密度方程。

## 3. 技术 gauge 平衡

小 `epsilon` 时，即使格式正确，`q_k=exp((u^n-u^{n+1})/eps)` 也可能在浮点数层面非常大。新版利用 WKB 的常数 gauge 自由度，在每一步给 `u^{n+1}` 加一个常数，使线性系统右端的 `q_k W^n` 位于安全数值范围内。

这个操作不改变：

- `u` 的导数；
- `argmax u`，即 fittest trait 的位置；
- 重构密度 `W*exp(u/eps)`；
- WKB 方程的物理含义。

相关诊断量会保存在 history 中：

```matlab
history.qLogAbsMax
history.qLogMax
history.qLogMin
history.qClipCount
history.ifGaugeShift
```

## 4. 初值质量准备

小 `epsilon` 下，如果初始 `max(u)=0` 且 `W=O(1)`，则

```matlab
rho = int W*exp(u/eps) dtheta
```

可能非常小，相当于从“近乎空种群”开始，容易产生强初始快层。新版默认只按 `x` 缩放初始 `W`，使初始总密度达到 `O(1)`：

```matlab
par.prepareInitialMass = true;
par.initialRhoProfile = 'scaledK';
par.initialRhoScale = 0.5;
```

这不会改变相位 `u` 的峰值位置，因此仍然是在 WKB 框架内测试 trait selection。

若要使用你测试过的均匀相位初值，可设：

```matlab
par.initialPhaseMode = 'flat';
```

## 5. residual 和病态监测

新版推荐用

```matlab
par.residualMode = 'wkb-steady';
```

它直接监测 WKB 稳态方程残差，而不是仅用单步差分判断是否收敛。单步 residual 仍保存为：

```matlab
history.residual_u
history.residual_n
history.residual_n_scaled
history.residual_W_legacy
```

稳态残差分量保存为：

```matlab
history.res_phase_steady
history.res_amplitude_steady
history.res_density_steady
history.res_wkb_steady
```

其中 `res_density_steady` 只是 gauge-invariant 诊断量，不表示主求解器在解 `n` 方程。

运行后可用：

```matlab
src.diagnose_wkb_history_1d(wkb.history, true)
```

输出中文诊断，判断 residual 不下降主要来自相位方程、振幅方程、`q` 指数过大、相位 CFL 过大，还是 trait 网格已经无法解析密度峰宽。

## 6. 自适应时间步

新版自适应时间步默认只限制相位 Hamilton-Jacobi 的显式 CFL：

```matlab
par.adaptiveTimeStep = true;
par.adaptiveStrategy = 'phase-cfl';
par.phaseCflSafety = 0.45;
```

它不再强制 `dt=O(epsilon)`。不过，如果想和旧格式比较，也可以使用：

```matlab
par.adaptiveStrategy = 'eps-source';
```

或

```matlab
par.adaptiveStrategy = 'combined';
```

## 7. 建议测试参数

先用：

```matlab
par.eps = 1e-4;
par.dt = 1e-3;
par.Nx = 50;
par.Ntheta = 64;
par.amplitudeVariant = 'wkb-if-split';
par.residualMode = 'wkb-steady';
par.adaptiveTimeStep = true;
par.adaptiveStrategy = 'phase-cfl';
```

若要测试 `epsilon=1e-6`，建议同时查看：

```matlab
history.peakWidthOverGrid
history.qLogAbsMax
history.qClipCount
history.res_phase_steady
history.res_amplitude_steady
```

当 `peakWidthOverGrid < 1` 时，密度峰形已明显小于一个 trait 网格。此时 WKB phase 的 fittest trait 位置仍可能可靠，但不应要求重构密度峰形在该网格上完全解析。
