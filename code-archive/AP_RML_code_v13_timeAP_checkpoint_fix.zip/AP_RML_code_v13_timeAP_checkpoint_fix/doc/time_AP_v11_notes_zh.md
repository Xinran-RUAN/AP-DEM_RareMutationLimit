# v11 时间积分器修改记录

## 背景

当前 WKB 分解可以剥离 trait 方向的指数集中，但动态方程中仍有 \(\varepsilon \partial_t W\) 的快时间尺度。并且本模型的有效 Hamiltonian

\[
H_k(t)=H_k(\rho(t))
\]

随时间变化，简单使用 `H^n` 冻结一个大时间步会产生相位误差。该误差在密度重构

\[
n = W\exp(u/\varepsilon)
\]

中被 \(1/\varepsilon\) 放大。

v11 试验两个方向：

1. 全隐式耦合更新：在一个时间步内迭代更新 `rho,H,u,W`。
2. projective / micro-macro：先用 epsilon 尺度小步解析快层，再对慢变量大步外推。

## 修改 1：全隐式耦合 Picard

新增 `par.timeIntegrator='implicit-coupled'`。

每个时间步内 Picard 迭代：

1. 根据当前猜测 `(Wguess,uguess)` 重构 `rhoGuess`；
2. 解特征值问题得到 `HGuess=H(rhoGuess)`；
3. 用公共一步算子从 `(Wold,uold)` 更新到 `(Wcand,ucand)`；
4. 对 `(Wguess,uguess)` 做欠松弛更新；
5. 检查相对变化。

该方法仍然是 time evolution，不是直接求稳态。

## 修改 2：projective / micro-macro

新增 `par.timeIntegrator='projective'`。

每个宏步：

1. 选取 `dt_micro ≈ eps/scale`；
2. 做 `projectiveMicroSteps` 个 micro steps；
3. 用最后两个 micro states 估计相位导数；
4. 默认只外推 `u`，不外推 `W`；
5. 可选做 corrector micro steps。

默认只外推 `u` 是为了避免 `log(W)` 外推重新制造指数病态。

## 修改 3：公共一步算子

新增：

```matlab
src.wkb_one_step_frozenH_1d
```

它在给定 `rho,H` 的情况下推进一次 `W,u`。全隐式 Picard 和 projective micro steps 都调用这个函数，避免复制旧代码。

## 修改 4：诊断量

新增 history 字段：

```matlab
implicitIter
implicitRelChange
implicitConverged
projectiveMicroStepsUsed
projectiveMicroDt
projectiveRemainingDt
projectiveModeCode
```

进度行新增：

```text
impIt, impRel, microN, microDt
```

## 推荐命令

```matlab
par.timeIntegrator = 'implicit-coupled';
```

或

```matlab
par.timeIntegrator = 'projective';
```

运行后使用：

```matlab
src.diagnose_wkb_history_1d(wkb.history, true)
```

并重点查看 `implicitRelChange` 或 `projectiveMicroDt`。
