# v11 中间结果保存说明

本次修改的目的，是避免长时间 projective/time-AP 计算只有在最终时刻才保存数据。修改后，即使程序没有跑到终止时刻，也可以在输出目录中找到最近的计算状态。

## 1. 输出文件

运行 `run_main_1d.m` 后，输出目录中会出现以下文件。

### latest_checkpoint.mat

这是最新检查点文件。程序会按 `par.checkpointEveryTime` 或 `par.checkpointEverySteps` 覆盖保存一次。若计算被手动停止，可以优先读取这个文件。

它包含主要变量：

- `W`, `u`
- `n`, `rho`, `H`
- `D`, `Kx`, `grid`, `op`
- `par`, `tag`, `t`, `step`, `residual`
- `history`, `diagnostics`, `resInfo`, `dtInfo`, `stepInfo`

### history_checkpoint.mat

这是轻量级历史文件，主要用于画 residual、thetaWKB 等诊断曲线。它不保存完整的 `W` 和 `n`，文件更小。

### snapshots/*.mat

这是编号快照文件，保存在 `snapshots` 子目录中。文件名包含 step 和 t，例如：

```text
baseline_eps0.0001_..._step0005000_t5.mat
```

这些文件适合保存若干中间时刻，用于后处理和画图。

## 2. 主要参数

```matlab
par.storeSnapshots = true;          % 是否保存编号快照
par.snapshotTimes = [];             % 指定保存的物理时刻，例如 [1,5,10,20]
par.snapshotEveryTime = 5.0;        % 每隔多少物理时间保存一个编号快照
par.snapshotEverySteps = [];        % 每隔多少步保存一个编号快照

par.saveLatestCheckpoint = true;    % 是否覆盖保存 latest_checkpoint.mat
par.checkpointEveryTime = 0.5;      % 每隔多少物理时间保存一次 latest checkpoint
par.checkpointEverySteps = [];      % 每隔多少步保存一次 latest checkpoint

par.saveHistoryCheckpoint = true;   % 是否保存 history_checkpoint.mat
par.snapshotSubdir = 'snapshots';
```

在 `quick` 模式下，当前默认设置为：

```matlab
par.storeSnapshots = true;
par.snapshotEveryTime = 5.0;
par.saveLatestCheckpoint = true;
par.checkpointEveryTime = 0.5;
par.saveHistoryCheckpoint = true;
```

因此即使在 `T=100` 前手动停止，也能读取最近状态。

## 3. 如何读取最近结果

在 MATLAB 中运行：

```matlab
S = load(fullfile(par.outdir, 'latest_checkpoint.mat'));
```

如果不确定输出目录，可以直接进入 `data/main_single_case_quick`，找到对应算例文件夹或 `latest_checkpoint.mat`。

也可以用新增的后处理脚本：

```matlab
post_load_latest_checkpoint
```

该脚本会读取 `par.outdir/latest_checkpoint.mat`，并打印当前时间、步数、residual、thetaWKB 等信息。

