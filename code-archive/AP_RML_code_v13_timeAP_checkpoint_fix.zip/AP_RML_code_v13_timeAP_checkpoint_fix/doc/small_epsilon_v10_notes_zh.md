# v10 小 epsilon 修正说明

本版修正 v9 中仍然不合理的结果。核心判断如下。

1. 结果停留在初始 trait 附近并不是 WENO 没有开启造成的。WENO 只影响相位导数的高阶重构，不能解决 WKB 分解中公共 Hamiltonian 偏移和 theta 依赖 rephase 对相位导数结构的影响。

2. v9 中的 theta 依赖 rephase 虽然严格保持重构密度 `n=W.*exp(u/eps)` 不变，但会把 `eps*log(W)` 吸收到 `u` 中。这个操作会改变 `u_theta`，因此会改变 Hamilton-Jacobi 方程中的数值 Hamiltonian，可能污染 fittest trait 的定位。v10 默认关闭该操作。

3. v10 保留 WKB 框架，即主未知量仍然是 `W` 和 `u`，没有改为求解原始密度方程。为了消除小 epsilon 下的公共指数刚性，本版采用有效 Hamiltonian 的标量 gauge 平移：

   ```matlab
   Huse = Hraw - min(Hraw)
   ```

   并且在相位方程和振幅方程中同时使用 `Huse`。这只对应 WKB 的常数 gauge 选择，不改变相位导数结构，也不改变重构密度方程。

4. `wkb-if-split` 中的积分因子默认使用平移后的 `Huse`。因此 `exp(dt*H/eps)` 不再包含无意义的公共偏移，只反映不同 trait 之间的相对选择强度。

5. v10 不再因为 `log(qW)` 的自然跨度稍大就拒步。该量主要用于诊断。只有接近双精度溢出或 `rho/H/residual` 出现非有限值时才会停止或重试。

建议先使用 `run_main_1d.m` 中的默认设置测试：

```matlab
par.eps = 1e-6;
par.dt = 1e-3;
par.amplitudeVariant = 'wkb-if-split';
par.reactionDiscretization = 'logistic-exact';
par.rhoReconstruction = 'laplace-hybrid';
par.hamiltonianGauge = 'min';
par.thetaRephase = false;
```

运行时重点观察：

```matlab
HrawMin, HrawMax, HuseMin, HuseMax,
seedLogRange, logWRange, phaseCFL,
res_phase_steady, res_amp_w_steady, res_density_steady,
thetaWKB, thetaDIR, peakGrid.
```

如果 `peakGrid < 1`，说明密度峰宽已经小于 trait 网格。此时 WKB 相位的选中特征位置仍然是主要可信指标，而节点密度图像和 `thetaDIR` 可能对网格点位置很敏感。
