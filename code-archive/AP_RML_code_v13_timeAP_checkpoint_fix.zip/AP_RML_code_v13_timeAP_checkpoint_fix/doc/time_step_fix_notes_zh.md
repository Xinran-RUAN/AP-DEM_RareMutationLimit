# 时间步长、residual 和保正更新修改说明

本版本根据 `time_step_issue_note.pdf` 的 6.1--6.4 部分，对一维有限差分代码作了如下修改。

## 1. 时间方向 density-compatible / integrating-factor 振幅更新

新增文件：

- `+src/update_w_density_if_fd_1d.m`

新增选项：

```matlab
par.amplitudeVariant = 'density-compatible-if';
```

该格式使用

```matlab
q_k = exp((uOld_k - uNew_k)/eps)
```

并离散

```text
eps*(Wnew - q.*Wold)/dt - diffusion_in_x - density_compatible_theta_diffusion = reaction.
```

乘回 `Enew = exp(uNew/eps)` 后，它对应密度变量
`n = W.*exp(u/eps)` 的全离散更新，避免旧 split 时间离散中 `u` 和 `W` 分别推进造成的时间链式法则误差。

旧的半离散 density-compatible 全离散格式仍可通过

```matlab
par.amplitudeVariant = 'density-compatible-semidiscrete';
```

调用；split 格式仍可通过

```matlab
par.amplitudeVariant = 'split';
```

调用。

## 2. Patankar 型反应项

新增/修改选项：

```matlab
par.reactionDiscretization = 'patankar';   % 默认
par.reactionDiscretization = 'implicit';   % 旧线性隐式反应
```

Patankar 形式在密度层面使用

```text
(K-rho)_+ n^old - (K-rho)_- n^new
```

以减轻正增长项导致的保正时间步限制。该选项用于新版 WKB density-compatible-if 更新，也用于 direct density solver。

## 3. Gauge-invariant residual

新增文件：

- `+src/compute_wkb_residual_1d.m`

新增选项：

```matlab
par.residualMode = 'gauge-invariant';  % 默认
par.residualMode = 'legacy';           % 旧 W residual
```

默认 residual 比较：

1. 相位 `u` 在去除常数 gauge 后的变化；
2. 重构密度 `n = W.*exp(u/eps)` 的变化。

旧的基于 `W` 的 residual 仍保存在 `history.residual_W_legacy`，便于诊断 gauge 缩放对 `W` 的影响。

## 4. 可选自适应时间步

新增文件：

- `+src/select_wkb_time_step_1d.m`
- `+src/time_step_stability_info_1d.m`

新增选项：

```matlab
par.adaptiveTimeStep = true;    % 默认 false
par.adaptiveSafety = 0.5;
par.dtMax = [];                 % 为空时使用 par.dt
par.dtMin = 0;
```

启用时使用近似限制

```text
dt <= eta*eps / max(1, max r_+, max |H|),
```

其中 `eta = par.adaptiveSafety`，`par.dt` 作为最大时间步。

## 5. 主要入口文件修改

- `+src/run_wkb_1d.m`：接入新版振幅格式、自适应时间步、gauge-invariant residual 和额外诊断；
- `+src/update_direct_density_fd_1d.m`：加入 Patankar 反应选项；
- `+utils/append_history.m`：保存 `dt`、`residual_n`、`residual_u`、`residual_W_legacy`、`lambdaR`、`lambdaH`；
- `+model/default_params_1d.m` 和 `run/run_main_1d.m`：默认启用新版 WKB 振幅格式、Patankar 反应和 gauge-invariant residual。
