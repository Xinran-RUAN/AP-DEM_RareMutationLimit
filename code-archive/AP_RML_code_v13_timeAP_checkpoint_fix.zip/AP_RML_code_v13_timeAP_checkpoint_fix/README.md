# AP_RML_code_restructured

Restructured MATLAB code for the WKB formulation of the rare-mutation dispersal-selection model.

## Layout

- `+model`: default parameters, grids, coefficient profiles, and initial data.
- `+src`: core numerical solvers and diagnostics for the 1D finite-difference WKB/direct solvers.
- `+utils`: path, output, progress display, and small numerical utilities.
- `run`: main scripts. `run_main_1d.m` is the ordinary one-case main program; `run_test*.m` are numerical experiments.
- `post`: post-processing scripts to generate tables/plots after data are saved.
- `src_2d_legacy`: 2D FEM legacy routines copied from the old code, with a wrapper experiment script.
- `doc`: notes and TeX/manuscript updates.

## Quick start

From the project root in MATLAB:

```matlab
startup_AP_RML
run_smoke_test_1d
```

For a normal single-parameter run, use:

```matlab
run_main_1d
```

For manuscript experiments, run for example:

```matlab
run_test3_fine_grid_compare_n
```

The solvers now print start information, estimated total steps, periodic progress lines, elapsed time, ETA, residual, selected trait, and final save paths. The output frequency is controlled by these fields in `par`:

```matlab
par.verbose = true;
par.progressEveryPercent = 5;
par.progressEverySeconds = 10;
par.progressEverySteps = [];
par.historyEveryTime = 0.2;
```

All output directories are resolved relative to the project root through `utils.output_dir` / `utils.resolve_path`, so scripts can be launched from the project root, from `run/`, or from another current folder. The 2D legacy path is added only when calling `startup_AP_RML(true)` or running `run_test6_2d_legacy`.

## 2026 time-step/residual update

This version adds the time-discretization fixes described in `time_step_issue_note.pdf`:

- `par.amplitudeVariant = 'density-compatible-if'` uses a time-direction density-compatible / integrating-factor update with
  `q_k = exp((u_k^n-u_k^{n+1})/eps)`.  This keeps the fully discrete density variable
  `n = W.*exp(u/eps)` consistent with the density-level time difference.
- `par.reactionDiscretization = 'patankar'` uses a production-destruction reaction treatment for the density-compatible WKB
  update and the direct density solver.  Use `'implicit'` to recover the old linear implicit reaction.
- `par.residualMode = 'gauge-invariant'` makes the WKB stopping residual use the reconstructed density `n` and the phase modulo
  additive constants.  The old W-based residual is still stored as `history.residual_W_legacy` and can be used by setting
  `par.residualMode = 'legacy'`.
- `par.adaptiveTimeStep = true` enables the optional safeguard
  `dt <= par.adaptiveSafety*eps/max(1,max r_+,max(abs(H)))`, with `par.dt` used as the maximum step.

The old split update remains available with `par.amplitudeVariant = 'split'`, and the previous fully discrete density-compatible
implementation is available as `par.amplitudeVariant = 'density-compatible-semidiscrete'` for comparison.
