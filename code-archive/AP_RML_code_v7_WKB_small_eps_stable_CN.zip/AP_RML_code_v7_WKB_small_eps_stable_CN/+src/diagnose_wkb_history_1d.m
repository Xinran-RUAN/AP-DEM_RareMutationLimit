function diagnose_wkb_history_1d(history, doPlot)
%DIAGNOSE_WKB_HISTORY_1D 中文打印 WKB 运行历史中的病态来源。
%
%  用法：
%       src.diagnose_wkb_history_1d(wkb.history, true)
%
%  该函数不重新计算解，只根据 history 中保存的监测量判断：
%  1) residual 主要来自 u、W 还是稳态方程；
%  2) 是否出现 q_k=exp((u^n-u^{n+1})/eps) 过大；
%  3) 是否存在相位 CFL 过大；
%  4) 是否存在矩阵病态。

if nargin < 2 || isempty(doPlot)
    doPlot = false;
end
if isempty(history)
    fprintf('history 为空，无法诊断。\n');
    return;
end

fprintf('\n========== WKB 小 epsilon 诊断摘要 ==========' );
fprintf('\n记录点数: %d\n', numel(history.t));
print_last(history, 'residual', '最终 residual');
print_last(history, 'residual_u', '最终 update residual: u');
print_last(history, 'residual_n', '最终 update residual: 重构密度 n，仅作诊断');
print_last(history, 'residual_W_legacy', '最终旧 W residual，仅作诊断');
print_last(history, 'res_phase_steady', '最终稳态 residual: phase');
print_last(history, 'res_amplitude_steady', '最终稳态 residual: amplitude W');
print_last(history, 'qLogAbsMax', '最终 max |log q|');
print_last(history, 'phaseCFL', '最终 phase CFL');
print_last(history, 'neighborJumpOverEps', '最终 max |u_{k+1}-u_k|/eps');
print_last(history, 'peakWidthOverGrid', '最终峰宽/网格宽度');
print_last(history, 'matrixRcondEst', '最终矩阵 rcond 估计');
print_last(history, 'rho_max', '最终 max rho');
print_last(history, 'W_min', '最终 min W');
print_last(history, 'W_max', '最终 max W');

% 简单规则判断。
fprintf('\n--- 自动判断 ---\n');
if has_field(history,'qLogAbsMax') && max_finite(history.qLogAbsMax) > 80
    fprintf('1) q=exp((u^n-u^{n+1})/eps) 的指数范围很大；建议保持 ifGaugeBalance=true，检查 qClipCount，必要时减小 dt。\n');
else
    fprintf('1) q 指数范围未显示明显爆炸。\n');
end
if has_field(history,'phaseCFL') && max_finite(history.phaseCFL) > 1
    fprintf('2) phase CFL 曾超过 1；建议开启 adaptiveStrategy=''phase-cfl'' 或降低 dt。\n');
else
    fprintf('2) phase CFL 未显示明显超限。\n');
end
if has_field(history,'matrixRcondEst') && min_finite(history.matrixRcondEst) < 1e-12
    fprintf('3) 振幅矩阵出现病态；查看 qLogAbsMax、rIfPlusMax 和 W 动态范围。\n');
else
    fprintf('3) 未检测到明显矩阵奇异，或未开启 monitorMatrixCondition。\n');
end
if has_field(history,'res_phase_steady') && has_field(history,'res_amplitude_steady')
    rp = last_finite(history.res_phase_steady);
    ra = last_finite(history.res_amplitude_steady);
    if isfinite(rp) && isfinite(ra)
        if rp > 10*ra
            fprintf('4) 稳态残差主要来自 phase 方程。\n');
        elseif ra > 10*rp
            fprintf('4) 稳态残差主要来自 W 振幅方程。\n');
        else
            fprintf('4) phase 和 W 振幅方程残差量级接近。\n');
        end
    end
end
fprintf('==============================================\n');

if doPlot
    try
        figure; plot(history.t, history.residual, 'LineWidth', 1.4); grid on;
        xlabel('t'); ylabel('residual'); title('WKB residual history');
        if has_field(history,'res_phase_steady')
            figure; semilogy(history.t, max(history.res_phase_steady,realmin), 'LineWidth', 1.4); hold on;
            semilogy(history.t, max(history.res_amplitude_steady,realmin), 'LineWidth', 1.4); grid on;
            xlabel('t'); ylabel('steady residual'); legend('phase','amplitude W');
            title('WKB steady residual components');
        end
        if has_field(history,'qLogAbsMax')
            figure; plot(history.t, history.qLogAbsMax, 'LineWidth', 1.4); grid on;
            xlabel('t'); ylabel('max |log q|'); title('IF exponent diagnostic');
        end
    catch ME
        warning('诊断图绘制失败: %s', ME.message);
    end
end
end

function tf = has_field(s, name)
tf = isstruct(s) && isfield(s,name) && ~isempty(s.(name));
end

function print_last(s, name, label)
if has_field(s,name)
    v = last_finite(s.(name));
    if isfinite(v)
        fprintf('%s: %.6e\n', label, v);
    end
end
end

function v = last_finite(x)
x = x(:);
y = x(isfinite(x));
if isempty(y), v = NaN; else, v = y(end); end
end

function v = max_finite(x)
y = x(isfinite(x));
if isempty(y), v = NaN; else, v = max(y); end
end

function v = min_finite(x)
y = x(isfinite(x));
if isempty(y), v = NaN; else, v = min(y); end
end
