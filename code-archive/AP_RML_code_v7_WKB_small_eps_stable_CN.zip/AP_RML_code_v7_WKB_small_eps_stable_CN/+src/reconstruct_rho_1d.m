function [rho, n, info] = reconstruct_rho_1d(W, u, eps, op, mode)
%RECONSTRUCT_RHO_1D 由 WKB 变量重构 n 和 rho。
%   n(x,theta) = W(x,theta) * exp(u(theta)/eps)
%   rho(x)     = int n(x,theta) dtheta
%
%   本版本的 direct-log 不要求 max(u)=0。它对每个 x 行使用
%       log n_{j,k} = log W_{j,k} + u_k/eps
%   做 log-sum-exp，因此 incremental gauge、w-balance gauge 等都可以使用。

if nargin < 5 || isempty(mode)
    mode = 'direct-log';
end
info = struct('mode', mode, 'usedFallback', false, 'thetaStar', NaN, 'dduStar', NaN, ...
              'numNonpositiveW', 0, 'lognMax', NaN, 'logrhoMax', NaN);

switch lower(mode)
    case {'direct','direct-log'}
        Wreal = real(W);
        bad = (~isfinite(Wreal)) | (Wreal <= 0);
        info.numNonpositiveW = nnz(bad);
        Wpos = max(Wreal, realmin);
        logW = log(Wpos);
        logn = bsxfun(@plus, logW, u(:).'/eps);
        rowMax = max(logn, [], 2);
        rowMaxSafe = min(max(rowMax, -745), 700);  % exp(700) 仍在 double 范围内
        nScaled = exp(bsxfun(@minus, logn, rowMax));
        n = bsxfun(@times, nScaled, exp(rowMaxSafe));
        rho = op.dtheta * sum(n, 2);
        info.lognMax = max(logn(:));
        info.logrhoMax = max(log(max(rho,realmin)));
    case 'laplace'
        [rho, n, info] = src.reconstruct_laplace_1d(W, u, eps, op, false);
    case {'laplace-hybrid','hybrid-laplace'}
        [rho, n, info] = src.reconstruct_laplace_1d(W, u, eps, op, true);
    otherwise
        error('Unknown rho reconstruction mode "%s".', mode);
end
rho = real(rho(:));
n = real(n);
end
