function [Wnew, uWork, info] = update_w_wkb_if_split_fd_1d(W, uOld, uRaw, D, Kx, rho, H, eps, dt, op, par)
%UPDATE_W_WKB_IF_SPLIT_FD_1D WKB 框架内的小 epsilon 稳健振幅更新。
%
%  重要说明：本函数始终推进 WKB 变量 W 和 u，不求解原始密度 n 的全局方程。
%  这里做的只是对 W 方程中最容易导致小 epsilon 病态的零阶项作技术处理：
%
%  (1) H-only integrating factor：
%      连续 W 方程中有 H W/eps，而相位方程中有 -H。二者在 n=W exp(u/eps)
%      中抵消。旧的 full IF 使用 exp((u^n-u^{n+1})/eps)，会把 HJ 梯度项
%      |u_theta|^2 也放进指数，eps 很小时容易制造巨大 q。新版默认只抵消
%      H 项：q_k = exp(dt*H_k/eps)。这样保留 WKB 结构，同时避免 p^2/eps
%      型的人为放大。
%
%  (2) logistic-exact reaction scaling：
%      K-rho 是真实非局部竞争项，时间尺度为 eps。若用显式正生产 Patankar，
%      dt/eps 很大时会把 rho 从 O(1) 一步推到 O(dt/eps)。新版对每个 x 点的
%      竞争反应 rho_t=(K-rho)rho/eps 使用精确 logistic 缩放，并把同一个缩放
%      乘到该 x 点所有 theta 上。这仍然是在 W 上操作，不是求解 n 方程。
%
%  (3) 剩余的空间扩散、theta 扩散、upwind 运输和 -2eps*u_thetatheta 项继续
%      作为 W 方程的线性隐式步处理。该部分不含 exp((u_{k+1}-u_k)/eps)
%      这种相邻指数比值。
%
%  这些处理的目标是：在 eps 很小时避免数值奇异和 rho 爆炸，同时保留通过
%  WKB phase 捕捉 fittest trait 的算法框架。

if nargin < 11 || isempty(par)
    par = struct();
end
Ktheta = op.Ntheta;
nx = op.nx;
N = nx*Ktheta;
info = struct();

reactionMode = local_get_string(par, 'reactionDiscretization', 'logistic-exact');
ifMode = lower(local_get_string(par, 'ifMode', 'h-only'));

%-------------------------
% 1. 积分因子 q。
%    默认只抵消 H 项。full 模式保留作对比，但小 epsilon 不推荐。
%-------------------------
switch ifMode
    case {'h-only','h','hamiltonian-only','eigenvalue-only'}
        logQ0 = dt * H(:).' / eps;
        info.ifModeUsed = 'h-only';
    case {'full','full-phase'}
        logQ0 = (uOld(:).' - uRaw(:).') / eps;
        info.ifModeUsed = 'full-phase';
    case {'none','off'}
        logQ0 = zeros(1,Ktheta);
        info.ifModeUsed = 'none';
    otherwise
        error('Unknown ifMode "%s".', ifMode);
end

%-------------------------
% 2. 技术 gauge：只移动 uRaw 的常数项，并在 q 中作相反缩放。
%    这不改变 u 的导数、argmax、Hhat，也不改变重构密度。
%-------------------------
Wpos = max(real(W), realmin);
logW = log(Wpos);
logQMat0 = repmat(logQ0, nx, 1);
logSeed0 = logW + logQMat0;
info.logQMax_raw = max(logQ0(:));
info.logQMin_raw = min(logQ0(:));
info.qLogMaxRaw = info.logQMax_raw;
info.qLogMinRaw = info.logQMin_raw;
info.seedLogMax_beforeGauge = max(logSeed0(:));
info.seedLogMin_beforeGauge = min(logSeed0(:));

useBalance = local_get_bool(par, 'ifGaugeBalance', true);
if useBalance
    target = local_get_num(par, 'ifRhsLogTarget', NaN);
    if ~isfinite(target)
        % 目标不要随 eps 过分增大；W 本身保持 O(1)--O(100) 更安全。
        target = log(local_get_num(par, 'ifSeedTargetValue', 10));
    end
    cGauge = eps * (info.seedLogMax_beforeGauge - target);
else
    target = info.seedLogMax_beforeGauge;
    cGauge = 0;
end
uWork = uRaw + cGauge;
logQ = logQ0 - cGauge/eps;
logSeed = logW + repmat(logQ, nx, 1);

clipHalfWidth = local_get_num(par, 'ifRhsLogClip', 120);
if isfinite(clipHalfWidth) && clipHalfWidth > 0
    hi = target + clipHalfWidth;
    lo = target - clipHalfWidth;
else
    hi = 700; lo = -745;
end
logSeedClip = min(max(logSeed, lo), hi);
Wseed = exp(logSeedClip);
Wseed(~isfinite(Wseed)) = 0;

info.ifGaugeShift = cGauge;
info.ifRhsLogTarget = target;
info.logQMax = max(logQ(:));
info.logQMin = min(logQ(:));
info.qLogMax = info.logQMax;
info.qLogMin = info.logQMin;
info.qLogAbsMax = max(abs([info.logQMax, info.logQMin]));
info.numRhsLogClippedHigh = nnz(logSeed > hi);
info.numRhsLogClippedLow = nnz(logSeed < lo);
info.qClipCount = info.numRhsLogClippedHigh + info.numRhsLogClippedLow;
info.qClipFraction = info.qClipCount / max(numel(logSeed),1);
info.seedLogMax_afterGauge = max(logSeed(:));
info.seedLogMin_afterGauge = min(logSeed(:));
info.seedLogMax_afterClip = max(logSeedClip(:));
info.seedLogMin_afterClip = min(logSeedClip(:));

%-------------------------
% 3. 对真实非局部竞争项 K-rho 作 exact logistic 缩放。
%    这是在 W 上按 x 点逐行缩放，不是全局求解密度方程。
%-------------------------
useExactReaction = any(strcmpi(reactionMode, {'logistic-exact','exact-logistic','exact','ap-reaction','patankar'}));
% 小 epsilon 下，patankar 的显式正生产会导致 rho 一步放大 O(dt/eps)。因此在
% wkb-if-split 主格式里把 patankar 自动提升为 logistic-exact，并在 info 中记录。
if strcmpi(reactionMode, 'patankar')
    info.reactionModeRequested = 'patankar';
    reactionMode = 'logistic-exact';
end

if useExactReaction
    [scaleX, rhoAfterReact, reactInfo] = local_logistic_reaction_scale(rho(:), Kx(:), eps, dt, par);
    Wseed = bsxfun(@times, Wseed, scaleX(:));
    info.rhoReactionBeforeMax = max(rho(:));
    info.rhoReactionAfterMax = max(rhoAfterReact(:));
    info.reactionScaleMax = max(scaleX(:));
    info.reactionScaleMin = min(scaleX(:));
    info.reactionModeUsed = reactionMode;
    info.reactionScaleClipped = reactInfo.numClipped;
else
    info.reactionModeUsed = reactionMode;
    info.rhoReactionBeforeMax = max(rho(:));
    info.rhoReactionAfterMax = NaN;
    info.reactionScaleMax = 1;
    info.reactionScaleMin = 1;
    info.reactionScaleClipped = 0;
end

%-------------------------
% 4. 剩余 W 方程的线性隐式步。
%    此处不含 K-rho 和 H 的 stiff 正生产；只保留扩散、upwind 运输和
%    -2 eps u_{theta theta} 这个 O(eps) 零阶项。
%-------------------------
ddu = (op.Ltheta * uWork(:)).';
rCurvMat = repmat((-2*eps*ddu(:).'), nx, 1);
rCurv = rCurvMat(:);
rPlus = max(rCurv, 0);
rMinus = max(-rCurv, 0);

b = eps * Wseed(:);
DblockLx = kron(spdiags(D(:),0,Ktheta,Ktheta), op.Lx);
Lth = op.Ltheta_big;
Tmat = src.upwind_transport_matrix(uWork, op);
A = eps*speye(N) - dt*DblockLx - dt*eps^2*Lth;
if ~isfield(par,'transportImplicit') || par.transportImplicit
    A = A + dt*2*eps*Tmat;
else
    b = b - dt*2*eps*(Tmat*Wseed(:));
end

% rCurv 很小，但仍采用 production-destruction 保正写法。
A = A + dt*spdiags(rMinus,0,N,N);
b = b + dt*(rPlus(:).*Wseed(:));

info.matrixDiagMin = min(abs(diag(A)));
info.matrixDiagMax = max(abs(diag(A)));
info.matrixCondEst = NaN;
info.matrixRcondEst = NaN;
if local_get_bool(par, 'monitorMatrixCondition', false)
    try
        info.matrixCondEst = condest(A);
        info.matrixRcondEst = 1 / info.matrixCondEst;
    catch
        info.matrixCondEst = NaN;
        info.matrixRcondEst = NaN;
    end
end

Wvec = A \ b;
Wnew = reshape(real(Wvec), nx, Ktheta);
info.numNonfiniteW = nnz(~isfinite(Wnew));
Wnew(~isfinite(Wnew)) = 0;
info.minWBeforeClip = min(Wnew(:));
info.maxWBeforeClip = max(Wnew(:));
if local_get_bool(par, 'clipNegativeW', true)
    floorW = local_get_num(par, 'WFloor', 0);
    info.numNegativeW = nnz(Wnew < floorW);
    Wnew = max(Wnew, floorW);
else
    info.numNegativeW = nnz(Wnew < 0);
end

info.rIfMax = max(rCurv);
info.rIfMin = min(rCurv);
info.rIfPlusMax = max(max(rCurv),0);
info.rIfAbsMax = max(abs(rCurv));
info.WmaxAfter = max(Wnew(:));
info.WminAfter = min(Wnew(:));
end

function [scale, rhoNew, info] = local_logistic_reaction_scale(rho, K, eps, dt, par)
% 对 eps*rho_t=(K-rho)rho 的逐点精确解给出缩放 rhoNew/rho。
info = struct('numClipped',0);
rho = max(real(rho(:)), 0);
K = max(real(K(:)), 0);
rhoFloor = local_get_num(par, 'rhoReactionFloor', 1e-300);
rhoSafe = max(rho, rhoFloor);
rhoNew = zeros(size(rhoSafe));

for j = 1:numel(rhoSafe)
    Kj = K(j);
    rj = rhoSafe(j);
    if Kj > 0
        a = Kj * dt / max(eps, realmin);
        if a > 80
            % 充分长的快反应步直接松弛到 K，避免 exp 下溢/上溢。
            rhoNew(j) = Kj;
        else
            ea = exp(-a);
            rhoNew(j) = Kj / (1 + (Kj/rj - 1)*ea);
        end
    else
        % K=0 时 eps*rho_t=-rho^2。
        rhoNew(j) = rj / (1 + dt*rj/max(eps,realmin));
    end
end
scale = rhoNew ./ rhoSafe;

sMax = local_get_num(par, 'reactionScaleMaxAllowed', 1e6);
sMin = local_get_num(par, 'reactionScaleMinAllowed', 1e-6);
if isfinite(sMax) && sMax > 0
    n1 = nnz(scale > sMax);
    scale = min(scale, sMax);
else
    n1 = 0;
end
if isfinite(sMin) && sMin > 0
    n2 = nnz(scale < sMin);
    scale = max(scale, sMin);
else
    n2 = 0;
end
info.numClipped = n1 + n2;
end

function val = local_get_string(s, name, defaultValue)
val = defaultValue;
if isstruct(s) && isfield(s, name) && ~isempty(s.(name))
    val = char(s.(name));
end
end

function tf = local_get_bool(s, name, defaultValue)
tf = defaultValue;
if isstruct(s) && isfield(s, name) && ~isempty(s.(name))
    tf = logical(s.(name));
end
end

function val = local_get_num(s, name, defaultValue)
val = defaultValue;
if isstruct(s) && isfield(s, name) && ~isempty(s.(name)) && isnumeric(s.(name)) && isscalar(s.(name))
    val = double(s.(name));
end
end
