function diag = compute_diagnostics_1d(W, u, D, Kx, rho, H, eps, op, par, variant)
%COMPUTE_DIAGNOSTICS_1D 一维 WKB 标准诊断量。
if nargin < 10 || isempty(variant)
    variant = par.amplitudeVariant;
end
[~, n] = src.reconstruct_rho_1d(W, u, eps, op, 'direct-log');
wx = utils.trapz_weights(op.nx, op.dx);
P = (wx.' * n);
[~, idP] = max(P);
[~, idU] = max(u);
diag.theta_direct = op.theta(idP);
diag.theta_wkb = op.theta(idU);
diag.theta_m = par.theta_m;
diag.err_direct_to_m = utils.periodic_distance(diag.theta_direct, par.theta_m);
diag.err_wkb_to_m = utils.periodic_distance(diag.theta_wkb, par.theta_m);
dist = utils.periodic_distance(op.theta, diag.theta_wkb);
diag.sigma_theta = sqrt(sum((dist.^2).*P) / max(sum(P), realmin));
diag.Hmin = min(H);
diag.H_at_wkb = H(idU);
diag.rho_min = min(rho);
diag.rho_max = max(rho);
diag.W_min = min(W(:));
diag.W_max = max(W(:));
diag.mass_total = op.dtheta * sum(P);
diag.gammaR = src.compute_remainder_gamma_1d(W, u, D, eps, op, par, variant);
if isfield(par, 'dt') && ~isempty(par.dt)
    ts = src.time_step_stability_info_1d(W, u, Kx, rho, H, eps, par.dt, op, par, variant);
    diag.lambdaR = ts.lambdaR;
    diag.lambdaH = ts.lambdaH;
    diag.rplusMax = ts.rplusMax;
    diag.HabsMax = ts.HabsMax;
    diag.phaseCFL = ts.phaseCFL;
    diag.phaseSpeedMax = ts.phaseSpeedMax;
    diag.neighborJumpOverEps = ts.neighborJumpOverEps;
end
Wpos = W(isfinite(W) & W > 0);
if isempty(Wpos)
    diag.logWRange = Inf;
else
    diag.logWRange = max(log(Wpos(:))) - min(log(Wpos(:)));
end
diag.P = P;
end
