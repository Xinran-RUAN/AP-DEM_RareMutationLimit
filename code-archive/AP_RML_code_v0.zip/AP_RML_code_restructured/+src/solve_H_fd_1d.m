function H = solve_H_fd_1d(D, Kx, rho, op)
%SOLVE_H_FD_1D 计算每个 theta_k 对应的离散主特征值 H_k。
%
% 离散特征值问题写成
%   -D_k L_x N - diag(K-rho) N = H_k N.
% 时间推进中的 Neumann Laplacian 采用 reflected ghost，因此在普通欧氏
% 内积下不完全对称；但它在梯形权重内积下是自伴的。这里用
%   S A S^{-1},  S = diag(sqrt(w_x))
% 做相似变换后再调用 eigs('sa')，避免 MATLAB 对 issym 的 warning，
% 也保持与时间推进算子一致。

Ktheta = numel(D);
nx = op.nx;
H = zeros(1, Ktheta);

opts = struct();
opts.tol = 1e-11;
opts.maxit = 500;

V = Kx(:) - rho(:);
wx = utils.trapz_weights(nx, op.dx);
S = spdiags(sqrt(wx), 0, nx, nx);
Sinv = spdiags(1 ./ sqrt(wx), 0, nx, nx);

for k = 1:Ktheta
    A = -D(k) * op.Lx - spdiags(V, 0, nx, nx);
    As = S * A * Sinv;
    As = (As + As')/2;  % 消除舍入误差导致的非对称小扰动
    try
        H(k) = eigs(As, 1, 'sa', opts);
    catch
        try
            H(k) = eigs(As, 1, 'smallestreal', opts);
        catch
            % 小矩阵或 eigs 失败时的保险 fallback。
            ev = eig(full(As));
            H(k) = min(real(ev));
        end
    end
end
end
