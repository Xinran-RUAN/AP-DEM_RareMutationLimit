function par = default_params_1d(profile)
%DEFAULT_PARAMS_1D 1D WKB/direct 程序的默认参数。
%   profile = 'baseline'      文档中的基准算例；
%   profile = 'heterogeneous' 非平凡非均匀算例。
%
%   说明：run 目录中的脚本通常先调用本函数，再覆盖少数参数。
%   这样可以保证网格、时间步、输出路径、进度打印等控制量集中管理。

if nargin < 1 || isempty(profile)
    profile = 'baseline';
end

par.profile = profile;

%-------------------------
% 网格和时间推进参数
%-------------------------
par.Nx = 200;                 % x 方向子区间数；实际节点数为 Nx+1
par.Ntheta = 64;              % 周期 trait 网格点数
par.dt = 1e-3;                % 时间步长
par.T = 50;                   % 终止时间
par.maxSteps = Inf;           % 额外的最大步数限制；Inf 表示只受 T 控制
par.tol = 1e-9;               % 稳态残差阈值
par.saveEvery = Inf;          % 预留字段：固定步数保存
par.outdir = utils.output_dir(profile);

%-------------------------
% 小突变参数和初始相位
%-------------------------
par.eps = 1e-2;
par.theta0 = 0.70;            % 初始相位峰值位置，故意与 theta_m 不同
par.alpha0 = 0.05;            % 初始相位宽度参数

%-------------------------
% WKB 数值格式选择
%-------------------------
par.phaseHamiltonian = 'godunov';    % 'godunov', 'lf', 或 'weno5'
par.lfAlpha = 10;                    % Lax--Friedrichs Hamiltonian 的粘性系数
par.amplitudeVariant = 'split';      % 'split' 或 'density-compatible'
par.transportImplicit = true;        % split WKB 中 theta 输运项是否隐式
par.rhoReconstruction = 'direct-log'; % 'direct-log', 'laplace', 或 'laplace-hybrid'

%-------------------------
% 停止、快照和进度输出控制
%-------------------------
par.stopByResidual = true;            % true: residual 达到 tol 后提前停止
par.storeSnapshots = true;            % true: 按 snapshotTimes 保存中间结果
par.snapshotTimes = [];
par.verbose = true;                   % true: 打印进度和保存信息
par.progressEveryPercent = 5;         % 至少每 5%% 预计进度输出一次
par.progressEverySeconds = 10;        % 或者每 10 秒墙钟时间输出一次
par.progressEverySteps = [];          % 为空时自动按 progressEveryPercent 估计
par.historyEveryTime = 0.1;           % 诊断历史记录的时间间隔；会额外计算 gammaR
par.historyEverySteps = [];           % 为空时由 historyEveryTime/dt 自动确定

%-------------------------
% 系数函数。baseline 对应文档中的主算例。
%-------------------------
switch lower(profile)
    case 'baseline'
        theta_m = 0.35;
        K0 = 1.0;
        K1 = 0.5;
        Dmin = 0.2;
        D1 = 0.4;
        par.theta_m = theta_m;
        par.K0 = K0;
        par.K1 = K1;
        par.Dmin = Dmin;
        par.D1 = D1;
        par.K_fun = @(x) K0 + K1 * cos(2*pi*x);
        par.D_fun = @(theta) Dmin + D1 * (1 - cos(2*pi*(theta - theta_m)));
    case 'heterogeneous'
        theta_m = 0.25;
        par.theta_m = theta_m;
        par.K_fun = @(x) 1 + 0.35*cos(2*pi*x) + 0.20*cos(4*pi*x);
        par.D_fun = @(theta) 0.15 + 0.35*(1 - cos(2*pi*(theta - theta_m))) + ...
                             0.08*(1 - cos(4*pi*(theta - theta_m)));
    otherwise
        error('Unknown profile "%s".', profile);
end
end
