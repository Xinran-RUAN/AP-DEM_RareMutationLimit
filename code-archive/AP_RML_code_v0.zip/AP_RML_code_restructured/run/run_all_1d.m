% RUN_ALL_1D 依次运行所有一维数值实验脚本。
% 注意：这会花较长时间；日常单组参数请用 run_main_1d。
root = fileparts(fileparts(mfilename('fullpath')));
addpath(root);
startup_AP_RML;
here = fileparts(mfilename('fullpath'));

scripts = {'run_test1_assumption_diagnostics.m', ...
           'run_test2_long_time_concentration.m', ...
           'run_test3_fine_grid_compare_n.m', ...
           'run_test4_coarse_theta_AP.m', ...
           'run_test5_accuracy.m'};

fprintf('\n========== RUN_ALL_1D: 共 %d 个实验 ==========\n', numel(scripts));
for iscript = 1:numel(scripts)
    fprintf('\n========== [%d/%d] %s ==========\n', iscript, numel(scripts), scripts{iscript});
    run(fullfile(here, scripts{iscript}));
end
fprintf('\nRUN_ALL_1D 完成。\n');
