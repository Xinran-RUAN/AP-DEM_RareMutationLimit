% RUN_TEST3_FINE_GRID_COMPARE_N
% 数值实验 3：在较细 theta 网格上比较 direct n 与 WKB 重构 n。
root = fileparts(fileparts(mfilename('fullpath')));
addpath(root);
startup_AP_RML;

par = model.default_params_1d('baseline');
par.eps = 1e-2;
par.Nx = 200;
par.Ntheta = 256;
par.T = 30;
par.dt = 5e-4;
par.tol = 1e-9;
par.outdir = utils.output_dir('test3_compare_n');
par.verbose = true;
par.progressEveryPercent = 5;
par.historyEveryTime = 0.2;

fprintf('\n========== TEST 3: fine-grid comparison of n ==========\n');
fprintf('eps=%.4g, Nx=%d, Ntheta=%d, T=%.4g, dt=%.4g\n', ...
    par.eps, par.Nx, par.Ntheta, par.T, par.dt);
fprintf('[TEST 3] 先运行 WKB，然后运行 direct solver。\n');
wkb = src.run_wkb_1d(par);
direct = src.run_direct_1d(par);

% 加权 L1/L2 误差：x 方向用梯形权重，theta 方向用周期均匀权重。
wx = utils.trapz_weights(wkb.op.nx, wkb.op.dx);
errL1 = wkb.op.dtheta * sum(wx.' * abs(wkb.n - direct.n));
refL1 = wkb.op.dtheta * sum(wx.' * abs(direct.n));
errL2 = sqrt(wkb.op.dtheta * sum(wx.' * (wkb.n - direct.n).^2));
refL2 = sqrt(wkb.op.dtheta * sum(wx.' * direct.n.^2));
summary = struct('relL1',errL1/max(refL1,realmin),'relL2',errL2/max(refL2,realmin), ...
                 'theta_wkb',wkb.diagnostics.theta_wkb, ...
                 'theta_direct',direct.diagnostics.theta_direct, ...
                 'wkb_steps',wkb.step,'direct_steps',direct.step);
disp(summary);
utils.ensure_dir(par.outdir);
save(fullfile(par.outdir,'summary_compare_n.mat'),'summary','wkb','direct');
fprintf('TEST 3 完成。summary 保存到: %s\n', fullfile(par.outdir,'summary_compare_n.mat'));
