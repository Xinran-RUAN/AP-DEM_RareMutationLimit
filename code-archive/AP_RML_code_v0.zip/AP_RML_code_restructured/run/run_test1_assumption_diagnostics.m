% RUN_TEST1_ASSUMPTION_DIAGNOSTICS
% 数值实验 1：检查文章关键假设和诊断量，包括 rho 有界性、W 非负性、
% remainder 指标 gammaR 是否随 eps 变小仍保持可控。
root = fileparts(fileparts(mfilename('fullpath')));
addpath(root);
startup_AP_RML;

epsList = [5e-2, 2e-2, 1e-2, 5e-3];
outdir = utils.output_dir('test1_assumptions');
rows = struct([]);

fprintf('\n========== TEST 1: assumption diagnostics，共 %d 组 ==========\n', numel(epsList));
for i = 1:numel(epsList)
    par = model.default_params_1d('baseline');
    par.eps = epsList(i);
    par.Nx = 200;
    par.Ntheta = 64;
    par.T = 50;
    par.dt = min(1e-3, 0.1*par.eps);
    par.tol = 1e-9;
    par.outdir = outdir;
    par.amplitudeVariant = 'split';
    par.progressEveryPercent = 10;  % 成组实验中每组少打一点，避免刷屏
    par.historyEveryTime = 0.2;

    fprintf('\n[TEST 1] case %d/%d: eps=%.4g, Nx=%d, Ntheta=%d, T=%.4g, dt=%.4g\n', ...
        i, numel(epsList), par.eps, par.Nx, par.Ntheta, par.T, par.dt);
    result = src.run_wkb_1d(par);

    rows(i).eps = par.eps;
    rows(i).theta_wkb = result.diagnostics.theta_wkb;
    rows(i).err_wkb_to_m = result.diagnostics.err_wkb_to_m;
    rows(i).rho_max = result.diagnostics.rho_max;
    rows(i).W_min = result.diagnostics.W_min;
    rows(i).gammaR = result.diagnostics.gammaR;
    rows(i).residual = result.residual;
    rows(i).steps = result.step;
end
T = struct2table(rows);
disp(T);
utils.ensure_dir(outdir);
save(fullfile(outdir,'summary.mat'), 'T');
fprintf('TEST 1 完成。summary 保存到: %s\n', fullfile(outdir,'summary.mat'));
