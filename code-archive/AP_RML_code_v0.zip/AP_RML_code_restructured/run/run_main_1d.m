% RUN_MAIN_1D 普通一维主程序：只跑一组参数，不做成组数值测试。
% 用法：
%   startup_AP_RML
%   run_main_1d
%
% 说明：
%   这个脚本适合日常检查模型、生成一组基准数据或调参数。
%   与 run_test*.m 不同，这里没有 eps/grid 的循环，也不计算测试表格。

root = fileparts(fileparts(mfilename('fullpath')));
addpath(root);
startup_AP_RML;

%==============================
% 1. 选择模型和数值参数
%==============================
par = model.default_params_1d('baseline');   % 'baseline' 或 'heterogeneous'
par.eps = 1e-2;
par.Nx = 200;
par.Ntheta = 128;
par.T = 30;
par.dt = 1e-3;
par.tol = 1e-9;

% WKB 格式选项。
par.phaseHamiltonian = 'godunov';            % 'godunov', 'lf', 或 'weno5'
par.amplitudeVariant = 'split';              % 'split' 或 'density-compatible'
par.rhoReconstruction = 'direct-log';

% 输出和进度控制。
par.outdir = utils.output_dir('main_single_case');
par.verbose = true;
par.progressEveryPercent = 5;                % 每 5%% 预计进度至少输出一次
par.progressEverySeconds = 10;               % 或每 10 秒输出一次
par.historyEveryTime = 0.2;                  % 每 0.2 个模型时间单位记录一次诊断
par.storeSnapshots = true;
par.snapshotTimes = [1, 5, 10, 20, par.T];

% 是否同时跑直接密度方程。默认 false，因为 direct 在小 eps 下更慢且容易欠分辨。
runDirect = false;

fprintf('\n========== RUN_MAIN_1D: 单组参数主程序 ==========\n');
fprintf('profile=%s, eps=%.4g, Nx=%d, Ntheta=%d, T=%.4g, dt=%.4g\n', ...
    par.profile, par.eps, par.Nx, par.Ntheta, par.T, par.dt);
fprintf('outdir=%s\n', par.outdir);

%==============================
% 2. 运行 WKB 求解器
%==============================
wkb = src.run_wkb_1d(par);

%==============================
% 3. 可选：运行原始密度方程直接求解器
%==============================
if runDirect
    direct = src.run_direct_1d(par); %#ok<SNASGU>
else
    direct = []; %#ok<NASGU>
end

%==============================
% 4. 保存本次单组运行摘要
%==============================
summary = struct();
summary.profile = par.profile;
summary.eps = par.eps;
summary.Nx = par.Nx;
summary.Ntheta = par.Ntheta;
summary.T = par.T;
summary.dt = par.dt;
summary.theta_m = par.theta_m;
summary.theta_wkb = wkb.diagnostics.theta_wkb;
summary.err_wkb_to_m = wkb.diagnostics.err_wkb_to_m;
summary.sigma_theta = wkb.diagnostics.sigma_theta;
summary.rho_max = wkb.diagnostics.rho_max;
summary.gammaR = wkb.diagnostics.gammaR;
summary.residual = wkb.residual;
summary.steps = wkb.step;

utils.ensure_dir(par.outdir);
save(fullfile(par.outdir, 'summary_main_1d.mat'), 'summary', 'wkb', 'direct');

disp('RUN_MAIN_1D 摘要:');
disp(summary);
fprintf('RUN_MAIN_1D 完成。结果目录: %s\n', par.outdir);
