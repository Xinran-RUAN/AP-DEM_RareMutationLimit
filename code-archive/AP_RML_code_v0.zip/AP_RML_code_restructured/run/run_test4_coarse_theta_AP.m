% RUN_TEST4_COARSE_THETA_AP
% 数值实验 4：theta 网格较粗时，比较 WKB 与 direct 捕捉集中位置的能力。
root = fileparts(fileparts(mfilename('fullpath')));
addpath(root);
startup_AP_RML;

KList = [16, 24, 32, 48, 64];
outdir = utils.output_dir('test4_coarse_AP');
rows = struct([]);

fprintf('\n========== TEST 4: coarse theta AP，共 %d 组 ==========\n', numel(KList));
for i = 1:numel(KList)
    par = model.default_params_1d('baseline');
    par.eps = 5e-3;
    par.Nx = 200;
    par.Ntheta = KList(i);
    par.T = 60;
    par.dt = 5e-4;
    par.tol = 1e-9;
    par.outdir = outdir;
    par.progressEveryPercent = 10;
    par.historyEveryTime = 0.2;

    fprintf('\n[TEST 4] case %d/%d: K=%d, eps=%.4g, T=%.4g, dt=%.4g\n', ...
        i, numel(KList), par.Ntheta, par.eps, par.T, par.dt);
    wkb = src.run_wkb_1d(par);
    direct = src.run_direct_1d(par);

    rows(i).K = KList(i);
    rows(i).theta_wkb = wkb.diagnostics.theta_wkb;
    rows(i).theta_direct = direct.diagnostics.theta_direct;
    rows(i).err_wkb_to_m = wkb.diagnostics.err_wkb_to_m;
    rows(i).err_direct_to_m = direct.diagnostics.err_direct_to_m;
    rows(i).sigma_wkb = wkb.diagnostics.sigma_theta;
    rows(i).wkb_steps = wkb.step;
    rows(i).direct_steps = direct.step;
end
T = struct2table(rows);
disp(T);
utils.ensure_dir(outdir);
save(fullfile(outdir,'summary.mat'),'T');
fprintf('TEST 4 完成。summary 保存到: %s\n', fullfile(outdir,'summary.mat'));
