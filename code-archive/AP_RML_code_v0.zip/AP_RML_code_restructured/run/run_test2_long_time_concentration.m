% RUN_TEST2_LONG_TIME_CONCENTRATION
% 数值实验 2：长时间演化后，检查解是否在 theta 方向形成集中。
root = fileparts(fileparts(mfilename('fullpath')));
addpath(root);
startup_AP_RML;

par = model.default_params_1d('baseline');
par.eps = 1e-2;
par.Nx = 200;
par.Ntheta = 128;
par.T = 80;
par.dt = 1e-3;
par.tol = 1e-10;
par.outdir = utils.output_dir('test2_long_time');
par.snapshotTimes = [1, 5, 10, 20, 40, 80];
par.progressEveryPercent = 5;
par.historyEveryTime = 0.2;

fprintf('\n========== TEST 2: long-time concentration ==========\n');
fprintf('eps=%.4g, Nx=%d, Ntheta=%d, T=%.4g, dt=%.4g\n', ...
    par.eps, par.Nx, par.Ntheta, par.T, par.dt);
result = src.run_wkb_1d(par);
disp(result.diagnostics);
fprintf('TEST 2 完成。输出目录: %s\n', par.outdir);
